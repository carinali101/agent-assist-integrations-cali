# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import abc
from typing import Awaitable, Callable, Dict, Optional, Sequence, Union

from google.cloud.dialogflow_v2beta1 import gapic_version as package_version

import google.auth  # type: ignore
import google.api_core
from google.api_core import exceptions as core_exceptions
from google.api_core import gapic_v1
from google.api_core import retry as retries
from google.api_core import operations_v1
from google.auth import credentials as ga_credentials  # type: ignore
from google.oauth2 import service_account # type: ignore
import google.protobuf

from google.cloud.dialogflow_v2beta1.types import conversation
from google.cloud.dialogflow_v2beta1.types import conversation as gcd_conversation
from google.cloud.dialogflow_v2beta1.types import interaction_monitoring
from google.cloud.dialogflow_v2beta1.types import participant
from google.cloud.location import locations_pb2 # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from google.protobuf import empty_pb2  # type: ignore

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(gapic_version=package_version.__version__)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class ConversationsTransport(abc.ABC):
    """Abstract transport class for Conversations."""

    AUTH_SCOPES = (
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/dialogflow',
    )

    DEFAULT_HOST: str = 'dialogflow.googleapis.com'

    def __init__(
            self, *,
            host: str = DEFAULT_HOST,
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            api_audience: Optional[str] = None,
            **kwargs,
            ) -> None:
        """Instantiate the transport.

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is mutually exclusive with credentials. This argument will be
                removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A list of scopes.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
        """

        scopes_kwargs = {"scopes": scopes, "default_scopes": self.AUTH_SCOPES}

        # Save the scopes.
        self._scopes = scopes
        if not hasattr(self, "_ignore_credentials"):
            self._ignore_credentials: bool = False

        # If no credentials are provided, then determine the appropriate
        # defaults.
        if credentials and credentials_file:
            raise core_exceptions.DuplicateCredentialArgs("'credentials_file' and 'credentials' are mutually exclusive")

        if credentials_file is not None:
            credentials, _ = google.auth.load_credentials_from_file(
                                credentials_file,
                                **scopes_kwargs,
                                quota_project_id=quota_project_id
                            )
        elif credentials is None and not self._ignore_credentials:
            credentials, _ = google.auth.default(**scopes_kwargs, quota_project_id=quota_project_id)
            # Don't apply audience if the credentials file passed from user.
            if hasattr(credentials, "with_gdch_audience"):
                credentials = credentials.with_gdch_audience(api_audience if api_audience else host)

        # If the credentials are service account credentials, then always try to use self signed JWT.
        if always_use_jwt_access and isinstance(credentials, service_account.Credentials) and hasattr(service_account.Credentials, "with_always_use_jwt_access"):
            credentials = credentials.with_always_use_jwt_access(True)

        # Save the credentials.
        self._credentials = credentials

        # Save the hostname. Default to port 443 (HTTPS) if none is specified.
        if ':' not in host:
            host += ':443'
        self._host = host

    @property
    def host(self):
        return self._host

    def _prep_wrapped_messages(self, client_info):
        # Precompute the wrapped methods.
        self._wrapped_methods = {
            self.create_conversation: gapic_v1.method.wrap_method(
                self.create_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_conversations: gapic_v1.method.wrap_method(
                self.list_conversations,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_conversation: gapic_v1.method.wrap_method(
                self.get_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.add_conversation_phone_number: gapic_v1.method.wrap_method(
                self.add_conversation_phone_number,
                default_timeout=None,
                client_info=client_info,
            ),
            self.activate_conversation: gapic_v1.method.wrap_method(
                self.activate_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.deactivate_conversation: gapic_v1.method.wrap_method(
                self.deactivate_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.complete_conversation: gapic_v1.method.wrap_method(
                self.complete_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.update_conversation: gapic_v1.method.wrap_method(
                self.update_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.ingest_context_references: gapic_v1.method.wrap_method(
                self.ingest_context_references,
                default_timeout=None,
                client_info=client_info,
            ),
            self.create_call_matcher: gapic_v1.method.wrap_method(
                self.create_call_matcher,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_call_matchers: gapic_v1.method.wrap_method(
                self.list_call_matchers,
                default_timeout=None,
                client_info=client_info,
            ),
            self.delete_call_matcher: gapic_v1.method.wrap_method(
                self.delete_call_matcher,
                default_timeout=None,
                client_info=client_info,
            ),
            self.batch_create_messages: gapic_v1.method.wrap_method(
                self.batch_create_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_messages: gapic_v1.method.wrap_method(
                self.list_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.export_messages: gapic_v1.method.wrap_method(
                self.export_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.suggest_conversation_summary: gapic_v1.method.wrap_method(
                self.suggest_conversation_summary,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_stateless_summary: gapic_v1.method.wrap_method(
                self.generate_stateless_summary,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_stateless_suggestion: gapic_v1.method.wrap_method(
                self.generate_stateless_suggestion,
                default_timeout=None,
                client_info=client_info,
            ),
            self.suggest_conversation_key_moments: gapic_v1.method.wrap_method(
                self.suggest_conversation_key_moments,
                default_timeout=None,
                client_info=client_info,
            ),
            self.search_articles: gapic_v1.method.wrap_method(
                self.search_articles,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_past_call_companion_events: gapic_v1.method.wrap_method(
                self.list_past_call_companion_events,
                default_timeout=None,
                client_info=client_info,
            ),
            self.streaming_list_upcoming_call_companion_events: gapic_v1.method.wrap_method(
                self.streaming_list_upcoming_call_companion_events,
                default_timeout=600.0,
                client_info=client_info,
            ),
            self.inject_call_companion_user_input: gapic_v1.method.wrap_method(
                self.inject_call_companion_user_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.streaming_list_call_companion_events: gapic_v1.method.wrap_method(
                self.streaming_list_call_companion_events,
                default_timeout=600.0,
                client_info=client_info,
            ),
            self.inject_call_companion_input: gapic_v1.method.wrap_method(
                self.inject_call_companion_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.initialize_call_companion: gapic_v1.method.wrap_method(
                self.initialize_call_companion,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_call_companion_settings: gapic_v1.method.wrap_method(
                self.get_call_companion_settings,
                default_timeout=None,
                client_info=client_info,
            ),
            self.search_knowledge: gapic_v1.method.wrap_method(
                self.search_knowledge,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_suggestions: gapic_v1.method.wrap_method(
                self.generate_suggestions,
                default_timeout=None,
                client_info=client_info,
            ),
            self.initiate_phone_call: gapic_v1.method.wrap_method(
                self.initiate_phone_call,
                default_timeout=None,
                client_info=client_info,
            ),
            self.inject_supervisor_input: gapic_v1.method.wrap_method(
                self.inject_supervisor_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_interaction_monitoring_alert: gapic_v1.method.wrap_method(
                self.get_interaction_monitoring_alert,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_interaction_monitoring_alerts: gapic_v1.method.wrap_method(
                self.list_interaction_monitoring_alerts,
                default_timeout=None,
                client_info=client_info,
            ),
            self.ack_interaction_monitoring_alert: gapic_v1.method.wrap_method(
                self.ack_interaction_monitoring_alert,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_interaction_monitoring_metrics: gapic_v1.method.wrap_method(
                self.list_interaction_monitoring_metrics,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_location: gapic_v1.method.wrap_method(
                self.get_location,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_locations: gapic_v1.method.wrap_method(
                self.list_locations,
                default_timeout=None,
                client_info=client_info,
            ),
            self.cancel_operation: gapic_v1.method.wrap_method(
                self.cancel_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_operation: gapic_v1.method.wrap_method(
                self.get_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_operations: gapic_v1.method.wrap_method(
                self.list_operations,
                default_timeout=None,
                client_info=client_info,
            ),
         }

    def close(self):
        """Closes resources associated with the transport.

       .. warning::
            Only call this method if the transport is NOT shared
            with other clients - this may cause errors in other clients!
        """
        raise NotImplementedError()

    @property
    def operations_client(self):
        """Return the client designed to process long-running operations."""
        raise NotImplementedError()

    @property
    def create_conversation(self) -> Callable[
            [gcd_conversation.CreateConversationRequest],
            Union[
                gcd_conversation.Conversation,
                Awaitable[gcd_conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def list_conversations(self) -> Callable[
            [conversation.ListConversationsRequest],
            Union[
                conversation.ListConversationsResponse,
                Awaitable[conversation.ListConversationsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def get_conversation(self) -> Callable[
            [conversation.GetConversationRequest],
            Union[
                conversation.Conversation,
                Awaitable[conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def add_conversation_phone_number(self) -> Callable[
            [conversation.AddConversationPhoneNumberRequest],
            Union[
                conversation.ConversationPhoneNumber,
                Awaitable[conversation.ConversationPhoneNumber]
            ]]:
        raise NotImplementedError()

    @property
    def activate_conversation(self) -> Callable[
            [gcd_conversation.ActivateConversationRequest],
            Union[
                gcd_conversation.Conversation,
                Awaitable[gcd_conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def deactivate_conversation(self) -> Callable[
            [gcd_conversation.DeactivateConversationRequest],
            Union[
                gcd_conversation.Conversation,
                Awaitable[gcd_conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def complete_conversation(self) -> Callable[
            [conversation.CompleteConversationRequest],
            Union[
                conversation.Conversation,
                Awaitable[conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def update_conversation(self) -> Callable[
            [gcd_conversation.UpdateConversationRequest],
            Union[
                gcd_conversation.Conversation,
                Awaitable[gcd_conversation.Conversation]
            ]]:
        raise NotImplementedError()

    @property
    def ingest_context_references(self) -> Callable[
            [gcd_conversation.IngestContextReferencesRequest],
            Union[
                gcd_conversation.IngestContextReferencesResponse,
                Awaitable[gcd_conversation.IngestContextReferencesResponse]
            ]]:
        raise NotImplementedError()

    @property
    def create_call_matcher(self) -> Callable[
            [conversation.CreateCallMatcherRequest],
            Union[
                conversation.CallMatcher,
                Awaitable[conversation.CallMatcher]
            ]]:
        raise NotImplementedError()

    @property
    def list_call_matchers(self) -> Callable[
            [conversation.ListCallMatchersRequest],
            Union[
                conversation.ListCallMatchersResponse,
                Awaitable[conversation.ListCallMatchersResponse]
            ]]:
        raise NotImplementedError()

    @property
    def delete_call_matcher(self) -> Callable[
            [conversation.DeleteCallMatcherRequest],
            Union[
                empty_pb2.Empty,
                Awaitable[empty_pb2.Empty]
            ]]:
        raise NotImplementedError()

    @property
    def batch_create_messages(self) -> Callable[
            [conversation.BatchCreateMessagesRequest],
            Union[
                conversation.BatchCreateMessagesResponse,
                Awaitable[conversation.BatchCreateMessagesResponse]
            ]]:
        raise NotImplementedError()

    @property
    def list_messages(self) -> Callable[
            [conversation.ListMessagesRequest],
            Union[
                conversation.ListMessagesResponse,
                Awaitable[conversation.ListMessagesResponse]
            ]]:
        raise NotImplementedError()

    @property
    def export_messages(self) -> Callable[
            [conversation.ExportMessagesRequest],
            Union[
                operations_pb2.Operation,
                Awaitable[operations_pb2.Operation]
            ]]:
        raise NotImplementedError()

    @property
    def suggest_conversation_summary(self) -> Callable[
            [gcd_conversation.SuggestConversationSummaryRequest],
            Union[
                gcd_conversation.SuggestConversationSummaryResponse,
                Awaitable[gcd_conversation.SuggestConversationSummaryResponse]
            ]]:
        raise NotImplementedError()

    @property
    def generate_stateless_summary(self) -> Callable[
            [conversation.GenerateStatelessSummaryRequest],
            Union[
                conversation.GenerateStatelessSummaryResponse,
                Awaitable[conversation.GenerateStatelessSummaryResponse]
            ]]:
        raise NotImplementedError()

    @property
    def generate_stateless_suggestion(self) -> Callable[
            [conversation.GenerateStatelessSuggestionRequest],
            Union[
                conversation.GenerateStatelessSuggestionResponse,
                Awaitable[conversation.GenerateStatelessSuggestionResponse]
            ]]:
        raise NotImplementedError()

    @property
    def suggest_conversation_key_moments(self) -> Callable[
            [gcd_conversation.SuggestConversationKeyMomentsRequest],
            Union[
                gcd_conversation.SuggestConversationKeyMomentsResponse,
                Awaitable[gcd_conversation.SuggestConversationKeyMomentsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def search_articles(self) -> Callable[
            [gcd_conversation.SearchArticlesRequest],
            Union[
                gcd_conversation.SearchArticlesResponse,
                Awaitable[gcd_conversation.SearchArticlesResponse]
            ]]:
        raise NotImplementedError()

    @property
    def list_past_call_companion_events(self) -> Callable[
            [gcd_conversation.ListPastCallCompanionEventsRequest],
            Union[
                gcd_conversation.ListPastCallCompanionEventsResponse,
                Awaitable[gcd_conversation.ListPastCallCompanionEventsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def streaming_list_upcoming_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest],
            Union[
                gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse,
                Awaitable[gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def inject_call_companion_user_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionUserInputRequest],
            Union[
                gcd_conversation.InjectCallCompanionUserInputResponse,
                Awaitable[gcd_conversation.InjectCallCompanionUserInputResponse]
            ]]:
        raise NotImplementedError()

    @property
    def streaming_list_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListCallCompanionEventsRequest],
            Union[
                gcd_conversation.StreamingListCallCompanionEventsResponse,
                Awaitable[gcd_conversation.StreamingListCallCompanionEventsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def inject_call_companion_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionInputRequest],
            Union[
                gcd_conversation.InjectCallCompanionInputResponse,
                Awaitable[gcd_conversation.InjectCallCompanionInputResponse]
            ]]:
        raise NotImplementedError()

    @property
    def initialize_call_companion(self) -> Callable[
            [gcd_conversation.InitializeCallCompanionRequest],
            Union[
                empty_pb2.Empty,
                Awaitable[empty_pb2.Empty]
            ]]:
        raise NotImplementedError()

    @property
    def get_call_companion_settings(self) -> Callable[
            [gcd_conversation.GetCallCompanionSettingsRequest],
            Union[
                gcd_conversation.CallCompanionSettings,
                Awaitable[gcd_conversation.CallCompanionSettings]
            ]]:
        raise NotImplementedError()

    @property
    def search_knowledge(self) -> Callable[
            [conversation.SearchKnowledgeRequest],
            Union[
                conversation.SearchKnowledgeResponse,
                Awaitable[conversation.SearchKnowledgeResponse]
            ]]:
        raise NotImplementedError()

    @property
    def generate_suggestions(self) -> Callable[
            [gcd_conversation.GenerateSuggestionsRequest],
            Union[
                participant.GenerateSuggestionsResponse,
                Awaitable[participant.GenerateSuggestionsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def initiate_phone_call(self) -> Callable[
            [gcd_conversation.InitiatePhoneCallRequest],
            Union[
                gcd_conversation.InitiatePhoneCallResponse,
                Awaitable[gcd_conversation.InitiatePhoneCallResponse]
            ]]:
        raise NotImplementedError()

    @property
    def inject_supervisor_input(self) -> Callable[
            [gcd_conversation.InjectSupervisorInputRequest],
            Union[
                gcd_conversation.InjectSupervisorInputResponse,
                Awaitable[gcd_conversation.InjectSupervisorInputResponse]
            ]]:
        raise NotImplementedError()

    @property
    def get_interaction_monitoring_alert(self) -> Callable[
            [conversation.GetInteractionMonitoringAlertRequest],
            Union[
                interaction_monitoring.InteractionMonitoringAlert,
                Awaitable[interaction_monitoring.InteractionMonitoringAlert]
            ]]:
        raise NotImplementedError()

    @property
    def list_interaction_monitoring_alerts(self) -> Callable[
            [conversation.ListInteractionMonitoringAlertsRequest],
            Union[
                conversation.ListInteractionMonitoringAlertsResponse,
                Awaitable[conversation.ListInteractionMonitoringAlertsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def ack_interaction_monitoring_alert(self) -> Callable[
            [conversation.AckInteractionMonitoringAlertRequest],
            Union[
                interaction_monitoring.InteractionMonitoringAlert,
                Awaitable[interaction_monitoring.InteractionMonitoringAlert]
            ]]:
        raise NotImplementedError()

    @property
    def list_interaction_monitoring_metrics(self) -> Callable[
            [conversation.ListInteractionMonitoringMetricsRequest],
            Union[
                conversation.ListInteractionMonitoringMetricsResponse,
                Awaitable[conversation.ListInteractionMonitoringMetricsResponse]
            ]]:
        raise NotImplementedError()

    @property
    def list_operations(
        self,
    ) -> Callable[
        [operations_pb2.ListOperationsRequest],
        Union[operations_pb2.ListOperationsResponse, Awaitable[operations_pb2.ListOperationsResponse]],
    ]:
        raise NotImplementedError()

    @property
    def get_operation(
        self,
    ) -> Callable[
        [operations_pb2.GetOperationRequest],
        Union[operations_pb2.Operation, Awaitable[operations_pb2.Operation]],
    ]:
        raise NotImplementedError()

    @property
    def cancel_operation(
        self,
    ) -> Callable[
        [operations_pb2.CancelOperationRequest],
        None,
    ]:
        raise NotImplementedError()

    @property
    def get_location(self,
    ) -> Callable[
        [locations_pb2.GetLocationRequest],
        Union[locations_pb2.Location, Awaitable[locations_pb2.Location]],
    ]:
        raise NotImplementedError()

    @property
    def list_locations(self,
    ) -> Callable[
        [locations_pb2.ListLocationsRequest],
        Union[locations_pb2.ListLocationsResponse, Awaitable[locations_pb2.ListLocationsResponse]],
    ]:
        raise NotImplementedError()

    @property
    def kind(self) -> str:
        raise NotImplementedError()


__all__ = (
    'ConversationsTransport',
)
