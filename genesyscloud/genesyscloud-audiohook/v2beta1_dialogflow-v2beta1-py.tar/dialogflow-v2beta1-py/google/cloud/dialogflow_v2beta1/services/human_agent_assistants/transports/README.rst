
transport inheritance structure
_______________________________

`HumanAgentAssistantsTransport` is the ABC for all transports.
- public child `HumanAgentAssistantsGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `HumanAgentAssistantsGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BaseHumanAgentAssistantsRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `HumanAgentAssistantsRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
