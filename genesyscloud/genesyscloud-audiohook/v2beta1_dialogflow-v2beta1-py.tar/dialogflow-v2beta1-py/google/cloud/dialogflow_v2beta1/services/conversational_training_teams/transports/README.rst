
transport inheritance structure
_______________________________

`ConversationalTrainingTeamsTransport` is the ABC for all transports.
- public child `ConversationalTrainingTeamsGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `ConversationalTrainingTeamsGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BaseConversationalTrainingTeamsRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `ConversationalTrainingTeamsRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
