# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging as std_logging
from collections import OrderedDict
import re
from typing import Dict, Callable, Mapping, MutableMapping, MutableSequence, Optional, Sequence, Tuple, Type, Union
import uuid

from google.cloud.dialogflow_v2beta1 import gapic_version as package_version

from google.api_core.client_options import ClientOptions
from google.api_core import exceptions as core_exceptions
from google.api_core import gapic_v1
from google.api_core import retry_async as retries
from google.auth import credentials as ga_credentials   # type: ignore
from google.oauth2 import service_account              # type: ignore
import google.protobuf


try:
    OptionalRetry = Union[retries.AsyncRetry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.AsyncRetry, object, None]  # type: ignore

from google.cloud.dialogflow_v2beta1.services.conversational_training_assignments import pagers
from google.cloud.dialogflow_v2beta1.types import conversational_training_assignment
from google.cloud.dialogflow_v2beta1.types import conversational_training_assignment as gcd_conversational_training_assignment
from google.cloud.location import locations_pb2 # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore
from .transports.base import ConversationalTrainingAssignmentsTransport, DEFAULT_CLIENT_INFO
from .transports.grpc_asyncio import ConversationalTrainingAssignmentsGrpcAsyncIOTransport
from .client import ConversationalTrainingAssignmentsClient

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = std_logging.getLogger(__name__)

class ConversationalTrainingAssignmentsAsyncClient:
    """Service for creating and managing conversational training
    assignment resources.
    """

    _client: ConversationalTrainingAssignmentsClient

    # Copy defaults from the synchronous client for use here.
    # Note: DEFAULT_ENDPOINT is deprecated. Use _DEFAULT_ENDPOINT_TEMPLATE instead.
    DEFAULT_ENDPOINT = ConversationalTrainingAssignmentsClient.DEFAULT_ENDPOINT
    DEFAULT_MTLS_ENDPOINT = ConversationalTrainingAssignmentsClient.DEFAULT_MTLS_ENDPOINT
    _DEFAULT_ENDPOINT_TEMPLATE = ConversationalTrainingAssignmentsClient._DEFAULT_ENDPOINT_TEMPLATE
    _DEFAULT_UNIVERSE = ConversationalTrainingAssignmentsClient._DEFAULT_UNIVERSE

    conversation_path = staticmethod(ConversationalTrainingAssignmentsClient.conversation_path)
    parse_conversation_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_conversation_path)
    conversational_training_assignment_path = staticmethod(ConversationalTrainingAssignmentsClient.conversational_training_assignment_path)
    parse_conversational_training_assignment_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_conversational_training_assignment_path)
    conversational_training_member_path = staticmethod(ConversationalTrainingAssignmentsClient.conversational_training_member_path)
    parse_conversational_training_member_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_conversational_training_member_path)
    conversational_training_module_path = staticmethod(ConversationalTrainingAssignmentsClient.conversational_training_module_path)
    parse_conversational_training_module_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_conversational_training_module_path)
    common_billing_account_path = staticmethod(ConversationalTrainingAssignmentsClient.common_billing_account_path)
    parse_common_billing_account_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_common_billing_account_path)
    common_folder_path = staticmethod(ConversationalTrainingAssignmentsClient.common_folder_path)
    parse_common_folder_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_common_folder_path)
    common_organization_path = staticmethod(ConversationalTrainingAssignmentsClient.common_organization_path)
    parse_common_organization_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_common_organization_path)
    common_project_path = staticmethod(ConversationalTrainingAssignmentsClient.common_project_path)
    parse_common_project_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_common_project_path)
    common_location_path = staticmethod(ConversationalTrainingAssignmentsClient.common_location_path)
    parse_common_location_path = staticmethod(ConversationalTrainingAssignmentsClient.parse_common_location_path)

    @classmethod
    def from_service_account_info(cls, info: dict, *args, **kwargs):
        """Creates an instance of this client using the provided credentials
            info.

        Args:
            info (dict): The service account private key info.
            args: Additional arguments to pass to the constructor.
            kwargs: Additional arguments to pass to the constructor.

        Returns:
            ConversationalTrainingAssignmentsAsyncClient: The constructed client.
        """
        return ConversationalTrainingAssignmentsClient.from_service_account_info.__func__(ConversationalTrainingAssignmentsAsyncClient, info, *args, **kwargs)  # type: ignore

    @classmethod
    def from_service_account_file(cls, filename: str, *args, **kwargs):
        """Creates an instance of this client using the provided credentials
            file.

        Args:
            filename (str): The path to the service account private key json
                file.
            args: Additional arguments to pass to the constructor.
            kwargs: Additional arguments to pass to the constructor.

        Returns:
            ConversationalTrainingAssignmentsAsyncClient: The constructed client.
        """
        return ConversationalTrainingAssignmentsClient.from_service_account_file.__func__(ConversationalTrainingAssignmentsAsyncClient, filename, *args, **kwargs)  # type: ignore

    from_service_account_json = from_service_account_file

    @classmethod
    def get_mtls_endpoint_and_cert_source(cls, client_options: Optional[ClientOptions] = None):
        """Return the API endpoint and client cert source for mutual TLS.

        The client cert source is determined in the following order:
        (1) if `GOOGLE_API_USE_CLIENT_CERTIFICATE` environment variable is not "true", the
        client cert source is None.
        (2) if `client_options.client_cert_source` is provided, use the provided one; if the
        default client cert source exists, use the default one; otherwise the client cert
        source is None.

        The API endpoint is determined in the following order:
        (1) if `client_options.api_endpoint` if provided, use the provided one.
        (2) if `GOOGLE_API_USE_CLIENT_CERTIFICATE` environment variable is "always", use the
        default mTLS endpoint; if the environment variable is "never", use the default API
        endpoint; otherwise if client cert source exists, use the default mTLS endpoint, otherwise
        use the default API endpoint.

        More details can be found at https://google.aip.dev/auth/4114.

        Args:
            client_options (google.api_core.client_options.ClientOptions): Custom options for the
                client. Only the `api_endpoint` and `client_cert_source` properties may be used
                in this method.

        Returns:
            Tuple[str, Callable[[], Tuple[bytes, bytes]]]: returns the API endpoint and the
                client cert source to use.

        Raises:
            google.auth.exceptions.MutualTLSChannelError: If any errors happen.
        """
        return ConversationalTrainingAssignmentsClient.get_mtls_endpoint_and_cert_source(client_options)  # type: ignore

    @property
    def transport(self) -> ConversationalTrainingAssignmentsTransport:
        """Returns the transport used by the client instance.

        Returns:
            ConversationalTrainingAssignmentsTransport: The transport used by the client instance.
        """
        return self._client.transport

    @property
    def api_endpoint(self):
        """Return the API endpoint used by the client instance.

        Returns:
            str: The API endpoint used by the client instance.
        """
        return self._client._api_endpoint

    @property
    def universe_domain(self) -> str:
        """Return the universe domain used by the client instance.

        Returns:
            str: The universe domain used
                by the client instance.
        """
        return self._client._universe_domain

    get_transport_class = ConversationalTrainingAssignmentsClient.get_transport_class

    def __init__(self, *,
            credentials: Optional[ga_credentials.Credentials] = None,
            transport: Optional[Union[str, ConversationalTrainingAssignmentsTransport, Callable[..., ConversationalTrainingAssignmentsTransport]]] = "grpc_asyncio",
            client_options: Optional[ClientOptions] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            ) -> None:
        """Instantiates the conversational training assignments async client.

        Args:
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
            transport (Optional[Union[str,ConversationalTrainingAssignmentsTransport,Callable[..., ConversationalTrainingAssignmentsTransport]]]):
                The transport to use, or a Callable that constructs and returns a new transport to use.
                If a Callable is given, it will be called with the same set of initialization
                arguments as used in the ConversationalTrainingAssignmentsTransport constructor.
                If set to None, a transport is chosen automatically.
                NOTE: "rest" transport functionality is currently in a
                beta state (preview). We welcome your feedback via an
                issue in this library's source repository.
            client_options (Optional[Union[google.api_core.client_options.ClientOptions, dict]]):
                Custom options for the client.

                1. The ``api_endpoint`` property can be used to override the
                default endpoint provided by the client when ``transport`` is
                not explicitly provided. Only if this property is not set and
                ``transport`` was not explicitly provided, the endpoint is
                determined by the GOOGLE_API_USE_MTLS_ENDPOINT environment
                variable, which have one of the following values:
                "always" (always use the default mTLS endpoint), "never" (always
                use the default regular endpoint) and "auto" (auto-switch to the
                default mTLS endpoint if client certificate is present; this is
                the default value).

                2. If the GOOGLE_API_USE_CLIENT_CERTIFICATE environment variable
                is "true", then the ``client_cert_source`` property can be used
                to provide a client certificate for mTLS transport. If
                not provided, the default SSL client certificate will be used if
                present. If GOOGLE_API_USE_CLIENT_CERTIFICATE is "false" or not
                set, no client certificate will be used.

                3. The ``universe_domain`` property can be used to override the
                default "googleapis.com" universe. Note that ``api_endpoint``
                property still takes precedence; and ``universe_domain`` is
                currently not supported for mTLS.

            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.

        Raises:
            google.auth.exceptions.MutualTlsChannelError: If mutual TLS transport
                creation failed for any reason.
        """
        self._client = ConversationalTrainingAssignmentsClient(
            credentials=credentials,
            transport=transport,
            client_options=client_options,
            client_info=client_info,

        )

        if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(std_logging.DEBUG):  # pragma: NO COVER
            _LOGGER.debug(
                "Created client `google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient`.",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                    "universeDomain": getattr(self._client._transport._credentials, "universe_domain", ""),
                    "credentialsType": f"{type(self._client._transport._credentials).__module__}.{type(self._client._transport._credentials).__qualname__}",
                    "credentialsInfo": getattr(self.transport._credentials, "get_cred_info", lambda: None)(),
                } if hasattr(self._client._transport, "_credentials") else {
                    "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                    "credentialsType": None,
                }
            )

    async def create_conversational_training_assignment(self,
            request: Optional[Union[gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest, dict]] = None,
            *,
            parent: Optional[str] = None,
            conversational_training_assignment: Optional[gcd_conversational_training_assignment.ConversationalTrainingAssignment] = None,
            conversational_training_assignment_id: Optional[str] = None,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
        r"""Creates a conversational training assignment.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_create_conversational_training_assignment():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                conversational_training_assignment = dialogflow_v2beta1.ConversationalTrainingAssignment()
                conversational_training_assignment.training_module = "training_module_value"

                request = dialogflow_v2beta1.CreateConversationalTrainingAssignmentRequest(
                    parent="parent_value",
                    conversational_training_assignment=conversational_training_assignment,
                )

                # Make the request
                response = await client.create_conversational_training_assignment(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.CreateConversationalTrainingAssignmentRequest, dict]]):
                The request object. Request message of
                CreateConversationalTrainingAssignment.
            parent (:class:`str`):
                Required. The member to create conversational training
                assignment for. Format:
                ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``.

                This corresponds to the ``parent`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            conversational_training_assignment (:class:`google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment`):
                Required. The conversational training
                assignment to create.

                This corresponds to the ``conversational_training_assignment`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            conversational_training_assignment_id (:class:`str`):
                Optional. The ID to use for the conversational training
                assignment, which will become the final component of the
                conversational training assignment's resource name.

                The conversational training assignment ID must be
                compliant with the regression fomula
                ``[a-zA-Z][a-zA-Z0-9_-]*`` with the characters length in
                range of [3,64]. If the field is not provide, an Id will
                be auto-generated. If the field is provided, the caller
                is responsible for

                1. the uniqueness of the ID, otherwise the request will
                   be rejected.
                2. the consistency for whether to use custom ID or not
                   under a project to better ensure uniqueness.

                This corresponds to the ``conversational_training_assignment_id`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment:
                A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

        """
        # Create or coerce a protobuf request object.
        # - Quick check: If we got a request object, we should *not* have
        #   gotten any keyword arguments that map to the request.
        flattened_params = [parent, conversational_training_assignment, conversational_training_assignment_id]
        has_flattened_params = len([param for param in flattened_params if param is not None]) > 0
        if request is not None and has_flattened_params:
            raise ValueError("If the `request` argument is set, then none of "
                             "the individual field arguments should be set.")

        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest):
            request = gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest(request)

        # If we have keyword arguments corresponding to fields on the
        # request, apply these.
        if parent is not None:
            request.parent = parent
        if conversational_training_assignment is not None:
            request.conversational_training_assignment = conversational_training_assignment
        if conversational_training_assignment_id is not None:
            request.conversational_training_assignment_id = conversational_training_assignment_id

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.create_conversational_training_assignment]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("parent", request.parent),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def get_conversational_training_assignment(self,
            request: Optional[Union[conversational_training_assignment.GetConversationalTrainingAssignmentRequest, dict]] = None,
            *,
            name: Optional[str] = None,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> conversational_training_assignment.ConversationalTrainingAssignment:
        r"""Retrieves a conversational training assignment.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_get_conversational_training_assignment():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.GetConversationalTrainingAssignmentRequest(
                    name="name_value",
                )

                # Make the request
                response = await client.get_conversational_training_assignment(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.GetConversationalTrainingAssignmentRequest, dict]]):
                The request object. Request message of
                GetConversationalTrainingAssignment.
            name (:class:`str`):
                Required. The conversational training assignment
                resource name to retrieve. Format:
                ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.

                This corresponds to the ``name`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment:
                A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

        """
        # Create or coerce a protobuf request object.
        # - Quick check: If we got a request object, we should *not* have
        #   gotten any keyword arguments that map to the request.
        flattened_params = [name]
        has_flattened_params = len([param for param in flattened_params if param is not None]) > 0
        if request is not None and has_flattened_params:
            raise ValueError("If the `request` argument is set, then none of "
                             "the individual field arguments should be set.")

        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.GetConversationalTrainingAssignmentRequest):
            request = conversational_training_assignment.GetConversationalTrainingAssignmentRequest(request)

        # If we have keyword arguments corresponding to fields on the
        # request, apply these.
        if name is not None:
            request.name = name

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.get_conversational_training_assignment]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("name", request.name),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def list_conversational_training_assignments(self,
            request: Optional[Union[conversational_training_assignment.ListConversationalTrainingAssignmentsRequest, dict]] = None,
            *,
            parent: Optional[str] = None,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> pagers.ListConversationalTrainingAssignmentsAsyncPager:
        r"""Lists conversational training assignments.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_list_conversational_training_assignments():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.ListConversationalTrainingAssignmentsRequest(
                    parent="parent_value",
                )

                # Make the request
                page_result = client.list_conversational_training_assignments(request=request)

                # Handle the response
                async for response in page_result:
                    print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.ListConversationalTrainingAssignmentsRequest, dict]]):
                The request object. Request message of
                ListConversationalTrainingAssignments.
            parent (:class:`str`):
                Required. The member to list
                conversationalTrainingAssignments for. Format:
                ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``

                This corresponds to the ``parent`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.services.conversational_training_assignments.pagers.ListConversationalTrainingAssignmentsAsyncPager:
                Response of
                ListConversationalTrainingAssignments.
                Iterating over this object will yield
                results and resolve additional pages
                automatically.

        """
        # Create or coerce a protobuf request object.
        # - Quick check: If we got a request object, we should *not* have
        #   gotten any keyword arguments that map to the request.
        flattened_params = [parent]
        has_flattened_params = len([param for param in flattened_params if param is not None]) > 0
        if request is not None and has_flattened_params:
            raise ValueError("If the `request` argument is set, then none of "
                             "the individual field arguments should be set.")

        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.ListConversationalTrainingAssignmentsRequest):
            request = conversational_training_assignment.ListConversationalTrainingAssignmentsRequest(request)

        # If we have keyword arguments corresponding to fields on the
        # request, apply these.
        if parent is not None:
            request.parent = parent

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.list_conversational_training_assignments]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("parent", request.parent),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # This method is paged; wrap the response in a pager, which provides
        # an `__aiter__` convenience method.
        response = pagers.ListConversationalTrainingAssignmentsAsyncPager(
            method=rpc,
            request=request,
            response=response,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def delete_conversational_training_assignment(self,
            request: Optional[Union[conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest, dict]] = None,
            *,
            name: Optional[str] = None,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> None:
        r"""Deletes a conversational training assignment.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_delete_conversational_training_assignment():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.DeleteConversationalTrainingAssignmentRequest(
                    name="name_value",
                )

                # Make the request
                await client.delete_conversational_training_assignment(request=request)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.DeleteConversationalTrainingAssignmentRequest, dict]]):
                The request object. Request of
                DeleteConversationalTrainingAssignment.
            name (:class:`str`):
                Required. The conversational training assignment
                resource name to delete. Format:
                ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.

                This corresponds to the ``name`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        """
        # Create or coerce a protobuf request object.
        # - Quick check: If we got a request object, we should *not* have
        #   gotten any keyword arguments that map to the request.
        flattened_params = [name]
        has_flattened_params = len([param for param in flattened_params if param is not None]) > 0
        if request is not None and has_flattened_params:
            raise ValueError("If the `request` argument is set, then none of "
                             "the individual field arguments should be set.")

        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest):
            request = conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest(request)

        # If we have keyword arguments corresponding to fields on the
        # request, apply these.
        if name is not None:
            request.name = name

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.delete_conversational_training_assignment]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("name", request.name),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

    async def update_conversational_training_assignment(self,
            request: Optional[Union[gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest, dict]] = None,
            *,
            conversational_training_assignment: Optional[gcd_conversational_training_assignment.ConversationalTrainingAssignment] = None,
            update_mask: Optional[field_mask_pb2.FieldMask] = None,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
        r"""Updates a conversational training assignment.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_update_conversational_training_assignment():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                conversational_training_assignment = dialogflow_v2beta1.ConversationalTrainingAssignment()
                conversational_training_assignment.training_module = "training_module_value"

                request = dialogflow_v2beta1.UpdateConversationalTrainingAssignmentRequest(
                    conversational_training_assignment=conversational_training_assignment,
                )

                # Make the request
                response = await client.update_conversational_training_assignment(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.UpdateConversationalTrainingAssignmentRequest, dict]]):
                The request object. Request of
                UpdateConversationalTrainingAssignment.
                Should only be used by managers to
                prevent directly setting assignment
                progress.
            conversational_training_assignment (:class:`google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment`):
                Required. The conversational training
                assignment to update. The name field of
                conversational training assignment is to
                identify the conversational training
                assignment to update.

                This corresponds to the ``conversational_training_assignment`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            update_mask (:class:`google.protobuf.field_mask_pb2.FieldMask`):
                Optional. The list of fields to
                update.

                This corresponds to the ``update_mask`` field
                on the ``request`` instance; if ``request`` is provided, this
                should not be set.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment:
                A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

        """
        # Create or coerce a protobuf request object.
        # - Quick check: If we got a request object, we should *not* have
        #   gotten any keyword arguments that map to the request.
        flattened_params = [conversational_training_assignment, update_mask]
        has_flattened_params = len([param for param in flattened_params if param is not None]) > 0
        if request is not None and has_flattened_params:
            raise ValueError("If the `request` argument is set, then none of "
                             "the individual field arguments should be set.")

        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest):
            request = gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest(request)

        # If we have keyword arguments corresponding to fields on the
        # request, apply these.
        if conversational_training_assignment is not None:
            request.conversational_training_assignment = conversational_training_assignment
        if update_mask is not None:
            request.update_mask = update_mask

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.update_conversational_training_assignment]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("conversational_training_assignment.name", request.conversational_training_assignment.name),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def finalize_simulation_attempt(self,
            request: Optional[Union[conversational_training_assignment.FinalizeSimulationAttemptRequest, dict]] = None,
            *,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> conversational_training_assignment.ConversationalTrainingAssignment:
        r"""Finalizes a simulation attempt for a conversational
        training assignment. Adding the attempt and saving the
        outcome of the simulation to the assignment.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_finalize_simulation_attempt():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.FinalizeSimulationAttemptRequest(
                    name="name_value",
                    conversation="conversation_value",
                    module_component_uuid="module_component_uuid_value",
                )

                # Make the request
                response = await client.finalize_simulation_attempt(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.FinalizeSimulationAttemptRequest, dict]]):
                The request object. Request message of
                FinalizeSimulationAttempt.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment:
                A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

        """
        # Create or coerce a protobuf request object.
        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.FinalizeSimulationAttemptRequest):
            request = conversational_training_assignment.FinalizeSimulationAttemptRequest(request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.finalize_simulation_attempt]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("name", request.name),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def complete_conversational_training_assignment(self,
            request: Optional[Union[conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest, dict]] = None,
            *,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> conversational_training_assignment.ConversationalTrainingAssignment:
        r"""Marks the conversational training assignment as
        completed.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_complete_conversational_training_assignment():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.CompleteConversationalTrainingAssignmentRequest(
                    name="name_value",
                )

                # Make the request
                response = await client.complete_conversational_training_assignment(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.CompleteConversationalTrainingAssignmentRequest, dict]]):
                The request object. Request message of
                CompleteConversationalTrainingAssignment.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment:
                A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

        """
        # Create or coerce a protobuf request object.
        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest):
            request = conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest(request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.complete_conversational_training_assignment]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("name", request.name),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def batch_create_conversational_training_assignments(self,
            request: Optional[Union[conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest, dict]] = None,
            *,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse:
        r"""Batch creates conversational training assignments.
        Accepts the wildcard '-' as a
        conversationalTrainingMember ID to indicate that the
        assignments should be created for members under a
        specified team.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_batch_create_conversational_training_assignments():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                requests = dialogflow_v2beta1.CreateConversationalTrainingAssignmentRequest()
                requests.parent = "parent_value"
                requests.conversational_training_assignment.training_module = "training_module_value"

                request = dialogflow_v2beta1.BatchCreateConversationalTrainingAssignmentsRequest(
                    parent="parent_value",
                    requests=requests,
                )

                # Make the request
                response = await client.batch_create_conversational_training_assignments(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.BatchCreateConversationalTrainingAssignmentsRequest, dict]]):
                The request object. Request message of
                BatchCreateConversationalTrainingAssignment.

                All individual requests must have the same
                ``batch_uuid``. If no ``batch_uuid`` is provided, a new
                UUID will be generated for the entire batch.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.BatchCreateConversationalTrainingAssignmentsResponse:
                Response message of
                BatchCreateConversationalTrainingAssignment.

        """
        # Create or coerce a protobuf request object.
        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest):
            request = conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest(request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.batch_create_conversational_training_assignments]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("parent", request.parent),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def batch_delete_conversational_training_assignments(self,
            request: Optional[Union[conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest, dict]] = None,
            *,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> None:
        r"""Batch deletes conversational training assignments.
        Accepts the wildcard '-' as a
        conversationalTrainingMember ID to indicate that the
        assignments should be deleted for members under a
        specified team.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_batch_delete_conversational_training_assignments():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                request = dialogflow_v2beta1.BatchDeleteConversationalTrainingAssignmentsRequest(
                    parent="parent_value",
                    names=['names_value1', 'names_value2'],
                )

                # Make the request
                await client.batch_delete_conversational_training_assignments(request=request)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.BatchDeleteConversationalTrainingAssignmentsRequest, dict]]):
                The request object. Request message of
                BatchDeleteConversationalTrainingAssignment.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        """
        # Create or coerce a protobuf request object.
        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest):
            request = conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest(request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.batch_delete_conversational_training_assignments]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("parent", request.parent),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

    async def batch_update_conversational_training_assignments(self,
            request: Optional[Union[conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest, dict]] = None,
            *,
            retry: OptionalRetry = gapic_v1.method.DEFAULT,
            timeout: Union[float, object] = gapic_v1.method.DEFAULT,
            metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
            ) -> conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse:
        r"""Batch updates conversational training assignments.
        Accepts the wildcard '-' as a
        conversationalTrainingMember ID to indicate that the
        assignments should be updated for members under a
        specified team.

        .. code-block:: python

            # This snippet has been automatically generated and should be regarded as a
            # code template only.
            # It will require modifications to work:
            # - It may require correct/in-range values for request initialization.
            # - It may require specifying regional endpoints when creating the service
            #   client as shown in:
            #   https://googleapis.dev/python/google-api-core/latest/client_options.html
            from google.cloud import dialogflow_v2beta1

            async def sample_batch_update_conversational_training_assignments():
                # Create a client
                client = dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient()

                # Initialize request argument(s)
                requests = dialogflow_v2beta1.UpdateConversationalTrainingAssignmentRequest()
                requests.conversational_training_assignment.training_module = "training_module_value"

                request = dialogflow_v2beta1.BatchUpdateConversationalTrainingAssignmentsRequest(
                    parent="parent_value",
                    requests=requests,
                )

                # Make the request
                response = await client.batch_update_conversational_training_assignments(request=request)

                # Handle the response
                print(response)

        Args:
            request (Optional[Union[google.cloud.dialogflow_v2beta1.types.BatchUpdateConversationalTrainingAssignmentsRequest, dict]]):
                The request object. Request message of
                BatchUpdateConversationalTrainingAssignment.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors, if any,
                should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.

        Returns:
            google.cloud.dialogflow_v2beta1.types.BatchUpdateConversationalTrainingAssignmentsResponse:
                Response message of
                BatchUpdateConversationalTrainingAssignment.

        """
        # Create or coerce a protobuf request object.
        # - Use the request object if provided (there's no risk of modifying the input as
        #   there are no flattened fields), or create one.
        if not isinstance(request, conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest):
            request = conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest(request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self._client._transport._wrapped_methods[self._client._transport.batch_update_conversational_training_assignments]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ("parent", request.parent),
            )),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request,
            retry=retry,
            timeout=timeout,
            metadata=metadata,
        )

        # Done; return the response.
        return response

    async def list_operations(
        self,
        request: Optional[operations_pb2.ListOperationsRequest] = None,
        *,
        retry: OptionalRetry = gapic_v1.method.DEFAULT,
        timeout: Union[float, object] = gapic_v1.method.DEFAULT,
        metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
    ) -> operations_pb2.ListOperationsResponse:
        r"""Lists operations that match the specified filter in the request.

        Args:
            request (:class:`~.operations_pb2.ListOperationsRequest`):
                The request object. Request message for
                `ListOperations` method.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors,
                    if any, should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        Returns:
            ~.operations_pb2.ListOperationsResponse:
                Response message for ``ListOperations`` method.
        """
        # Create or coerce a protobuf request object.
        # The request isn't a proto-plus wrapped type,
        # so it must be constructed via keyword expansion.
        if isinstance(request, dict):
            request = operations_pb2.ListOperationsRequest(**request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self.transport._wrapped_methods[self._client._transport.list_operations]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata(
                (("name", request.name),)),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request, retry=retry, timeout=timeout, metadata=metadata,)

        # Done; return the response.
        return response

    async def get_operation(
        self,
        request: Optional[operations_pb2.GetOperationRequest] = None,
        *,
        retry: OptionalRetry = gapic_v1.method.DEFAULT,
        timeout: Union[float, object] = gapic_v1.method.DEFAULT,
        metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
    ) -> operations_pb2.Operation:
        r"""Gets the latest state of a long-running operation.

        Args:
            request (:class:`~.operations_pb2.GetOperationRequest`):
                The request object. Request message for
                `GetOperation` method.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors,
                    if any, should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        Returns:
            ~.operations_pb2.Operation:
                An ``Operation`` object.
        """
        # Create or coerce a protobuf request object.
        # The request isn't a proto-plus wrapped type,
        # so it must be constructed via keyword expansion.
        if isinstance(request, dict):
            request = operations_pb2.GetOperationRequest(**request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self.transport._wrapped_methods[self._client._transport.get_operation]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata(
                (("name", request.name),)),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request, retry=retry, timeout=timeout, metadata=metadata,)

        # Done; return the response.
        return response

    async def cancel_operation(
        self,
        request: Optional[operations_pb2.CancelOperationRequest] = None,
        *,
        retry: OptionalRetry = gapic_v1.method.DEFAULT,
        timeout: Union[float, object] = gapic_v1.method.DEFAULT,
        metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
    ) -> None:
        r"""Starts asynchronous cancellation on a long-running operation.

        The server makes a best effort to cancel the operation, but success
        is not guaranteed.  If the server doesn't support this method, it returns
        `google.rpc.Code.UNIMPLEMENTED`.

        Args:
            request (:class:`~.operations_pb2.CancelOperationRequest`):
                The request object. Request message for
                `CancelOperation` method.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors,
                    if any, should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        Returns:
            None
        """
        # Create or coerce a protobuf request object.
        # The request isn't a proto-plus wrapped type,
        # so it must be constructed via keyword expansion.
        if isinstance(request, dict):
            request = operations_pb2.CancelOperationRequest(**request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self.transport._wrapped_methods[self._client._transport.cancel_operation]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata(
                (("name", request.name),)),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        await rpc(request, retry=retry, timeout=timeout, metadata=metadata,)

    async def get_location(
        self,
        request: Optional[locations_pb2.GetLocationRequest] = None,
        *,
        retry: OptionalRetry = gapic_v1.method.DEFAULT,
        timeout: Union[float, object] = gapic_v1.method.DEFAULT,
        metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
    ) -> locations_pb2.Location:
        r"""Gets information about a location.

        Args:
            request (:class:`~.location_pb2.GetLocationRequest`):
                The request object. Request message for
                `GetLocation` method.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors,
                 if any, should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        Returns:
            ~.location_pb2.Location:
                Location object.
        """
        # Create or coerce a protobuf request object.
        # The request isn't a proto-plus wrapped type,
        # so it must be constructed via keyword expansion.
        if isinstance(request, dict):
            request = locations_pb2.GetLocationRequest(**request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self.transport._wrapped_methods[self._client._transport.get_location]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata(
                (("name", request.name),)),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request, retry=retry, timeout=timeout, metadata=metadata,)

        # Done; return the response.
        return response

    async def list_locations(
        self,
        request: Optional[locations_pb2.ListLocationsRequest] = None,
        *,
        retry: OptionalRetry = gapic_v1.method.DEFAULT,
        timeout: Union[float, object] = gapic_v1.method.DEFAULT,
        metadata: Sequence[Tuple[str, Union[str, bytes]]] = (),
    ) -> locations_pb2.ListLocationsResponse:
        r"""Lists information about the supported locations for this service.

        Args:
            request (:class:`~.location_pb2.ListLocationsRequest`):
                The request object. Request message for
                `ListLocations` method.
            retry (google.api_core.retry_async.AsyncRetry): Designation of what errors,
                 if any, should be retried.
            timeout (float): The timeout for this request.
            metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                sent along with the request as metadata. Normally, each value must be of type `str`,
                but for metadata keys ending with the suffix `-bin`, the corresponding values must
                be of type `bytes`.
        Returns:
            ~.location_pb2.ListLocationsResponse:
                Response message for ``ListLocations`` method.
        """
        # Create or coerce a protobuf request object.
        # The request isn't a proto-plus wrapped type,
        # so it must be constructed via keyword expansion.
        if isinstance(request, dict):
            request = locations_pb2.ListLocationsRequest(**request)

        # Wrap the RPC method; this adds retry and timeout information,
        # and friendly error handling.
        rpc = self.transport._wrapped_methods[self._client._transport.list_locations]

        # Certain fields should be provided within the metadata header;
        # add these here.
        metadata = tuple(metadata) + (
            gapic_v1.routing_header.to_grpc_metadata(
                (("name", request.name),)),
        )

        # Validate the universe domain.
        self._client._validate_universe_domain()

        # Send the request.
        response = await rpc(
            request, retry=retry, timeout=timeout, metadata=metadata,)

        # Done; return the response.
        return response

    async def __aenter__(self) -> "ConversationalTrainingAssignmentsAsyncClient":
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.transport.close()

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(gapic_version=package_version.__version__)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):   # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


__all__ = (
    "ConversationalTrainingAssignmentsAsyncClient",
)
