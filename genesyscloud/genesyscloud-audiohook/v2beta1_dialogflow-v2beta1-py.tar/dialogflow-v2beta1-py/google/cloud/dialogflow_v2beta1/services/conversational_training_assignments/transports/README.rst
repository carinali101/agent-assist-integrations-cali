
transport inheritance structure
_______________________________

`ConversationalTrainingAssignmentsTransport` is the ABC for all transports.
- public child `ConversationalTrainingAssignmentsGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `ConversationalTrainingAssignmentsGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BaseConversationalTrainingAssignmentsRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `ConversationalTrainingAssignmentsRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
