
transport inheritance structure
_______________________________

`SupervisorAssignmentServiceTransport` is the ABC for all transports.
- public child `SupervisorAssignmentServiceGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `SupervisorAssignmentServiceGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BaseSupervisorAssignmentServiceRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `SupervisorAssignmentServiceRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
