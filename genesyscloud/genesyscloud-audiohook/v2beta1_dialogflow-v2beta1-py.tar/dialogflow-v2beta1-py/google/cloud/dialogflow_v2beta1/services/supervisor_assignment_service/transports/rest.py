# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1
import google.protobuf

from google.protobuf import json_format
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v2beta1.types import supervisor_assignment_service
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseSupervisorAssignmentServiceRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class SupervisorAssignmentServiceRestInterceptor:
    """Interceptor for SupervisorAssignmentService.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the SupervisorAssignmentServiceRestTransport.

    .. code-block:: python
        class MyCustomSupervisorAssignmentServiceInterceptor(SupervisorAssignmentServiceRestInterceptor):
            def pre_assign_supervisor(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_assign_supervisor(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_create_supervisor(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_supervisor(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_supervisor(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_list_conversation_assignments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_conversation_assignments(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_supervisors(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_supervisors(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_update_supervisor_status(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_update_supervisor_status(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = SupervisorAssignmentServiceRestTransport(interceptor=MyCustomSupervisorAssignmentServiceInterceptor())
        client = SupervisorAssignmentServiceClient(transport=transport)


    """
    def pre_assign_supervisor(self, request: supervisor_assignment_service.AssignSupervisorRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.AssignSupervisorRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for assign_supervisor

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_assign_supervisor(self, response: supervisor_assignment_service.AssignSupervisorResponse) -> supervisor_assignment_service.AssignSupervisorResponse:
        """Post-rpc interceptor for assign_supervisor

        DEPRECATED. Please use the `post_assign_supervisor_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code. This `post_assign_supervisor` interceptor runs
        before the `post_assign_supervisor_with_metadata` interceptor.
        """
        return response

    def post_assign_supervisor_with_metadata(self, response: supervisor_assignment_service.AssignSupervisorResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.AssignSupervisorResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for assign_supervisor

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the SupervisorAssignmentService server but before it is returned to user code.

        We recommend only using this `post_assign_supervisor_with_metadata`
        interceptor in new development instead of the `post_assign_supervisor` interceptor.
        When both interceptors are used, this `post_assign_supervisor_with_metadata` interceptor runs after the
        `post_assign_supervisor` interceptor. The (possibly modified) response returned by
        `post_assign_supervisor` will be passed to
        `post_assign_supervisor_with_metadata`.
        """
        return response, metadata

    def pre_create_supervisor(self, request: supervisor_assignment_service.CreateSupervisorRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.CreateSupervisorRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_supervisor

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_create_supervisor(self, response: supervisor_assignment_service.Supervisor) -> supervisor_assignment_service.Supervisor:
        """Post-rpc interceptor for create_supervisor

        DEPRECATED. Please use the `post_create_supervisor_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code. This `post_create_supervisor` interceptor runs
        before the `post_create_supervisor_with_metadata` interceptor.
        """
        return response

    def post_create_supervisor_with_metadata(self, response: supervisor_assignment_service.Supervisor, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.Supervisor, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_supervisor

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the SupervisorAssignmentService server but before it is returned to user code.

        We recommend only using this `post_create_supervisor_with_metadata`
        interceptor in new development instead of the `post_create_supervisor` interceptor.
        When both interceptors are used, this `post_create_supervisor_with_metadata` interceptor runs after the
        `post_create_supervisor` interceptor. The (possibly modified) response returned by
        `post_create_supervisor` will be passed to
        `post_create_supervisor_with_metadata`.
        """
        return response, metadata

    def pre_delete_supervisor(self, request: supervisor_assignment_service.DeleteSupervisorRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.DeleteSupervisorRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_supervisor

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def pre_list_conversation_assignments(self, request: supervisor_assignment_service.ListConversationAssignmentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.ListConversationAssignmentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_conversation_assignments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_list_conversation_assignments(self, response: supervisor_assignment_service.ListConversationAssignmentsResponse) -> supervisor_assignment_service.ListConversationAssignmentsResponse:
        """Post-rpc interceptor for list_conversation_assignments

        DEPRECATED. Please use the `post_list_conversation_assignments_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code. This `post_list_conversation_assignments` interceptor runs
        before the `post_list_conversation_assignments_with_metadata` interceptor.
        """
        return response

    def post_list_conversation_assignments_with_metadata(self, response: supervisor_assignment_service.ListConversationAssignmentsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.ListConversationAssignmentsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_conversation_assignments

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the SupervisorAssignmentService server but before it is returned to user code.

        We recommend only using this `post_list_conversation_assignments_with_metadata`
        interceptor in new development instead of the `post_list_conversation_assignments` interceptor.
        When both interceptors are used, this `post_list_conversation_assignments_with_metadata` interceptor runs after the
        `post_list_conversation_assignments` interceptor. The (possibly modified) response returned by
        `post_list_conversation_assignments` will be passed to
        `post_list_conversation_assignments_with_metadata`.
        """
        return response, metadata

    def pre_list_supervisors(self, request: supervisor_assignment_service.ListSupervisorsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.ListSupervisorsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_supervisors

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_list_supervisors(self, response: supervisor_assignment_service.ListSupervisorsResponse) -> supervisor_assignment_service.ListSupervisorsResponse:
        """Post-rpc interceptor for list_supervisors

        DEPRECATED. Please use the `post_list_supervisors_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code. This `post_list_supervisors` interceptor runs
        before the `post_list_supervisors_with_metadata` interceptor.
        """
        return response

    def post_list_supervisors_with_metadata(self, response: supervisor_assignment_service.ListSupervisorsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.ListSupervisorsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_supervisors

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the SupervisorAssignmentService server but before it is returned to user code.

        We recommend only using this `post_list_supervisors_with_metadata`
        interceptor in new development instead of the `post_list_supervisors` interceptor.
        When both interceptors are used, this `post_list_supervisors_with_metadata` interceptor runs after the
        `post_list_supervisors` interceptor. The (possibly modified) response returned by
        `post_list_supervisors` will be passed to
        `post_list_supervisors_with_metadata`.
        """
        return response, metadata

    def pre_update_supervisor_status(self, request: supervisor_assignment_service.UpdateSupervisorStatusRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.UpdateSupervisorStatusRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for update_supervisor_status

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_update_supervisor_status(self, response: supervisor_assignment_service.SupervisorStatus) -> supervisor_assignment_service.SupervisorStatus:
        """Post-rpc interceptor for update_supervisor_status

        DEPRECATED. Please use the `post_update_supervisor_status_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code. This `post_update_supervisor_status` interceptor runs
        before the `post_update_supervisor_status_with_metadata` interceptor.
        """
        return response

    def post_update_supervisor_status_with_metadata(self, response: supervisor_assignment_service.SupervisorStatus, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[supervisor_assignment_service.SupervisorStatus, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for update_supervisor_status

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the SupervisorAssignmentService server but before it is returned to user code.

        We recommend only using this `post_update_supervisor_status_with_metadata`
        interceptor in new development instead of the `post_update_supervisor_status` interceptor.
        When both interceptors are used, this `post_update_supervisor_status_with_metadata` interceptor runs after the
        `post_update_supervisor_status` interceptor. The (possibly modified) response returned by
        `post_update_supervisor_status` will be passed to
        `post_update_supervisor_status_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the SupervisorAssignmentService server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the SupervisorAssignmentService server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class SupervisorAssignmentServiceRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: SupervisorAssignmentServiceRestInterceptor


class SupervisorAssignmentServiceRestTransport(_BaseSupervisorAssignmentServiceRestTransport):
    """REST backend synchronous transport for SupervisorAssignmentService.

    Service for managing supervisors and their assignments.

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[SupervisorAssignmentServiceRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided. This argument will be
                removed in the next major version of this library.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or SupervisorAssignmentServiceRestInterceptor()
        self._prep_wrapped_messages(client_info)

    class _AssignSupervisor(_BaseSupervisorAssignmentServiceRestTransport._BaseAssignSupervisor, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.AssignSupervisor")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.AssignSupervisorRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> supervisor_assignment_service.AssignSupervisorResponse:
            r"""Call the assign supervisor method over HTTP.

            Args:
                request (~.supervisor_assignment_service.AssignSupervisorRequest):
                    The request object. Request message for AssignSupervisor.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.supervisor_assignment_service.AssignSupervisorResponse:
                    Response message for
                AssignSupervisor.

            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseAssignSupervisor._get_http_options()

            request, metadata = self._interceptor.pre_assign_supervisor(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseAssignSupervisor._get_transcoded_request(http_options, request)

            body = _BaseSupervisorAssignmentServiceRestTransport._BaseAssignSupervisor._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseAssignSupervisor._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.AssignSupervisor",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "AssignSupervisor",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._AssignSupervisor._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = supervisor_assignment_service.AssignSupervisorResponse()
            pb_resp = supervisor_assignment_service.AssignSupervisorResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_assign_supervisor(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_assign_supervisor_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = supervisor_assignment_service.AssignSupervisorResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.assign_supervisor",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "AssignSupervisor",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CreateSupervisor(_BaseSupervisorAssignmentServiceRestTransport._BaseCreateSupervisor, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.CreateSupervisor")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.CreateSupervisorRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> supervisor_assignment_service.Supervisor:
            r"""Call the create supervisor method over HTTP.

            Args:
                request (~.supervisor_assignment_service.CreateSupervisorRequest):
                    The request object. Request message for CreateSupervisor.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.supervisor_assignment_service.Supervisor:
                    Represents a supervisor.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseCreateSupervisor._get_http_options()

            request, metadata = self._interceptor.pre_create_supervisor(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseCreateSupervisor._get_transcoded_request(http_options, request)

            body = _BaseSupervisorAssignmentServiceRestTransport._BaseCreateSupervisor._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseCreateSupervisor._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.CreateSupervisor",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "CreateSupervisor",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._CreateSupervisor._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = supervisor_assignment_service.Supervisor()
            pb_resp = supervisor_assignment_service.Supervisor.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_supervisor(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_supervisor_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = supervisor_assignment_service.Supervisor.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.create_supervisor",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "CreateSupervisor",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteSupervisor(_BaseSupervisorAssignmentServiceRestTransport._BaseDeleteSupervisor, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.DeleteSupervisor")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.DeleteSupervisorRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete supervisor method over HTTP.

            Args:
                request (~.supervisor_assignment_service.DeleteSupervisorRequest):
                    The request object. Request message for DeleteSupervisor.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseDeleteSupervisor._get_http_options()

            request, metadata = self._interceptor.pre_delete_supervisor(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseDeleteSupervisor._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseDeleteSupervisor._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.DeleteSupervisor",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "DeleteSupervisor",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._DeleteSupervisor._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _ListConversationAssignments(_BaseSupervisorAssignmentServiceRestTransport._BaseListConversationAssignments, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.ListConversationAssignments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.ListConversationAssignmentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> supervisor_assignment_service.ListConversationAssignmentsResponse:
            r"""Call the list conversation
        assignments method over HTTP.

            Args:
                request (~.supervisor_assignment_service.ListConversationAssignmentsRequest):
                    The request object. Request message for
                ListConversationAssignments.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.supervisor_assignment_service.ListConversationAssignmentsResponse:
                    Response message for
                ListConversationAssignments.

            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseListConversationAssignments._get_http_options()

            request, metadata = self._interceptor.pre_list_conversation_assignments(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseListConversationAssignments._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseListConversationAssignments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.ListConversationAssignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListConversationAssignments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._ListConversationAssignments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = supervisor_assignment_service.ListConversationAssignmentsResponse()
            pb_resp = supervisor_assignment_service.ListConversationAssignmentsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_conversation_assignments(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_conversation_assignments_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = supervisor_assignment_service.ListConversationAssignmentsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.list_conversation_assignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListConversationAssignments",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListSupervisors(_BaseSupervisorAssignmentServiceRestTransport._BaseListSupervisors, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.ListSupervisors")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.ListSupervisorsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> supervisor_assignment_service.ListSupervisorsResponse:
            r"""Call the list supervisors method over HTTP.

            Args:
                request (~.supervisor_assignment_service.ListSupervisorsRequest):
                    The request object. Request message for ListSupervisors.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.supervisor_assignment_service.ListSupervisorsResponse:
                    Response message for ListSupervisors.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseListSupervisors._get_http_options()

            request, metadata = self._interceptor.pre_list_supervisors(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseListSupervisors._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseListSupervisors._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.ListSupervisors",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListSupervisors",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._ListSupervisors._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = supervisor_assignment_service.ListSupervisorsResponse()
            pb_resp = supervisor_assignment_service.ListSupervisorsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_supervisors(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_supervisors_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = supervisor_assignment_service.ListSupervisorsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.list_supervisors",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListSupervisors",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _UpdateSupervisorStatus(_BaseSupervisorAssignmentServiceRestTransport._BaseUpdateSupervisorStatus, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.UpdateSupervisorStatus")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: supervisor_assignment_service.UpdateSupervisorStatusRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> supervisor_assignment_service.SupervisorStatus:
            r"""Call the update supervisor status method over HTTP.

            Args:
                request (~.supervisor_assignment_service.UpdateSupervisorStatusRequest):
                    The request object. Request message for
                UpdateSupervisorStatus.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.supervisor_assignment_service.SupervisorStatus:
                    Represents the status of a
                supervisor.

            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseUpdateSupervisorStatus._get_http_options()

            request, metadata = self._interceptor.pre_update_supervisor_status(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseUpdateSupervisorStatus._get_transcoded_request(http_options, request)

            body = _BaseSupervisorAssignmentServiceRestTransport._BaseUpdateSupervisorStatus._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseUpdateSupervisorStatus._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.UpdateSupervisorStatus",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "UpdateSupervisorStatus",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._UpdateSupervisorStatus._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = supervisor_assignment_service.SupervisorStatus()
            pb_resp = supervisor_assignment_service.SupervisorStatus.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_update_supervisor_status(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_update_supervisor_status_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = supervisor_assignment_service.SupervisorStatus.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.update_supervisor_status",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "UpdateSupervisorStatus",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def assign_supervisor(self) -> Callable[
            [supervisor_assignment_service.AssignSupervisorRequest],
            supervisor_assignment_service.AssignSupervisorResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._AssignSupervisor(self._session, self._host, self._interceptor) # type: ignore

    @property
    def create_supervisor(self) -> Callable[
            [supervisor_assignment_service.CreateSupervisorRequest],
            supervisor_assignment_service.Supervisor]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateSupervisor(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_supervisor(self) -> Callable[
            [supervisor_assignment_service.DeleteSupervisorRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteSupervisor(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_conversation_assignments(self) -> Callable[
            [supervisor_assignment_service.ListConversationAssignmentsRequest],
            supervisor_assignment_service.ListConversationAssignmentsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListConversationAssignments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_supervisors(self) -> Callable[
            [supervisor_assignment_service.ListSupervisorsRequest],
            supervisor_assignment_service.ListSupervisorsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListSupervisors(self._session, self._host, self._interceptor) # type: ignore

    @property
    def update_supervisor_status(self) -> Callable[
            [supervisor_assignment_service.UpdateSupervisorStatusRequest],
            supervisor_assignment_service.SupervisorStatus]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._UpdateSupervisorStatus(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseSupervisorAssignmentServiceRestTransport._BaseGetLocation, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseSupervisorAssignmentServiceRestTransport._BaseListLocations, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseSupervisorAssignmentServiceRestTransport._BaseCancelOperation, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseSupervisorAssignmentServiceRestTransport._BaseGetOperation, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseSupervisorAssignmentServiceRestTransport._BaseListOperations, SupervisorAssignmentServiceRestStub):
        def __hash__(self):
            return hash("SupervisorAssignmentServiceRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseSupervisorAssignmentServiceRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseSupervisorAssignmentServiceRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseSupervisorAssignmentServiceRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = SupervisorAssignmentServiceRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.SupervisorAssignmentServiceAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.SupervisorAssignmentService",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'SupervisorAssignmentServiceRestTransport',
)
