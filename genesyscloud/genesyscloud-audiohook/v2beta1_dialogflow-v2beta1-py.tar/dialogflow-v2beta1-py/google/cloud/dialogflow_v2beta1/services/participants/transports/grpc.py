# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import json
import logging as std_logging
import pickle
import warnings
from typing import Callable, Dict, Optional, Sequence, Tuple, Union

from google.api_core import grpc_helpers
from google.api_core import gapic_v1
import google.auth                         # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.auth.transport.grpc import SslCredentials  # type: ignore
from google.protobuf.json_format import MessageToJson
import google.protobuf.message

import grpc  # type: ignore
import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import participant
from google.cloud.dialogflow_v2beta1.types import participant as gcd_participant
from google.cloud.location import locations_pb2 # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from .base import ParticipantsTransport, DEFAULT_CLIENT_INFO

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = std_logging.getLogger(__name__)


class _LoggingClientInterceptor(grpc.UnaryUnaryClientInterceptor):  # pragma: NO COVER
    def intercept_unary_unary(self, continuation, client_call_details, request):
        logging_enabled = CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(std_logging.DEBUG)
        if logging_enabled:  # pragma: NO COVER
            request_metadata = client_call_details.metadata
            if isinstance(request, proto.Message):
                request_payload = type(request).to_json(request)
            elif isinstance(request, google.protobuf.message.Message):
                request_payload = MessageToJson(request)
            else:
                request_payload = f"{type(request).__name__}: {pickle.dumps(request)}"

            request_metadata = {
                key: value.decode("utf-8") if isinstance(value, bytes) else value
                for key, value in request_metadata
            }
            grpc_request = {
                "payload": request_payload,
                "requestMethod": "grpc",
                "metadata": dict(request_metadata),
            }
            _LOGGER.debug(
                f"Sending request for {client_call_details.method}",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.Participants",
                    "rpcName": str(client_call_details.method),
                    "request": grpc_request,
                    "metadata": grpc_request["metadata"],
                },
            )
        response = continuation(client_call_details, request)
        if logging_enabled:  # pragma: NO COVER
            response_metadata = response.trailing_metadata()
            # Convert gRPC metadata `<class 'grpc.aio._metadata.Metadata'>` to list of tuples
            metadata = dict([(k, str(v)) for k, v in response_metadata]) if response_metadata else None
            result = response.result()
            if isinstance(result, proto.Message):
                response_payload = type(result).to_json(result)
            elif isinstance(result, google.protobuf.message.Message):
                response_payload = MessageToJson(result)
            else:
                response_payload = f"{type(result).__name__}: {pickle.dumps(result)}"
            grpc_response = {
                "payload": response_payload,
                "metadata": metadata,
                "status": "OK",
            }
            _LOGGER.debug(
                f"Received response for {client_call_details.method}.",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.Participants",
                    "rpcName": client_call_details.method,
                    "response": grpc_response,
                    "metadata": grpc_response["metadata"],
                },
            )
        return response


class ParticipantsGrpcTransport(ParticipantsTransport):
    """gRPC backend transport for Participants.

    Service for managing
    [Participants][google.cloud.dialogflow.v2beta1.Participant].

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends protocol buffers over the wire using gRPC (which is built on
    top of HTTP/2); the ``grpcio`` package must be installed.
    """
    _stubs: Dict[str, Callable]

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            channel: Optional[Union[grpc.Channel, Callable[..., grpc.Channel]]] = None,
            api_mtls_endpoint: Optional[str] = None,
            client_cert_source: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            ssl_channel_credentials: Optional[grpc.ChannelCredentials] = None,
            client_cert_source_for_mtls: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
                This argument is ignored if a ``channel`` instance is provided.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if a ``channel`` instance is provided.
                This argument will be removed in the next major version of this library.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if a ``channel`` instance is provided.
            channel (Optional[Union[grpc.Channel, Callable[..., grpc.Channel]]]):
                A ``Channel`` instance through which to make calls, or a Callable
                that constructs and returns one. If set to None, ``self.create_channel``
                is used to create the channel. If a Callable is given, it will be called
                with the same arguments as used in ``self.create_channel``.
            api_mtls_endpoint (Optional[str]): Deprecated. The mutual TLS endpoint.
                If provided, it overrides the ``host`` argument and tries to create
                a mutual TLS channel with client SSL credentials from
                ``client_cert_source`` or application default SSL credentials.
            client_cert_source (Optional[Callable[[], Tuple[bytes, bytes]]]):
                Deprecated. A callback to provide client SSL certificate bytes and
                private key bytes, both in PEM format. It is ignored if
                ``api_mtls_endpoint`` is None.
            ssl_channel_credentials (grpc.ChannelCredentials): SSL credentials
                for the grpc channel. It is ignored if a ``channel`` instance is provided.
            client_cert_source_for_mtls (Optional[Callable[[], Tuple[bytes, bytes]]]):
                A callback to provide client certificate bytes and private key bytes,
                both in PEM format. It is used to configure a mutual TLS channel. It is
                ignored if a ``channel`` instance or ``ssl_channel_credentials`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.

        Raises:
          google.auth.exceptions.MutualTLSChannelError: If mutual TLS transport
              creation failed for any reason.
          google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """
        self._grpc_channel = None
        self._ssl_channel_credentials = ssl_channel_credentials
        self._stubs: Dict[str, Callable] = {}

        if api_mtls_endpoint:
            warnings.warn("api_mtls_endpoint is deprecated", DeprecationWarning)
        if client_cert_source:
            warnings.warn("client_cert_source is deprecated", DeprecationWarning)

        if isinstance(channel, grpc.Channel):
            # Ignore credentials if a channel was passed.
            credentials = None
            self._ignore_credentials = True
            # If a channel was explicitly provided, set it.
            self._grpc_channel = channel
            self._ssl_channel_credentials = None

        else:
            if api_mtls_endpoint:
                host = api_mtls_endpoint

                # Create SSL credentials with client_cert_source or application
                # default SSL credentials.
                if client_cert_source:
                    cert, key = client_cert_source()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )
                else:
                    self._ssl_channel_credentials = SslCredentials().ssl_credentials

            else:
                if client_cert_source_for_mtls and not ssl_channel_credentials:
                    cert, key = client_cert_source_for_mtls()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )

        # The base transport sets the host, credentials and scopes
        super().__init__(
            host=host,
            credentials=credentials,
            credentials_file=credentials_file,
            scopes=scopes,
            quota_project_id=quota_project_id,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            api_audience=api_audience,
        )

        if not self._grpc_channel:
            # initialize with the provided callable or the default channel
            channel_init = channel or type(self).create_channel
            self._grpc_channel = channel_init(
                self._host,
                # use the credentials which are saved
                credentials=self._credentials,
                # Set ``credentials_file`` to ``None`` here as
                # the credentials that we saved earlier should be used.
                credentials_file=None,
                scopes=self._scopes,
                ssl_credentials=self._ssl_channel_credentials,
                quota_project_id=quota_project_id,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )

        self._interceptor = _LoggingClientInterceptor()
        self._logged_channel =  grpc.intercept_channel(self._grpc_channel, self._interceptor)

        # Wrap messages. This must be done after self._logged_channel exists
        self._prep_wrapped_messages(client_info)

    @classmethod
    def create_channel(cls,
                       host: str = 'dialogflow.googleapis.com',
                       credentials: Optional[ga_credentials.Credentials] = None,
                       credentials_file: Optional[str] = None,
                       scopes: Optional[Sequence[str]] = None,
                       quota_project_id: Optional[str] = None,
                       **kwargs) -> grpc.Channel:
        """Create and return a gRPC channel object.
        Args:
            host (Optional[str]): The host for the channel to use.
            credentials (Optional[~.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify this application to the service. If
                none are specified, the client will attempt to ascertain
                the credentials from the environment.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is mutually exclusive with credentials.  This argument will be
                removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            kwargs (Optional[dict]): Keyword arguments, which are passed to the
                channel creation.
        Returns:
            grpc.Channel: A gRPC channel object.

        Raises:
            google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """

        return grpc_helpers.create_channel(
            host,
            credentials=credentials,
            credentials_file=credentials_file,
            quota_project_id=quota_project_id,
            default_scopes=cls.AUTH_SCOPES,
            scopes=scopes,
            default_host=cls.DEFAULT_HOST,
            **kwargs
        )

    @property
    def grpc_channel(self) -> grpc.Channel:
        """Return the channel designed to connect to this service.
        """
        return self._grpc_channel

    @property
    def create_participant(self) -> Callable[
            [gcd_participant.CreateParticipantRequest],
            gcd_participant.Participant]:
        r"""Return a callable for the create participant method over gRPC.

        Creates a new participant in a conversation.

        Returns:
            Callable[[~.CreateParticipantRequest],
                    ~.Participant]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'create_participant' not in self._stubs:
            self._stubs['create_participant'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/CreateParticipant',
                request_serializer=gcd_participant.CreateParticipantRequest.serialize,
                response_deserializer=gcd_participant.Participant.deserialize,
            )
        return self._stubs['create_participant']

    @property
    def get_participant(self) -> Callable[
            [participant.GetParticipantRequest],
            participant.Participant]:
        r"""Return a callable for the get participant method over gRPC.

        Retrieves a conversation participant.

        Returns:
            Callable[[~.GetParticipantRequest],
                    ~.Participant]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_participant' not in self._stubs:
            self._stubs['get_participant'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/GetParticipant',
                request_serializer=participant.GetParticipantRequest.serialize,
                response_deserializer=participant.Participant.deserialize,
            )
        return self._stubs['get_participant']

    @property
    def list_participants(self) -> Callable[
            [participant.ListParticipantsRequest],
            participant.ListParticipantsResponse]:
        r"""Return a callable for the list participants method over gRPC.

        Returns the list of all participants in the specified
        conversation.

        Returns:
            Callable[[~.ListParticipantsRequest],
                    ~.ListParticipantsResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_participants' not in self._stubs:
            self._stubs['list_participants'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/ListParticipants',
                request_serializer=participant.ListParticipantsRequest.serialize,
                response_deserializer=participant.ListParticipantsResponse.deserialize,
            )
        return self._stubs['list_participants']

    @property
    def update_participant(self) -> Callable[
            [gcd_participant.UpdateParticipantRequest],
            gcd_participant.Participant]:
        r"""Return a callable for the update participant method over gRPC.

        Updates the specified participant.

        Returns:
            Callable[[~.UpdateParticipantRequest],
                    ~.Participant]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'update_participant' not in self._stubs:
            self._stubs['update_participant'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/UpdateParticipant',
                request_serializer=gcd_participant.UpdateParticipantRequest.serialize,
                response_deserializer=gcd_participant.Participant.deserialize,
            )
        return self._stubs['update_participant']

    @property
    def analyze_content(self) -> Callable[
            [gcd_participant.AnalyzeContentRequest],
            gcd_participant.AnalyzeContentResponse]:
        r"""Return a callable for the analyze content method over gRPC.

        Adds a text (chat, for example), or audio (phone recording, for
        example) message from a participant into the conversation.

        Note: Always use agent versions for production traffic sent to
        virtual agents. See `Versions and
        environments <https://cloud.google.com/dialogflow/es/docs/agents-versions>`__.

        Returns:
            Callable[[~.AnalyzeContentRequest],
                    ~.AnalyzeContentResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'analyze_content' not in self._stubs:
            self._stubs['analyze_content'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/AnalyzeContent',
                request_serializer=gcd_participant.AnalyzeContentRequest.serialize,
                response_deserializer=gcd_participant.AnalyzeContentResponse.deserialize,
            )
        return self._stubs['analyze_content']

    @property
    def streaming_analyze_content(self) -> Callable[
            [participant.StreamingAnalyzeContentRequest],
            participant.StreamingAnalyzeContentResponse]:
        r"""Return a callable for the streaming analyze content method over gRPC.

        Adds a text (e.g., chat) or audio (e.g., phone recording)
        message from a participant into the conversation. Note: This
        method is only available through the gRPC API (not REST).

        The top-level message sent to the client by the server is
        ``StreamingAnalyzeContentResponse``. Multiple response messages
        can be returned in order. The first one or more messages contain
        the ``recognition_result`` field. Each result represents a more
        complete transcript of what the user said. The next message
        contains the ``reply_text`` field, and potentially the
        ``reply_audio`` and/or the ``automated_agent_reply`` fields.

        Note: Always use agent versions for production traffic sent to
        virtual agents. See `Versions and
        environments <https://cloud.google.com/dialogflow/es/docs/agents-versions>`__.

        Returns:
            Callable[[~.StreamingAnalyzeContentRequest],
                    ~.StreamingAnalyzeContentResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'streaming_analyze_content' not in self._stubs:
            self._stubs['streaming_analyze_content'] = self._logged_channel.stream_stream(
                '/google.cloud.dialogflow.v2beta1.Participants/StreamingAnalyzeContent',
                request_serializer=participant.StreamingAnalyzeContentRequest.serialize,
                response_deserializer=participant.StreamingAnalyzeContentResponse.deserialize,
            )
        return self._stubs['streaming_analyze_content']

    @property
    def bidi_streaming_analyze_content(self) -> Callable[
            [participant.BidiStreamingAnalyzeContentRequest],
            participant.BidiStreamingAnalyzeContentResponse]:
        r"""Return a callable for the bidi streaming analyze content method over gRPC.

        Bidirectional endless streaming version of
        [StreamingAnalyzeContent][google.cloud.dialogflow.v2beta1.Participants.StreamingAnalyzeContent].

        Returns:
            Callable[[~.BidiStreamingAnalyzeContentRequest],
                    ~.BidiStreamingAnalyzeContentResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'bidi_streaming_analyze_content' not in self._stubs:
            self._stubs['bidi_streaming_analyze_content'] = self._logged_channel.stream_stream(
                '/google.cloud.dialogflow.v2beta1.Participants/BidiStreamingAnalyzeContent',
                request_serializer=participant.BidiStreamingAnalyzeContentRequest.serialize,
                response_deserializer=participant.BidiStreamingAnalyzeContentResponse.deserialize,
            )
        return self._stubs['bidi_streaming_analyze_content']

    @property
    def suggest_articles(self) -> Callable[
            [participant.SuggestArticlesRequest],
            participant.SuggestArticlesResponse]:
        r"""Return a callable for the suggest articles method over gRPC.

        Gets suggested articles for a participant based on specific
        historical messages.

        Note that
        [ListSuggestions][google.cloud.dialogflow.v2beta1.Participants.ListSuggestions]
        will only list the auto-generated suggestions, while
        [CompileSuggestion][google.cloud.dialogflow.v2beta1.Participants.CompileSuggestion]
        will try to compile suggestion based on the provided
        conversation context in the real time.

        Returns:
            Callable[[~.SuggestArticlesRequest],
                    ~.SuggestArticlesResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_articles' not in self._stubs:
            self._stubs['suggest_articles'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestArticles',
                request_serializer=participant.SuggestArticlesRequest.serialize,
                response_deserializer=participant.SuggestArticlesResponse.deserialize,
            )
        return self._stubs['suggest_articles']

    @property
    def suggest_faq_answers(self) -> Callable[
            [participant.SuggestFaqAnswersRequest],
            participant.SuggestFaqAnswersResponse]:
        r"""Return a callable for the suggest faq answers method over gRPC.

        Gets suggested faq answers for a participant based on
        specific historical messages.

        Returns:
            Callable[[~.SuggestFaqAnswersRequest],
                    ~.SuggestFaqAnswersResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_faq_answers' not in self._stubs:
            self._stubs['suggest_faq_answers'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestFaqAnswers',
                request_serializer=participant.SuggestFaqAnswersRequest.serialize,
                response_deserializer=participant.SuggestFaqAnswersResponse.deserialize,
            )
        return self._stubs['suggest_faq_answers']

    @property
    def suggest_smart_replies(self) -> Callable[
            [participant.SuggestSmartRepliesRequest],
            participant.SuggestSmartRepliesResponse]:
        r"""Return a callable for the suggest smart replies method over gRPC.

        Gets smart replies for a participant based on
        specific historical messages.

        Returns:
            Callable[[~.SuggestSmartRepliesRequest],
                    ~.SuggestSmartRepliesResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_smart_replies' not in self._stubs:
            self._stubs['suggest_smart_replies'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestSmartReplies',
                request_serializer=participant.SuggestSmartRepliesRequest.serialize,
                response_deserializer=participant.SuggestSmartRepliesResponse.deserialize,
            )
        return self._stubs['suggest_smart_replies']

    @property
    def suggest_smart_compose_answers(self) -> Callable[
            [participant.SuggestSmartComposeAnswersRequest],
            participant.SuggestSmartComposeAnswersResponse]:
        r"""Return a callable for the suggest smart compose answers method over gRPC.

        Gets smart compose suggestions for a participant
        based on specific historical messages.

        Returns:
            Callable[[~.SuggestSmartComposeAnswersRequest],
                    ~.SuggestSmartComposeAnswersResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_smart_compose_answers' not in self._stubs:
            self._stubs['suggest_smart_compose_answers'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestSmartComposeAnswers',
                request_serializer=participant.SuggestSmartComposeAnswersRequest.serialize,
                response_deserializer=participant.SuggestSmartComposeAnswersResponse.deserialize,
            )
        return self._stubs['suggest_smart_compose_answers']

    @property
    def suggest_dialogflow_assists(self) -> Callable[
            [participant.SuggestDialogflowAssistsRequest],
            participant.SuggestDialogflowAssistsResponse]:
        r"""Return a callable for the suggest dialogflow assists method over gRPC.

        Gets Dialogflow assist answers for a participant
        based on specific historical messages.

        Returns:
            Callable[[~.SuggestDialogflowAssistsRequest],
                    ~.SuggestDialogflowAssistsResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_dialogflow_assists' not in self._stubs:
            self._stubs['suggest_dialogflow_assists'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestDialogflowAssists',
                request_serializer=participant.SuggestDialogflowAssistsRequest.serialize,
                response_deserializer=participant.SuggestDialogflowAssistsResponse.deserialize,
            )
        return self._stubs['suggest_dialogflow_assists']

    @property
    def suggest_knowledge_assist(self) -> Callable[
            [participant.SuggestKnowledgeAssistRequest],
            participant.SuggestKnowledgeAssistResponse]:
        r"""Return a callable for the suggest knowledge assist method over gRPC.

        Gets knowledge assist suggestions based on historical
        messages.

        Returns:
            Callable[[~.SuggestKnowledgeAssistRequest],
                    ~.SuggestKnowledgeAssistResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_knowledge_assist' not in self._stubs:
            self._stubs['suggest_knowledge_assist'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/SuggestKnowledgeAssist',
                request_serializer=participant.SuggestKnowledgeAssistRequest.serialize,
                response_deserializer=participant.SuggestKnowledgeAssistResponse.deserialize,
            )
        return self._stubs['suggest_knowledge_assist']

    @property
    def list_suggestions(self) -> Callable[
            [participant.ListSuggestionsRequest],
            participant.ListSuggestionsResponse]:
        r"""Return a callable for the list suggestions method over gRPC.

        Deprecated: Use inline suggestion, event based suggestion or
        Suggestion\* API instead. See
        [HumanAgentAssistantConfig.name][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.name]
        for more details. Removal Date: 2020-09-01.

        Retrieves suggestions for live agents.

        This method should be used by human agent client software to
        fetch auto generated suggestions in real-time, while the
        conversation with an end user is in progress. The functionality
        is implemented in terms of the `list
        pagination <https://cloud.google.com/apis/design/design_patterns#list_pagination>`__
        design pattern. The client app should use the
        ``next_page_token`` field to fetch the next batch of
        suggestions. ``suggestions`` are sorted by ``create_time`` in
        descending order. To fetch latest suggestion, just set
        ``page_size`` to 1. To fetch new suggestions without
        duplication, send request with filter
        ``create_time_epoch_microseconds > [first item's create_time of previous request]``
        and empty page_token.

        Returns:
            Callable[[~.ListSuggestionsRequest],
                    ~.ListSuggestionsResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_suggestions' not in self._stubs:
            self._stubs['list_suggestions'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/ListSuggestions',
                request_serializer=participant.ListSuggestionsRequest.serialize,
                response_deserializer=participant.ListSuggestionsResponse.deserialize,
            )
        return self._stubs['list_suggestions']

    @property
    def compile_suggestion(self) -> Callable[
            [participant.CompileSuggestionRequest],
            participant.CompileSuggestionResponse]:
        r"""Return a callable for the compile suggestion method over gRPC.

        Deprecated. use
        [SuggestArticles][google.cloud.dialogflow.v2beta1.Participants.SuggestArticles]
        and
        [SuggestFaqAnswers][google.cloud.dialogflow.v2beta1.Participants.SuggestFaqAnswers]
        instead.

        Gets suggestions for a participant based on specific historical
        messages.

        Note that
        [ListSuggestions][google.cloud.dialogflow.v2beta1.Participants.ListSuggestions]
        will only list the auto-generated suggestions, while
        [CompileSuggestion][google.cloud.dialogflow.v2beta1.Participants.CompileSuggestion]
        will try to compile suggestion based on the provided
        conversation context in the real time.

        Returns:
            Callable[[~.CompileSuggestionRequest],
                    ~.CompileSuggestionResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'compile_suggestion' not in self._stubs:
            self._stubs['compile_suggestion'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Participants/CompileSuggestion',
                request_serializer=participant.CompileSuggestionRequest.serialize,
                response_deserializer=participant.CompileSuggestionResponse.deserialize,
            )
        return self._stubs['compile_suggestion']

    @property
    def bidi_endpoint_interact(self) -> Callable[
            [participant.BidiEndpointInteractRequest],
            participant.BidiEndpointInteractResponse]:
        r"""Return a callable for the bidi endpoint interact method over gRPC.

        Bidirectional interaction of an endpoint with the
        conversation. The endpoint sends messages and events to
        the conversation and receives messages from the
        conversation about other endpoints or the conversation
        itself.

        Returns:
            Callable[[~.BidiEndpointInteractRequest],
                    ~.BidiEndpointInteractResponse]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'bidi_endpoint_interact' not in self._stubs:
            self._stubs['bidi_endpoint_interact'] = self._logged_channel.stream_stream(
                '/google.cloud.dialogflow.v2beta1.Participants/BidiEndpointInteract',
                request_serializer=participant.BidiEndpointInteractRequest.serialize,
                response_deserializer=participant.BidiEndpointInteractResponse.deserialize,
            )
        return self._stubs['bidi_endpoint_interact']

    def close(self):
        self._logged_channel.close()

    @property
    def cancel_operation(
        self,
    ) -> Callable[[operations_pb2.CancelOperationRequest], None]:
        r"""Return a callable for the cancel_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "cancel_operation" not in self._stubs:
            self._stubs["cancel_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/CancelOperation",
                request_serializer=operations_pb2.CancelOperationRequest.SerializeToString,
                response_deserializer=None,
            )
        return self._stubs["cancel_operation"]

    @property
    def get_operation(
        self,
    ) -> Callable[[operations_pb2.GetOperationRequest], operations_pb2.Operation]:
        r"""Return a callable for the get_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_operation" not in self._stubs:
            self._stubs["get_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/GetOperation",
                request_serializer=operations_pb2.GetOperationRequest.SerializeToString,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["get_operation"]

    @property
    def list_operations(
        self,
    ) -> Callable[[operations_pb2.ListOperationsRequest], operations_pb2.ListOperationsResponse]:
        r"""Return a callable for the list_operations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_operations" not in self._stubs:
            self._stubs["list_operations"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/ListOperations",
                request_serializer=operations_pb2.ListOperationsRequest.SerializeToString,
                response_deserializer=operations_pb2.ListOperationsResponse.FromString,
            )
        return self._stubs["list_operations"]

    @property
    def list_locations(
        self,
    ) -> Callable[[locations_pb2.ListLocationsRequest], locations_pb2.ListLocationsResponse]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_locations" not in self._stubs:
            self._stubs["list_locations"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/ListLocations",
                request_serializer=locations_pb2.ListLocationsRequest.SerializeToString,
                response_deserializer=locations_pb2.ListLocationsResponse.FromString,
            )
        return self._stubs["list_locations"]

    @property
    def get_location(
        self,
    ) -> Callable[[locations_pb2.GetLocationRequest], locations_pb2.Location]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_location" not in self._stubs:
            self._stubs["get_location"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/GetLocation",
                request_serializer=locations_pb2.GetLocationRequest.SerializeToString,
                response_deserializer=locations_pb2.Location.FromString,
            )
        return self._stubs["get_location"]

    @property
    def kind(self) -> str:
        return "grpc"


__all__ = (
    'ParticipantsGrpcTransport',
)
