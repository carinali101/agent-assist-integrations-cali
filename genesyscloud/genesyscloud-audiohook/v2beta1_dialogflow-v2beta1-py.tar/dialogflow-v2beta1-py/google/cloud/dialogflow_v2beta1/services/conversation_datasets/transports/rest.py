# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1
import google.protobuf

from google.protobuf import json_format
from google.api_core import operations_v1
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v2beta1.types import conversation_dataset
from google.cloud.dialogflow_v2beta1.types import conversation_dataset as gcd_conversation_dataset
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseConversationDatasetsRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class ConversationDatasetsRestInterceptor:
    """Interceptor for ConversationDatasets.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the ConversationDatasetsRestTransport.

    .. code-block:: python
        class MyCustomConversationDatasetsInterceptor(ConversationDatasetsRestInterceptor):
            def pre_create_conversation_dataset(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_conversation_dataset(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_annotated_conversation_dataset(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_delete_conversation_dataset(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_delete_conversation_dataset(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_annotated_conversation_dataset(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_annotated_conversation_dataset(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_conversation_dataset(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_conversation_dataset(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_import_conversation_data(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_import_conversation_data(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_label_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_label_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_annotated_conversation_datasets(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_annotated_conversation_datasets(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_conversation_datasets(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_conversation_datasets(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = ConversationDatasetsRestTransport(interceptor=MyCustomConversationDatasetsInterceptor())
        client = ConversationDatasetsClient(transport=transport)


    """
    def pre_create_conversation_dataset(self, request: gcd_conversation_dataset.CreateConversationDatasetRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation_dataset.CreateConversationDatasetRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_conversation_dataset

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_create_conversation_dataset(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for create_conversation_dataset

        DEPRECATED. Please use the `post_create_conversation_dataset_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_create_conversation_dataset` interceptor runs
        before the `post_create_conversation_dataset_with_metadata` interceptor.
        """
        return response

    def post_create_conversation_dataset_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_conversation_dataset

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_create_conversation_dataset_with_metadata`
        interceptor in new development instead of the `post_create_conversation_dataset` interceptor.
        When both interceptors are used, this `post_create_conversation_dataset_with_metadata` interceptor runs after the
        `post_create_conversation_dataset` interceptor. The (possibly modified) response returned by
        `post_create_conversation_dataset` will be passed to
        `post_create_conversation_dataset_with_metadata`.
        """
        return response, metadata

    def pre_delete_annotated_conversation_dataset(self, request: conversation_dataset.DeleteAnnotatedConversationDatasetRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.DeleteAnnotatedConversationDatasetRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_annotated_conversation_dataset

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def pre_delete_conversation_dataset(self, request: conversation_dataset.DeleteConversationDatasetRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.DeleteConversationDatasetRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_conversation_dataset

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_delete_conversation_dataset(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for delete_conversation_dataset

        DEPRECATED. Please use the `post_delete_conversation_dataset_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_delete_conversation_dataset` interceptor runs
        before the `post_delete_conversation_dataset_with_metadata` interceptor.
        """
        return response

    def post_delete_conversation_dataset_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for delete_conversation_dataset

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_delete_conversation_dataset_with_metadata`
        interceptor in new development instead of the `post_delete_conversation_dataset` interceptor.
        When both interceptors are used, this `post_delete_conversation_dataset_with_metadata` interceptor runs after the
        `post_delete_conversation_dataset` interceptor. The (possibly modified) response returned by
        `post_delete_conversation_dataset` will be passed to
        `post_delete_conversation_dataset_with_metadata`.
        """
        return response, metadata

    def pre_get_annotated_conversation_dataset(self, request: conversation_dataset.GetAnnotatedConversationDatasetRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.GetAnnotatedConversationDatasetRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_annotated_conversation_dataset

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_get_annotated_conversation_dataset(self, response: conversation_dataset.AnnotatedConversationDataset) -> conversation_dataset.AnnotatedConversationDataset:
        """Post-rpc interceptor for get_annotated_conversation_dataset

        DEPRECATED. Please use the `post_get_annotated_conversation_dataset_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_get_annotated_conversation_dataset` interceptor runs
        before the `post_get_annotated_conversation_dataset_with_metadata` interceptor.
        """
        return response

    def post_get_annotated_conversation_dataset_with_metadata(self, response: conversation_dataset.AnnotatedConversationDataset, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.AnnotatedConversationDataset, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_annotated_conversation_dataset

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_get_annotated_conversation_dataset_with_metadata`
        interceptor in new development instead of the `post_get_annotated_conversation_dataset` interceptor.
        When both interceptors are used, this `post_get_annotated_conversation_dataset_with_metadata` interceptor runs after the
        `post_get_annotated_conversation_dataset` interceptor. The (possibly modified) response returned by
        `post_get_annotated_conversation_dataset` will be passed to
        `post_get_annotated_conversation_dataset_with_metadata`.
        """
        return response, metadata

    def pre_get_conversation_dataset(self, request: conversation_dataset.GetConversationDatasetRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.GetConversationDatasetRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_conversation_dataset

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_get_conversation_dataset(self, response: conversation_dataset.ConversationDataset) -> conversation_dataset.ConversationDataset:
        """Post-rpc interceptor for get_conversation_dataset

        DEPRECATED. Please use the `post_get_conversation_dataset_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_get_conversation_dataset` interceptor runs
        before the `post_get_conversation_dataset_with_metadata` interceptor.
        """
        return response

    def post_get_conversation_dataset_with_metadata(self, response: conversation_dataset.ConversationDataset, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ConversationDataset, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_conversation_dataset

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_get_conversation_dataset_with_metadata`
        interceptor in new development instead of the `post_get_conversation_dataset` interceptor.
        When both interceptors are used, this `post_get_conversation_dataset_with_metadata` interceptor runs after the
        `post_get_conversation_dataset` interceptor. The (possibly modified) response returned by
        `post_get_conversation_dataset` will be passed to
        `post_get_conversation_dataset_with_metadata`.
        """
        return response, metadata

    def pre_import_conversation_data(self, request: conversation_dataset.ImportConversationDataRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ImportConversationDataRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for import_conversation_data

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_import_conversation_data(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for import_conversation_data

        DEPRECATED. Please use the `post_import_conversation_data_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_import_conversation_data` interceptor runs
        before the `post_import_conversation_data_with_metadata` interceptor.
        """
        return response

    def post_import_conversation_data_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for import_conversation_data

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_import_conversation_data_with_metadata`
        interceptor in new development instead of the `post_import_conversation_data` interceptor.
        When both interceptors are used, this `post_import_conversation_data_with_metadata` interceptor runs after the
        `post_import_conversation_data` interceptor. The (possibly modified) response returned by
        `post_import_conversation_data` will be passed to
        `post_import_conversation_data_with_metadata`.
        """
        return response, metadata

    def pre_label_conversation(self, request: conversation_dataset.LabelConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.LabelConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for label_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_label_conversation(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for label_conversation

        DEPRECATED. Please use the `post_label_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_label_conversation` interceptor runs
        before the `post_label_conversation_with_metadata` interceptor.
        """
        return response

    def post_label_conversation_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for label_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_label_conversation_with_metadata`
        interceptor in new development instead of the `post_label_conversation` interceptor.
        When both interceptors are used, this `post_label_conversation_with_metadata` interceptor runs after the
        `post_label_conversation` interceptor. The (possibly modified) response returned by
        `post_label_conversation` will be passed to
        `post_label_conversation_with_metadata`.
        """
        return response, metadata

    def pre_list_annotated_conversation_datasets(self, request: conversation_dataset.ListAnnotatedConversationDatasetsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ListAnnotatedConversationDatasetsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_annotated_conversation_datasets

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_list_annotated_conversation_datasets(self, response: conversation_dataset.ListAnnotatedConversationDatasetsResponse) -> conversation_dataset.ListAnnotatedConversationDatasetsResponse:
        """Post-rpc interceptor for list_annotated_conversation_datasets

        DEPRECATED. Please use the `post_list_annotated_conversation_datasets_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_list_annotated_conversation_datasets` interceptor runs
        before the `post_list_annotated_conversation_datasets_with_metadata` interceptor.
        """
        return response

    def post_list_annotated_conversation_datasets_with_metadata(self, response: conversation_dataset.ListAnnotatedConversationDatasetsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ListAnnotatedConversationDatasetsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_annotated_conversation_datasets

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_list_annotated_conversation_datasets_with_metadata`
        interceptor in new development instead of the `post_list_annotated_conversation_datasets` interceptor.
        When both interceptors are used, this `post_list_annotated_conversation_datasets_with_metadata` interceptor runs after the
        `post_list_annotated_conversation_datasets` interceptor. The (possibly modified) response returned by
        `post_list_annotated_conversation_datasets` will be passed to
        `post_list_annotated_conversation_datasets_with_metadata`.
        """
        return response, metadata

    def pre_list_conversation_datasets(self, request: conversation_dataset.ListConversationDatasetsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ListConversationDatasetsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_conversation_datasets

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_list_conversation_datasets(self, response: conversation_dataset.ListConversationDatasetsResponse) -> conversation_dataset.ListConversationDatasetsResponse:
        """Post-rpc interceptor for list_conversation_datasets

        DEPRECATED. Please use the `post_list_conversation_datasets_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code. This `post_list_conversation_datasets` interceptor runs
        before the `post_list_conversation_datasets_with_metadata` interceptor.
        """
        return response

    def post_list_conversation_datasets_with_metadata(self, response: conversation_dataset.ListConversationDatasetsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation_dataset.ListConversationDatasetsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_conversation_datasets

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationDatasets server but before it is returned to user code.

        We recommend only using this `post_list_conversation_datasets_with_metadata`
        interceptor in new development instead of the `post_list_conversation_datasets` interceptor.
        When both interceptors are used, this `post_list_conversation_datasets_with_metadata` interceptor runs after the
        `post_list_conversation_datasets` interceptor. The (possibly modified) response returned by
        `post_list_conversation_datasets` will be passed to
        `post_list_conversation_datasets_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationDatasets server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the ConversationDatasets server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class ConversationDatasetsRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: ConversationDatasetsRestInterceptor


class ConversationDatasetsRestTransport(_BaseConversationDatasetsRestTransport):
    """REST backend synchronous transport for ConversationDatasets.

    Conversation datasets.

    Conversation datasets contain raw conversation files along with
    their customizable metadata that can be used to train custom
    human agent assistant models, evaluate models in regression
    tests and other stuff.

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[ConversationDatasetsRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided. This argument will be
                removed in the next major version of this library.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        self._operations_client: Optional[operations_v1.AbstractOperationsClient] = None
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or ConversationDatasetsRestInterceptor()
        self._prep_wrapped_messages(client_info)

    @property
    def operations_client(self) -> operations_v1.AbstractOperationsClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Only create a new client if we do not already have one.
        if self._operations_client is None:
            http_options: Dict[str, List[Dict[str, str]]] = {
                'google.longrunning.Operations.CancelOperation': [
                    {
                        'method': 'post',
                        'uri': '/v2beta1/{name=projects/*/operations/*}:cancel',
                    },
                    {
                        'method': 'post',
                        'uri': '/v2beta1/{name=projects/*/locations/*/operations/*}:cancel',
                    },
                ],
                'google.longrunning.Operations.GetOperation': [
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/operations/*}',
                    },
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/locations/*/operations/*}',
                    },
                ],
                'google.longrunning.Operations.ListOperations': [
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*}/operations',
                    },
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/locations/*}/operations',
                    },
                ],
            }

            rest_transport = operations_v1.OperationsRestTransport(
                    host=self._host,
                    # use the credentials which are saved
                    credentials=self._credentials,
                    scopes=self._scopes,
                    http_options=http_options,
                    path_prefix="v2beta1")

            self._operations_client = operations_v1.AbstractOperationsClient(transport=rest_transport)

        # Return the client from cache.
        return self._operations_client

    class _CreateConversationDataset(_BaseConversationDatasetsRestTransport._BaseCreateConversationDataset, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.CreateConversationDataset")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation_dataset.CreateConversationDatasetRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the create conversation
        dataset method over HTTP.

            Args:
                request (~.gcd_conversation_dataset.CreateConversationDatasetRequest):
                    The request object. The request message for
                [ConversationDatasets.CreateConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.CreateConversationDataset].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseCreateConversationDataset._get_http_options()

            request, metadata = self._interceptor.pre_create_conversation_dataset(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseCreateConversationDataset._get_transcoded_request(http_options, request)

            body = _BaseConversationDatasetsRestTransport._BaseCreateConversationDataset._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseCreateConversationDataset._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.CreateConversationDataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "CreateConversationDataset",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._CreateConversationDataset._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_conversation_dataset(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_conversation_dataset_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.create_conversation_dataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "CreateConversationDataset",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteAnnotatedConversationDataset(_BaseConversationDatasetsRestTransport._BaseDeleteAnnotatedConversationDataset, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.DeleteAnnotatedConversationDataset")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.DeleteAnnotatedConversationDatasetRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete annotated
        conversation dataset method over HTTP.

            Args:
                request (~.conversation_dataset.DeleteAnnotatedConversationDatasetRequest):
                    The request object. The request message for
                [ConversationDatasets.DeleteAnnotatedConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.DeleteAnnotatedConversationDataset].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseDeleteAnnotatedConversationDataset._get_http_options()

            request, metadata = self._interceptor.pre_delete_annotated_conversation_dataset(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseDeleteAnnotatedConversationDataset._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseDeleteAnnotatedConversationDataset._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.DeleteAnnotatedConversationDataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "DeleteAnnotatedConversationDataset",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._DeleteAnnotatedConversationDataset._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _DeleteConversationDataset(_BaseConversationDatasetsRestTransport._BaseDeleteConversationDataset, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.DeleteConversationDataset")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.DeleteConversationDatasetRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the delete conversation
        dataset method over HTTP.

            Args:
                request (~.conversation_dataset.DeleteConversationDatasetRequest):
                    The request object. The request message for
                [ConversationDatasets.DeleteConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.DeleteConversationDataset].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseDeleteConversationDataset._get_http_options()

            request, metadata = self._interceptor.pre_delete_conversation_dataset(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseDeleteConversationDataset._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseDeleteConversationDataset._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.DeleteConversationDataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "DeleteConversationDataset",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._DeleteConversationDataset._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_delete_conversation_dataset(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_delete_conversation_dataset_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.delete_conversation_dataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "DeleteConversationDataset",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetAnnotatedConversationDataset(_BaseConversationDatasetsRestTransport._BaseGetAnnotatedConversationDataset, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.GetAnnotatedConversationDataset")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.GetAnnotatedConversationDatasetRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation_dataset.AnnotatedConversationDataset:
            r"""Call the get annotated
        conversation dataset method over HTTP.

            Args:
                request (~.conversation_dataset.GetAnnotatedConversationDatasetRequest):
                    The request object. The request message for
                [ConversationDatasets.GetAnnotatedConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.GetAnnotatedConversationDataset].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation_dataset.AnnotatedConversationDataset:
                    Represents an annotated conversation
                dataset. ConversationDataset can have
                multiple AnnotatedConversationDataset,
                each of them represents one result from
                one annotation task.
                AnnotatedConversationDataset can only be
                generated from annotation task, which
                will be triggered by LabelConversation.

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseGetAnnotatedConversationDataset._get_http_options()

            request, metadata = self._interceptor.pre_get_annotated_conversation_dataset(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseGetAnnotatedConversationDataset._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseGetAnnotatedConversationDataset._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.GetAnnotatedConversationDataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetAnnotatedConversationDataset",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._GetAnnotatedConversationDataset._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation_dataset.AnnotatedConversationDataset()
            pb_resp = conversation_dataset.AnnotatedConversationDataset.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_annotated_conversation_dataset(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_annotated_conversation_dataset_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation_dataset.AnnotatedConversationDataset.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.get_annotated_conversation_dataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetAnnotatedConversationDataset",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetConversationDataset(_BaseConversationDatasetsRestTransport._BaseGetConversationDataset, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.GetConversationDataset")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.GetConversationDatasetRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation_dataset.ConversationDataset:
            r"""Call the get conversation dataset method over HTTP.

            Args:
                request (~.conversation_dataset.GetConversationDatasetRequest):
                    The request object. The request message for
                [ConversationDatasets.GetConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.GetConversationDataset].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation_dataset.ConversationDataset:
                    Represents a conversation dataset
                that a user imports raw data into. The
                data inside ConversationDataset can not
                be changed after ImportConversationData
                finishes (and calling
                ImportConversationData on a dataset that
                already has data is not allowed).

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseGetConversationDataset._get_http_options()

            request, metadata = self._interceptor.pre_get_conversation_dataset(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseGetConversationDataset._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseGetConversationDataset._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.GetConversationDataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetConversationDataset",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._GetConversationDataset._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation_dataset.ConversationDataset()
            pb_resp = conversation_dataset.ConversationDataset.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_conversation_dataset(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_conversation_dataset_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation_dataset.ConversationDataset.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.get_conversation_dataset",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetConversationDataset",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ImportConversationData(_BaseConversationDatasetsRestTransport._BaseImportConversationData, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.ImportConversationData")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation_dataset.ImportConversationDataRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the import conversation data method over HTTP.

            Args:
                request (~.conversation_dataset.ImportConversationDataRequest):
                    The request object. The request message for
                [ConversationDatasets.ImportConversationData][google.cloud.dialogflow.v2beta1.ConversationDatasets.ImportConversationData].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseImportConversationData._get_http_options()

            request, metadata = self._interceptor.pre_import_conversation_data(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseImportConversationData._get_transcoded_request(http_options, request)

            body = _BaseConversationDatasetsRestTransport._BaseImportConversationData._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseImportConversationData._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.ImportConversationData",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ImportConversationData",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._ImportConversationData._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_import_conversation_data(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_import_conversation_data_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.import_conversation_data",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ImportConversationData",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _LabelConversation(_BaseConversationDatasetsRestTransport._BaseLabelConversation, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.LabelConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation_dataset.LabelConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the label conversation method over HTTP.

            Args:
                request (~.conversation_dataset.LabelConversationRequest):
                    The request object. The request message for
                [ConversationDatasets.LabelConversation][google.cloud.dialogflow.v2beta1.ConversationDatasets.LabelConversation].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseLabelConversation._get_http_options()

            request, metadata = self._interceptor.pre_label_conversation(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseLabelConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationDatasetsRestTransport._BaseLabelConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseLabelConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.LabelConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "LabelConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._LabelConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_label_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_label_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.label_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "LabelConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListAnnotatedConversationDatasets(_BaseConversationDatasetsRestTransport._BaseListAnnotatedConversationDatasets, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.ListAnnotatedConversationDatasets")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.ListAnnotatedConversationDatasetsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation_dataset.ListAnnotatedConversationDatasetsResponse:
            r"""Call the list annotated
        conversation datasets method over HTTP.

            Args:
                request (~.conversation_dataset.ListAnnotatedConversationDatasetsRequest):
                    The request object. The request message for
                [ConversationDatasets.ListAnnotatedConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListAnnotatedConversationDatasets].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation_dataset.ListAnnotatedConversationDatasetsResponse:
                    The response message for
                [ConversationDatasets.ListAnnotatedConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListAnnotatedConversationDatasets].

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseListAnnotatedConversationDatasets._get_http_options()

            request, metadata = self._interceptor.pre_list_annotated_conversation_datasets(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseListAnnotatedConversationDatasets._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseListAnnotatedConversationDatasets._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.ListAnnotatedConversationDatasets",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListAnnotatedConversationDatasets",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._ListAnnotatedConversationDatasets._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation_dataset.ListAnnotatedConversationDatasetsResponse()
            pb_resp = conversation_dataset.ListAnnotatedConversationDatasetsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_annotated_conversation_datasets(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_annotated_conversation_datasets_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation_dataset.ListAnnotatedConversationDatasetsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.list_annotated_conversation_datasets",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListAnnotatedConversationDatasets",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListConversationDatasets(_BaseConversationDatasetsRestTransport._BaseListConversationDatasets, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.ListConversationDatasets")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation_dataset.ListConversationDatasetsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation_dataset.ListConversationDatasetsResponse:
            r"""Call the list conversation
        datasets method over HTTP.

            Args:
                request (~.conversation_dataset.ListConversationDatasetsRequest):
                    The request object. The request message for
                [ConversationDatasets.ListConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListConversationDatasets].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation_dataset.ListConversationDatasetsResponse:
                    The response message for
                [ConversationDatasets.ListConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListConversationDatasets].

            """

            http_options = _BaseConversationDatasetsRestTransport._BaseListConversationDatasets._get_http_options()

            request, metadata = self._interceptor.pre_list_conversation_datasets(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseListConversationDatasets._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseListConversationDatasets._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.ListConversationDatasets",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListConversationDatasets",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._ListConversationDatasets._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation_dataset.ListConversationDatasetsResponse()
            pb_resp = conversation_dataset.ListConversationDatasetsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_conversation_datasets(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_conversation_datasets_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation_dataset.ListConversationDatasetsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.list_conversation_datasets",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListConversationDatasets",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def create_conversation_dataset(self) -> Callable[
            [gcd_conversation_dataset.CreateConversationDatasetRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateConversationDataset(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_annotated_conversation_dataset(self) -> Callable[
            [conversation_dataset.DeleteAnnotatedConversationDatasetRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteAnnotatedConversationDataset(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_conversation_dataset(self) -> Callable[
            [conversation_dataset.DeleteConversationDatasetRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteConversationDataset(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_annotated_conversation_dataset(self) -> Callable[
            [conversation_dataset.GetAnnotatedConversationDatasetRequest],
            conversation_dataset.AnnotatedConversationDataset]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetAnnotatedConversationDataset(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_conversation_dataset(self) -> Callable[
            [conversation_dataset.GetConversationDatasetRequest],
            conversation_dataset.ConversationDataset]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetConversationDataset(self._session, self._host, self._interceptor) # type: ignore

    @property
    def import_conversation_data(self) -> Callable[
            [conversation_dataset.ImportConversationDataRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ImportConversationData(self._session, self._host, self._interceptor) # type: ignore

    @property
    def label_conversation(self) -> Callable[
            [conversation_dataset.LabelConversationRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._LabelConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_annotated_conversation_datasets(self) -> Callable[
            [conversation_dataset.ListAnnotatedConversationDatasetsRequest],
            conversation_dataset.ListAnnotatedConversationDatasetsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListAnnotatedConversationDatasets(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_conversation_datasets(self) -> Callable[
            [conversation_dataset.ListConversationDatasetsRequest],
            conversation_dataset.ListConversationDatasetsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListConversationDatasets(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseConversationDatasetsRestTransport._BaseGetLocation, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseConversationDatasetsRestTransport._BaseListLocations, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseConversationDatasetsRestTransport._BaseCancelOperation, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseConversationDatasetsRestTransport._BaseGetOperation, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseConversationDatasetsRestTransport._BaseListOperations, ConversationDatasetsRestStub):
        def __hash__(self):
            return hash("ConversationDatasetsRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseConversationDatasetsRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseConversationDatasetsRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationDatasetsRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationDatasetsClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationDatasetsRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationDatasetsAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'ConversationDatasetsRestTransport',
)
