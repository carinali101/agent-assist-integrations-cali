
transport inheritance structure
_______________________________

`PhoneNumberOrdersTransport` is the ABC for all transports.
- public child `PhoneNumberOrdersGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `PhoneNumberOrdersGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BasePhoneNumberOrdersRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `PhoneNumberOrdersRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
