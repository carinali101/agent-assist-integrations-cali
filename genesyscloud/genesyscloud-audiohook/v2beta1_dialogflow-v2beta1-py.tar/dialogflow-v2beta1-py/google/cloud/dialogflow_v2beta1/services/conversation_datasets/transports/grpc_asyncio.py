# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import inspect
import json
import pickle
import logging as std_logging
import warnings
from typing import Awaitable, Callable, Dict, Optional, Sequence, Tuple, Union

from google.api_core import gapic_v1
from google.api_core import grpc_helpers_async
from google.api_core import exceptions as core_exceptions
from google.api_core import retry_async as retries
from google.api_core import operations_v1
from google.auth import credentials as ga_credentials   # type: ignore
from google.auth.transport.grpc import SslCredentials  # type: ignore
from google.protobuf.json_format import MessageToJson
import google.protobuf.message

import grpc                        # type: ignore
import proto                       # type: ignore
from grpc.experimental import aio  # type: ignore

from google.cloud.dialogflow_v2beta1.types import conversation_dataset
from google.cloud.dialogflow_v2beta1.types import conversation_dataset as gcd_conversation_dataset
from google.cloud.location import locations_pb2 # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from google.protobuf import empty_pb2  # type: ignore
from .base import ConversationDatasetsTransport, DEFAULT_CLIENT_INFO
from .grpc import ConversationDatasetsGrpcTransport

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = std_logging.getLogger(__name__)


class _LoggingClientAIOInterceptor(grpc.aio.UnaryUnaryClientInterceptor):  # pragma: NO COVER
    async def intercept_unary_unary(self, continuation, client_call_details, request):
        logging_enabled = CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(std_logging.DEBUG)
        if logging_enabled:  # pragma: NO COVER
            request_metadata = client_call_details.metadata
            if isinstance(request, proto.Message):
                request_payload = type(request).to_json(request)
            elif isinstance(request, google.protobuf.message.Message):
                request_payload = MessageToJson(request)
            else:
                request_payload = f"{type(request).__name__}: {pickle.dumps(request)}"

            request_metadata = {
                key: value.decode("utf-8") if isinstance(value, bytes) else value
                for key, value in request_metadata
            }
            grpc_request = {
                "payload": request_payload,
                "requestMethod": "grpc",
                "metadata": dict(request_metadata),
            }
            _LOGGER.debug(
                f"Sending request for {client_call_details.method}",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                    "rpcName": str(client_call_details.method),
                    "request": grpc_request,
                    "metadata": grpc_request["metadata"],
                },
            )
        response = await continuation(client_call_details, request)
        if logging_enabled:  # pragma: NO COVER
            response_metadata = await response.trailing_metadata()
            # Convert gRPC metadata `<class 'grpc.aio._metadata.Metadata'>` to list of tuples
            metadata = dict([(k, str(v)) for k, v in response_metadata]) if response_metadata else None
            result = await response
            if isinstance(result, proto.Message):
                response_payload = type(result).to_json(result)
            elif isinstance(result, google.protobuf.message.Message):
                response_payload = MessageToJson(result)
            else:
                response_payload = f"{type(result).__name__}: {pickle.dumps(result)}"
            grpc_response = {
                "payload": response_payload,
                "metadata": metadata,
                "status": "OK",
            }
            _LOGGER.debug(
                f"Received response to rpc {client_call_details.method}.",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.ConversationDatasets",
                    "rpcName": str(client_call_details.method),
                    "response": grpc_response,
                    "metadata": grpc_response["metadata"],
                },
            )
        return response


class ConversationDatasetsGrpcAsyncIOTransport(ConversationDatasetsTransport):
    """gRPC AsyncIO backend transport for ConversationDatasets.

    Conversation datasets.

    Conversation datasets contain raw conversation files along with
    their customizable metadata that can be used to train custom
    human agent assistant models, evaluate models in regression
    tests and other stuff.

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends protocol buffers over the wire using gRPC (which is built on
    top of HTTP/2); the ``grpcio`` package must be installed.
    """

    _grpc_channel: aio.Channel
    _stubs: Dict[str, Callable] = {}

    @classmethod
    def create_channel(cls,
                       host: str = 'dialogflow.googleapis.com',
                       credentials: Optional[ga_credentials.Credentials] = None,
                       credentials_file: Optional[str] = None,
                       scopes: Optional[Sequence[str]] = None,
                       quota_project_id: Optional[str] = None,
                       **kwargs) -> aio.Channel:
        """Create and return a gRPC AsyncIO channel object.
        Args:
            host (Optional[str]): The host for the channel to use.
            credentials (Optional[~.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify this application to the service. If
                none are specified, the client will attempt to ascertain
                the credentials from the environment.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`. This argument will be
                removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            kwargs (Optional[dict]): Keyword arguments, which are passed to the
                channel creation.
        Returns:
            aio.Channel: A gRPC AsyncIO channel object.
        """

        return grpc_helpers_async.create_channel(
            host,
            credentials=credentials,
            credentials_file=credentials_file,
            quota_project_id=quota_project_id,
            default_scopes=cls.AUTH_SCOPES,
            scopes=scopes,
            default_host=cls.DEFAULT_HOST,
            **kwargs
        )

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            channel: Optional[Union[aio.Channel, Callable[..., aio.Channel]]] = None,
            api_mtls_endpoint: Optional[str] = None,
            client_cert_source: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            ssl_channel_credentials: Optional[grpc.ChannelCredentials] = None,
            client_cert_source_for_mtls: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
                This argument is ignored if a ``channel`` instance is provided.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if a ``channel`` instance is provided.
                This argument will be removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            channel (Optional[Union[aio.Channel, Callable[..., aio.Channel]]]):
                A ``Channel`` instance through which to make calls, or a Callable
                that constructs and returns one. If set to None, ``self.create_channel``
                is used to create the channel. If a Callable is given, it will be called
                with the same arguments as used in ``self.create_channel``.
            api_mtls_endpoint (Optional[str]): Deprecated. The mutual TLS endpoint.
                If provided, it overrides the ``host`` argument and tries to create
                a mutual TLS channel with client SSL credentials from
                ``client_cert_source`` or application default SSL credentials.
            client_cert_source (Optional[Callable[[], Tuple[bytes, bytes]]]):
                Deprecated. A callback to provide client SSL certificate bytes and
                private key bytes, both in PEM format. It is ignored if
                ``api_mtls_endpoint`` is None.
            ssl_channel_credentials (grpc.ChannelCredentials): SSL credentials
                for the grpc channel. It is ignored if a ``channel`` instance is provided.
            client_cert_source_for_mtls (Optional[Callable[[], Tuple[bytes, bytes]]]):
                A callback to provide client certificate bytes and private key bytes,
                both in PEM format. It is used to configure a mutual TLS channel. It is
                ignored if a ``channel`` instance or ``ssl_channel_credentials`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.

        Raises:
            google.auth.exceptions.MutualTlsChannelError: If mutual TLS transport
              creation failed for any reason.
          google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """
        self._grpc_channel = None
        self._ssl_channel_credentials = ssl_channel_credentials
        self._stubs: Dict[str, Callable] = {}
        self._operations_client: Optional[operations_v1.OperationsAsyncClient] = None

        if api_mtls_endpoint:
            warnings.warn("api_mtls_endpoint is deprecated", DeprecationWarning)
        if client_cert_source:
            warnings.warn("client_cert_source is deprecated", DeprecationWarning)

        if isinstance(channel, aio.Channel):
            # Ignore credentials if a channel was passed.
            credentials = None
            self._ignore_credentials = True
            # If a channel was explicitly provided, set it.
            self._grpc_channel = channel
            self._ssl_channel_credentials = None
        else:
            if api_mtls_endpoint:
                host = api_mtls_endpoint

                # Create SSL credentials with client_cert_source or application
                # default SSL credentials.
                if client_cert_source:
                    cert, key = client_cert_source()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )
                else:
                    self._ssl_channel_credentials = SslCredentials().ssl_credentials

            else:
                if client_cert_source_for_mtls and not ssl_channel_credentials:
                    cert, key = client_cert_source_for_mtls()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )

        # The base transport sets the host, credentials and scopes
        super().__init__(
            host=host,
            credentials=credentials,
            credentials_file=credentials_file,
            scopes=scopes,
            quota_project_id=quota_project_id,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            api_audience=api_audience,
        )

        if not self._grpc_channel:
            # initialize with the provided callable or the default channel
            channel_init = channel or type(self).create_channel
            self._grpc_channel = channel_init(
                self._host,
                # use the credentials which are saved
                credentials=self._credentials,
                # Set ``credentials_file`` to ``None`` here as
                # the credentials that we saved earlier should be used.
                credentials_file=None,
                scopes=self._scopes,
                ssl_credentials=self._ssl_channel_credentials,
                quota_project_id=quota_project_id,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )

        self._interceptor = _LoggingClientAIOInterceptor()
        self._grpc_channel._unary_unary_interceptors.append(self._interceptor)
        self._logged_channel = self._grpc_channel
        self._wrap_with_kind = "kind" in inspect.signature(gapic_v1.method_async.wrap_method).parameters
        # Wrap messages. This must be done after self._logged_channel exists
        self._prep_wrapped_messages(client_info)

    @property
    def grpc_channel(self) -> aio.Channel:
        """Create the channel designed to connect to this service.

        This property caches on the instance; repeated calls return
        the same channel.
        """
        # Return the channel from cache.
        return self._grpc_channel

    @property
    def operations_client(self) -> operations_v1.OperationsAsyncClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Quick check: Only create a new client if we do not already have one.
        if self._operations_client is None:
            self._operations_client = operations_v1.OperationsAsyncClient(
                self._logged_channel
            )

        # Return the client from cache.
        return self._operations_client

    @property
    def create_conversation_dataset(self) -> Callable[
            [gcd_conversation_dataset.CreateConversationDatasetRequest],
            Awaitable[operations_pb2.Operation]]:
        r"""Return a callable for the create conversation dataset method over gRPC.

        Creates a new conversation dataset.

        This method is a `long-running
        operation <https://cloud.google.com/dialogflow/es/docs/how/long-running-operations>`__.
        The returned ``Operation`` type has the following
        method-specific fields:

        - ``metadata``:
          [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
        - ``response``:
          [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]

        Returns:
            Callable[[~.CreateConversationDatasetRequest],
                    Awaitable[~.Operation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'create_conversation_dataset' not in self._stubs:
            self._stubs['create_conversation_dataset'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/CreateConversationDataset',
                request_serializer=gcd_conversation_dataset.CreateConversationDatasetRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs['create_conversation_dataset']

    @property
    def get_conversation_dataset(self) -> Callable[
            [conversation_dataset.GetConversationDatasetRequest],
            Awaitable[conversation_dataset.ConversationDataset]]:
        r"""Return a callable for the get conversation dataset method over gRPC.

        Retrieves the specified conversation dataset.

        Returns:
            Callable[[~.GetConversationDatasetRequest],
                    Awaitable[~.ConversationDataset]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_conversation_dataset' not in self._stubs:
            self._stubs['get_conversation_dataset'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/GetConversationDataset',
                request_serializer=conversation_dataset.GetConversationDatasetRequest.serialize,
                response_deserializer=conversation_dataset.ConversationDataset.deserialize,
            )
        return self._stubs['get_conversation_dataset']

    @property
    def list_conversation_datasets(self) -> Callable[
            [conversation_dataset.ListConversationDatasetsRequest],
            Awaitable[conversation_dataset.ListConversationDatasetsResponse]]:
        r"""Return a callable for the list conversation datasets method over gRPC.

        Returns the list of all conversation datasets in the
        specified project.

        Returns:
            Callable[[~.ListConversationDatasetsRequest],
                    Awaitable[~.ListConversationDatasetsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_conversation_datasets' not in self._stubs:
            self._stubs['list_conversation_datasets'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/ListConversationDatasets',
                request_serializer=conversation_dataset.ListConversationDatasetsRequest.serialize,
                response_deserializer=conversation_dataset.ListConversationDatasetsResponse.deserialize,
            )
        return self._stubs['list_conversation_datasets']

    @property
    def delete_conversation_dataset(self) -> Callable[
            [conversation_dataset.DeleteConversationDatasetRequest],
            Awaitable[operations_pb2.Operation]]:
        r"""Return a callable for the delete conversation dataset method over gRPC.

        Deletes the specified conversation dataset and all annotated
        conversation datasets that belong to it.

        This method is a `long-running
        operation <https://cloud.google.com/dialogflow/es/docs/how/long-running-operations>`__.
        The returned ``Operation`` type has the following
        method-specific fields:

        - ``metadata``:
          [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
        - ``response``: An `Empty
          message <https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty>`__

        Returns:
            Callable[[~.DeleteConversationDatasetRequest],
                    Awaitable[~.Operation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'delete_conversation_dataset' not in self._stubs:
            self._stubs['delete_conversation_dataset'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/DeleteConversationDataset',
                request_serializer=conversation_dataset.DeleteConversationDatasetRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs['delete_conversation_dataset']

    @property
    def get_annotated_conversation_dataset(self) -> Callable[
            [conversation_dataset.GetAnnotatedConversationDatasetRequest],
            Awaitable[conversation_dataset.AnnotatedConversationDataset]]:
        r"""Return a callable for the get annotated conversation
        dataset method over gRPC.

        Retrieves the specified annotated conversation
        dataset.

        Returns:
            Callable[[~.GetAnnotatedConversationDatasetRequest],
                    Awaitable[~.AnnotatedConversationDataset]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_annotated_conversation_dataset' not in self._stubs:
            self._stubs['get_annotated_conversation_dataset'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/GetAnnotatedConversationDataset',
                request_serializer=conversation_dataset.GetAnnotatedConversationDatasetRequest.serialize,
                response_deserializer=conversation_dataset.AnnotatedConversationDataset.deserialize,
            )
        return self._stubs['get_annotated_conversation_dataset']

    @property
    def list_annotated_conversation_datasets(self) -> Callable[
            [conversation_dataset.ListAnnotatedConversationDatasetsRequest],
            Awaitable[conversation_dataset.ListAnnotatedConversationDatasetsResponse]]:
        r"""Return a callable for the list annotated conversation
        datasets method over gRPC.

        Returns the list of all annotated conversation
        datasets that belong to a given conversation dataset.

        Returns:
            Callable[[~.ListAnnotatedConversationDatasetsRequest],
                    Awaitable[~.ListAnnotatedConversationDatasetsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_annotated_conversation_datasets' not in self._stubs:
            self._stubs['list_annotated_conversation_datasets'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/ListAnnotatedConversationDatasets',
                request_serializer=conversation_dataset.ListAnnotatedConversationDatasetsRequest.serialize,
                response_deserializer=conversation_dataset.ListAnnotatedConversationDatasetsResponse.deserialize,
            )
        return self._stubs['list_annotated_conversation_datasets']

    @property
    def delete_annotated_conversation_dataset(self) -> Callable[
            [conversation_dataset.DeleteAnnotatedConversationDatasetRequest],
            Awaitable[empty_pb2.Empty]]:
        r"""Return a callable for the delete annotated conversation
        dataset method over gRPC.

        Deletes the specified annotated conversation dataset
        and annotations that belongs to it.

        Returns:
            Callable[[~.DeleteAnnotatedConversationDatasetRequest],
                    Awaitable[~.Empty]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'delete_annotated_conversation_dataset' not in self._stubs:
            self._stubs['delete_annotated_conversation_dataset'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/DeleteAnnotatedConversationDataset',
                request_serializer=conversation_dataset.DeleteAnnotatedConversationDatasetRequest.serialize,
                response_deserializer=empty_pb2.Empty.FromString,
            )
        return self._stubs['delete_annotated_conversation_dataset']

    @property
    def import_conversation_data(self) -> Callable[
            [conversation_dataset.ImportConversationDataRequest],
            Awaitable[operations_pb2.Operation]]:
        r"""Return a callable for the import conversation data method over gRPC.

        Import data into the specified conversation dataset. Note that
        it is not allowed to import data to a conversation dataset that
        already has data in it.

        This method is a `long-running
        operation <https://cloud.google.com/dialogflow/es/docs/how/long-running-operations>`__.
        The returned ``Operation`` type has the following
        method-specific fields:

        - ``metadata``:
          [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
        - ``response``:
          [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]

        Returns:
            Callable[[~.ImportConversationDataRequest],
                    Awaitable[~.Operation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'import_conversation_data' not in self._stubs:
            self._stubs['import_conversation_data'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/ImportConversationData',
                request_serializer=conversation_dataset.ImportConversationDataRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs['import_conversation_data']

    @property
    def label_conversation(self) -> Callable[
            [conversation_dataset.LabelConversationRequest],
            Awaitable[operations_pb2.Operation]]:
        r"""Return a callable for the label conversation method over gRPC.

        [DEPRECATED]. Creates and starts a conversation dataset
        annotation task.

        This method is a `long-running
        operation <https://cloud.google.com/dialogflow/es/docs/how/long-running-operations>`__.
        The returned ``Operation`` type has the following
        method-specific fields:

        - ``metadata``:
          [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
        - ``response``:
          [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]

        Returns:
            Callable[[~.LabelConversationRequest],
                    Awaitable[~.Operation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'label_conversation' not in self._stubs:
            self._stubs['label_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.ConversationDatasets/LabelConversation',
                request_serializer=conversation_dataset.LabelConversationRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs['label_conversation']

    def _prep_wrapped_messages(self, client_info):
        """ Precompute the wrapped methods, overriding the base class method to use async wrappers."""
        self._wrapped_methods = {
            self.create_conversation_dataset: self._wrap_method(
                self.create_conversation_dataset,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_conversation_dataset: self._wrap_method(
                self.get_conversation_dataset,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_conversation_datasets: self._wrap_method(
                self.list_conversation_datasets,
                default_timeout=None,
                client_info=client_info,
            ),
            self.delete_conversation_dataset: self._wrap_method(
                self.delete_conversation_dataset,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_annotated_conversation_dataset: self._wrap_method(
                self.get_annotated_conversation_dataset,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_annotated_conversation_datasets: self._wrap_method(
                self.list_annotated_conversation_datasets,
                default_timeout=None,
                client_info=client_info,
            ),
            self.delete_annotated_conversation_dataset: self._wrap_method(
                self.delete_annotated_conversation_dataset,
                default_timeout=None,
                client_info=client_info,
            ),
            self.import_conversation_data: self._wrap_method(
                self.import_conversation_data,
                default_timeout=None,
                client_info=client_info,
            ),
            self.label_conversation: self._wrap_method(
                self.label_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_location: self._wrap_method(
                self.get_location,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_locations: self._wrap_method(
                self.list_locations,
                default_timeout=None,
                client_info=client_info,
            ),
            self.cancel_operation: self._wrap_method(
                self.cancel_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_operation: self._wrap_method(
                self.get_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_operations: self._wrap_method(
                self.list_operations,
                default_timeout=None,
                client_info=client_info,
            ),
        }

    def _wrap_method(self, func, *args, **kwargs):
        if self._wrap_with_kind:  # pragma: NO COVER
            kwargs["kind"] = self.kind
        return gapic_v1.method_async.wrap_method(func, *args, **kwargs)

    def close(self):
        return self._logged_channel.close()

    @property
    def kind(self) -> str:
        return "grpc_asyncio"

    @property
    def cancel_operation(
        self,
    ) -> Callable[[operations_pb2.CancelOperationRequest], None]:
        r"""Return a callable for the cancel_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "cancel_operation" not in self._stubs:
            self._stubs["cancel_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/CancelOperation",
                request_serializer=operations_pb2.CancelOperationRequest.SerializeToString,
                response_deserializer=None,
            )
        return self._stubs["cancel_operation"]

    @property
    def get_operation(
        self,
    ) -> Callable[[operations_pb2.GetOperationRequest], operations_pb2.Operation]:
        r"""Return a callable for the get_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_operation" not in self._stubs:
            self._stubs["get_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/GetOperation",
                request_serializer=operations_pb2.GetOperationRequest.SerializeToString,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["get_operation"]

    @property
    def list_operations(
        self,
    ) -> Callable[[operations_pb2.ListOperationsRequest], operations_pb2.ListOperationsResponse]:
        r"""Return a callable for the list_operations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_operations" not in self._stubs:
            self._stubs["list_operations"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/ListOperations",
                request_serializer=operations_pb2.ListOperationsRequest.SerializeToString,
                response_deserializer=operations_pb2.ListOperationsResponse.FromString,
            )
        return self._stubs["list_operations"]

    @property
    def list_locations(
        self,
    ) -> Callable[[locations_pb2.ListLocationsRequest], locations_pb2.ListLocationsResponse]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_locations" not in self._stubs:
            self._stubs["list_locations"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/ListLocations",
                request_serializer=locations_pb2.ListLocationsRequest.SerializeToString,
                response_deserializer=locations_pb2.ListLocationsResponse.FromString,
            )
        return self._stubs["list_locations"]

    @property
    def get_location(
        self,
    ) -> Callable[[locations_pb2.GetLocationRequest], locations_pb2.Location]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_location" not in self._stubs:
            self._stubs["get_location"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/GetLocation",
                request_serializer=locations_pb2.GetLocationRequest.SerializeToString,
                response_deserializer=locations_pb2.Location.FromString,
            )
        return self._stubs["get_location"]


__all__ = (
    'ConversationDatasetsGrpcAsyncIOTransport',
)
