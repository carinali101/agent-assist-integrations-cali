# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1
import google.protobuf

from google.protobuf import json_format
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v2beta1.types import conversational_training_assignment
from google.cloud.dialogflow_v2beta1.types import conversational_training_assignment as gcd_conversational_training_assignment
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseConversationalTrainingAssignmentsRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class ConversationalTrainingAssignmentsRestInterceptor:
    """Interceptor for ConversationalTrainingAssignments.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the ConversationalTrainingAssignmentsRestTransport.

    .. code-block:: python
        class MyCustomConversationalTrainingAssignmentsInterceptor(ConversationalTrainingAssignmentsRestInterceptor):
            def pre_batch_create_conversational_training_assignments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_batch_create_conversational_training_assignments(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_batch_delete_conversational_training_assignments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_batch_update_conversational_training_assignments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_batch_update_conversational_training_assignments(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_complete_conversational_training_assignment(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_complete_conversational_training_assignment(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_create_conversational_training_assignment(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_conversational_training_assignment(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_conversational_training_assignment(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_finalize_simulation_attempt(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_finalize_simulation_attempt(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_conversational_training_assignment(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_conversational_training_assignment(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_conversational_training_assignments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_conversational_training_assignments(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_update_conversational_training_assignment(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_update_conversational_training_assignment(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = ConversationalTrainingAssignmentsRestTransport(interceptor=MyCustomConversationalTrainingAssignmentsInterceptor())
        client = ConversationalTrainingAssignmentsClient(transport=transport)


    """
    def pre_batch_create_conversational_training_assignments(self, request: conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for batch_create_conversational_training_assignments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_batch_create_conversational_training_assignments(self, response: conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse) -> conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse:
        """Post-rpc interceptor for batch_create_conversational_training_assignments

        DEPRECATED. Please use the `post_batch_create_conversational_training_assignments_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_batch_create_conversational_training_assignments` interceptor runs
        before the `post_batch_create_conversational_training_assignments_with_metadata` interceptor.
        """
        return response

    def post_batch_create_conversational_training_assignments_with_metadata(self, response: conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for batch_create_conversational_training_assignments

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_batch_create_conversational_training_assignments_with_metadata`
        interceptor in new development instead of the `post_batch_create_conversational_training_assignments` interceptor.
        When both interceptors are used, this `post_batch_create_conversational_training_assignments_with_metadata` interceptor runs after the
        `post_batch_create_conversational_training_assignments` interceptor. The (possibly modified) response returned by
        `post_batch_create_conversational_training_assignments` will be passed to
        `post_batch_create_conversational_training_assignments_with_metadata`.
        """
        return response, metadata

    def pre_batch_delete_conversational_training_assignments(self, request: conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for batch_delete_conversational_training_assignments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def pre_batch_update_conversational_training_assignments(self, request: conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for batch_update_conversational_training_assignments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_batch_update_conversational_training_assignments(self, response: conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse) -> conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse:
        """Post-rpc interceptor for batch_update_conversational_training_assignments

        DEPRECATED. Please use the `post_batch_update_conversational_training_assignments_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_batch_update_conversational_training_assignments` interceptor runs
        before the `post_batch_update_conversational_training_assignments_with_metadata` interceptor.
        """
        return response

    def post_batch_update_conversational_training_assignments_with_metadata(self, response: conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for batch_update_conversational_training_assignments

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_batch_update_conversational_training_assignments_with_metadata`
        interceptor in new development instead of the `post_batch_update_conversational_training_assignments` interceptor.
        When both interceptors are used, this `post_batch_update_conversational_training_assignments_with_metadata` interceptor runs after the
        `post_batch_update_conversational_training_assignments` interceptor. The (possibly modified) response returned by
        `post_batch_update_conversational_training_assignments` will be passed to
        `post_batch_update_conversational_training_assignments_with_metadata`.
        """
        return response, metadata

    def pre_complete_conversational_training_assignment(self, request: conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for complete_conversational_training_assignment

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_complete_conversational_training_assignment(self, response: conversational_training_assignment.ConversationalTrainingAssignment) -> conversational_training_assignment.ConversationalTrainingAssignment:
        """Post-rpc interceptor for complete_conversational_training_assignment

        DEPRECATED. Please use the `post_complete_conversational_training_assignment_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_complete_conversational_training_assignment` interceptor runs
        before the `post_complete_conversational_training_assignment_with_metadata` interceptor.
        """
        return response

    def post_complete_conversational_training_assignment_with_metadata(self, response: conversational_training_assignment.ConversationalTrainingAssignment, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.ConversationalTrainingAssignment, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for complete_conversational_training_assignment

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_complete_conversational_training_assignment_with_metadata`
        interceptor in new development instead of the `post_complete_conversational_training_assignment` interceptor.
        When both interceptors are used, this `post_complete_conversational_training_assignment_with_metadata` interceptor runs after the
        `post_complete_conversational_training_assignment` interceptor. The (possibly modified) response returned by
        `post_complete_conversational_training_assignment` will be passed to
        `post_complete_conversational_training_assignment_with_metadata`.
        """
        return response, metadata

    def pre_create_conversational_training_assignment(self, request: gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_conversational_training_assignment

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_create_conversational_training_assignment(self, response: gcd_conversational_training_assignment.ConversationalTrainingAssignment) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
        """Post-rpc interceptor for create_conversational_training_assignment

        DEPRECATED. Please use the `post_create_conversational_training_assignment_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_create_conversational_training_assignment` interceptor runs
        before the `post_create_conversational_training_assignment_with_metadata` interceptor.
        """
        return response

    def post_create_conversational_training_assignment_with_metadata(self, response: gcd_conversational_training_assignment.ConversationalTrainingAssignment, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversational_training_assignment.ConversationalTrainingAssignment, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_conversational_training_assignment

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_create_conversational_training_assignment_with_metadata`
        interceptor in new development instead of the `post_create_conversational_training_assignment` interceptor.
        When both interceptors are used, this `post_create_conversational_training_assignment_with_metadata` interceptor runs after the
        `post_create_conversational_training_assignment` interceptor. The (possibly modified) response returned by
        `post_create_conversational_training_assignment` will be passed to
        `post_create_conversational_training_assignment_with_metadata`.
        """
        return response, metadata

    def pre_delete_conversational_training_assignment(self, request: conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_conversational_training_assignment

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def pre_finalize_simulation_attempt(self, request: conversational_training_assignment.FinalizeSimulationAttemptRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.FinalizeSimulationAttemptRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for finalize_simulation_attempt

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_finalize_simulation_attempt(self, response: conversational_training_assignment.ConversationalTrainingAssignment) -> conversational_training_assignment.ConversationalTrainingAssignment:
        """Post-rpc interceptor for finalize_simulation_attempt

        DEPRECATED. Please use the `post_finalize_simulation_attempt_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_finalize_simulation_attempt` interceptor runs
        before the `post_finalize_simulation_attempt_with_metadata` interceptor.
        """
        return response

    def post_finalize_simulation_attempt_with_metadata(self, response: conversational_training_assignment.ConversationalTrainingAssignment, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.ConversationalTrainingAssignment, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for finalize_simulation_attempt

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_finalize_simulation_attempt_with_metadata`
        interceptor in new development instead of the `post_finalize_simulation_attempt` interceptor.
        When both interceptors are used, this `post_finalize_simulation_attempt_with_metadata` interceptor runs after the
        `post_finalize_simulation_attempt` interceptor. The (possibly modified) response returned by
        `post_finalize_simulation_attempt` will be passed to
        `post_finalize_simulation_attempt_with_metadata`.
        """
        return response, metadata

    def pre_get_conversational_training_assignment(self, request: conversational_training_assignment.GetConversationalTrainingAssignmentRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.GetConversationalTrainingAssignmentRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_conversational_training_assignment

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_get_conversational_training_assignment(self, response: conversational_training_assignment.ConversationalTrainingAssignment) -> conversational_training_assignment.ConversationalTrainingAssignment:
        """Post-rpc interceptor for get_conversational_training_assignment

        DEPRECATED. Please use the `post_get_conversational_training_assignment_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_get_conversational_training_assignment` interceptor runs
        before the `post_get_conversational_training_assignment_with_metadata` interceptor.
        """
        return response

    def post_get_conversational_training_assignment_with_metadata(self, response: conversational_training_assignment.ConversationalTrainingAssignment, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.ConversationalTrainingAssignment, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_conversational_training_assignment

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_get_conversational_training_assignment_with_metadata`
        interceptor in new development instead of the `post_get_conversational_training_assignment` interceptor.
        When both interceptors are used, this `post_get_conversational_training_assignment_with_metadata` interceptor runs after the
        `post_get_conversational_training_assignment` interceptor. The (possibly modified) response returned by
        `post_get_conversational_training_assignment` will be passed to
        `post_get_conversational_training_assignment_with_metadata`.
        """
        return response, metadata

    def pre_list_conversational_training_assignments(self, request: conversational_training_assignment.ListConversationalTrainingAssignmentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.ListConversationalTrainingAssignmentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_conversational_training_assignments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_list_conversational_training_assignments(self, response: conversational_training_assignment.ListConversationalTrainingAssignmentsResponse) -> conversational_training_assignment.ListConversationalTrainingAssignmentsResponse:
        """Post-rpc interceptor for list_conversational_training_assignments

        DEPRECATED. Please use the `post_list_conversational_training_assignments_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_list_conversational_training_assignments` interceptor runs
        before the `post_list_conversational_training_assignments_with_metadata` interceptor.
        """
        return response

    def post_list_conversational_training_assignments_with_metadata(self, response: conversational_training_assignment.ListConversationalTrainingAssignmentsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversational_training_assignment.ListConversationalTrainingAssignmentsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_conversational_training_assignments

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_list_conversational_training_assignments_with_metadata`
        interceptor in new development instead of the `post_list_conversational_training_assignments` interceptor.
        When both interceptors are used, this `post_list_conversational_training_assignments_with_metadata` interceptor runs after the
        `post_list_conversational_training_assignments` interceptor. The (possibly modified) response returned by
        `post_list_conversational_training_assignments` will be passed to
        `post_list_conversational_training_assignments_with_metadata`.
        """
        return response, metadata

    def pre_update_conversational_training_assignment(self, request: gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for update_conversational_training_assignment

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_update_conversational_training_assignment(self, response: gcd_conversational_training_assignment.ConversationalTrainingAssignment) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
        """Post-rpc interceptor for update_conversational_training_assignment

        DEPRECATED. Please use the `post_update_conversational_training_assignment_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code. This `post_update_conversational_training_assignment` interceptor runs
        before the `post_update_conversational_training_assignment_with_metadata` interceptor.
        """
        return response

    def post_update_conversational_training_assignment_with_metadata(self, response: gcd_conversational_training_assignment.ConversationalTrainingAssignment, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversational_training_assignment.ConversationalTrainingAssignment, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for update_conversational_training_assignment

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the ConversationalTrainingAssignments server but before it is returned to user code.

        We recommend only using this `post_update_conversational_training_assignment_with_metadata`
        interceptor in new development instead of the `post_update_conversational_training_assignment` interceptor.
        When both interceptors are used, this `post_update_conversational_training_assignment_with_metadata` interceptor runs after the
        `post_update_conversational_training_assignment` interceptor. The (possibly modified) response returned by
        `post_update_conversational_training_assignment` will be passed to
        `post_update_conversational_training_assignment_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the ConversationalTrainingAssignments server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the ConversationalTrainingAssignments server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class ConversationalTrainingAssignmentsRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: ConversationalTrainingAssignmentsRestInterceptor


class ConversationalTrainingAssignmentsRestTransport(_BaseConversationalTrainingAssignmentsRestTransport):
    """REST backend synchronous transport for ConversationalTrainingAssignments.

    Service for creating and managing conversational training
    assignment resources.

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[ConversationalTrainingAssignmentsRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided. This argument will be
                removed in the next major version of this library.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or ConversationalTrainingAssignmentsRestInterceptor()
        self._prep_wrapped_messages(client_info)

    class _BatchCreateConversationalTrainingAssignments(_BaseConversationalTrainingAssignmentsRestTransport._BaseBatchCreateConversationalTrainingAssignments, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.BatchCreateConversationalTrainingAssignments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse:
            r"""Call the batch create
        conversational training assignments method over HTTP.

            Args:
                request (~.conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest):
                    The request object. Request message of
                BatchCreateConversationalTrainingAssignment.

                All individual requests must have the same
                ``batch_uuid``. If no ``batch_uuid`` is provided, a new
                UUID will be generated for the entire batch.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse:
                    Response message of
                BatchCreateConversationalTrainingAssignment.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchCreateConversationalTrainingAssignments._get_http_options()

            request, metadata = self._interceptor.pre_batch_create_conversational_training_assignments(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchCreateConversationalTrainingAssignments._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchCreateConversationalTrainingAssignments._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchCreateConversationalTrainingAssignments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.BatchCreateConversationalTrainingAssignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "BatchCreateConversationalTrainingAssignments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._BatchCreateConversationalTrainingAssignments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse()
            pb_resp = conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_batch_create_conversational_training_assignments(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_batch_create_conversational_training_assignments_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.batch_create_conversational_training_assignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "BatchCreateConversationalTrainingAssignments",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _BatchDeleteConversationalTrainingAssignments(_BaseConversationalTrainingAssignmentsRestTransport._BaseBatchDeleteConversationalTrainingAssignments, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.BatchDeleteConversationalTrainingAssignments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the batch delete
        conversational training assignments method over HTTP.

            Args:
                request (~.conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest):
                    The request object. Request message of
                BatchDeleteConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchDeleteConversationalTrainingAssignments._get_http_options()

            request, metadata = self._interceptor.pre_batch_delete_conversational_training_assignments(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchDeleteConversationalTrainingAssignments._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchDeleteConversationalTrainingAssignments._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchDeleteConversationalTrainingAssignments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.BatchDeleteConversationalTrainingAssignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "BatchDeleteConversationalTrainingAssignments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._BatchDeleteConversationalTrainingAssignments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _BatchUpdateConversationalTrainingAssignments(_BaseConversationalTrainingAssignmentsRestTransport._BaseBatchUpdateConversationalTrainingAssignments, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.BatchUpdateConversationalTrainingAssignments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse:
            r"""Call the batch update
        conversational training assignments method over HTTP.

            Args:
                request (~.conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest):
                    The request object. Request message of
                BatchUpdateConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse:
                    Response message of
                BatchUpdateConversationalTrainingAssignment.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchUpdateConversationalTrainingAssignments._get_http_options()

            request, metadata = self._interceptor.pre_batch_update_conversational_training_assignments(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchUpdateConversationalTrainingAssignments._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchUpdateConversationalTrainingAssignments._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseBatchUpdateConversationalTrainingAssignments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.BatchUpdateConversationalTrainingAssignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "BatchUpdateConversationalTrainingAssignments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._BatchUpdateConversationalTrainingAssignments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse()
            pb_resp = conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_batch_update_conversational_training_assignments(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_batch_update_conversational_training_assignments_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.batch_update_conversational_training_assignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "BatchUpdateConversationalTrainingAssignments",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CompleteConversationalTrainingAssignment(_BaseConversationalTrainingAssignmentsRestTransport._BaseCompleteConversationalTrainingAssignment, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.CompleteConversationalTrainingAssignment")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.ConversationalTrainingAssignment:
            r"""Call the complete conversational
        training assignment method over HTTP.

            Args:
                request (~.conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest):
                    The request object. Request message of
                CompleteConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.ConversationalTrainingAssignment:
                    A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseCompleteConversationalTrainingAssignment._get_http_options()

            request, metadata = self._interceptor.pre_complete_conversational_training_assignment(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseCompleteConversationalTrainingAssignment._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseCompleteConversationalTrainingAssignment._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseCompleteConversationalTrainingAssignment._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.CompleteConversationalTrainingAssignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "CompleteConversationalTrainingAssignment",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._CompleteConversationalTrainingAssignment._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.ConversationalTrainingAssignment()
            pb_resp = conversational_training_assignment.ConversationalTrainingAssignment.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_complete_conversational_training_assignment(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_complete_conversational_training_assignment_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.ConversationalTrainingAssignment.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.complete_conversational_training_assignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "CompleteConversationalTrainingAssignment",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CreateConversationalTrainingAssignment(_BaseConversationalTrainingAssignmentsRestTransport._BaseCreateConversationalTrainingAssignment, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.CreateConversationalTrainingAssignment")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
            r"""Call the create conversational
        training assignment method over HTTP.

            Args:
                request (~.gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest):
                    The request object. Request message of
                CreateConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversational_training_assignment.ConversationalTrainingAssignment:
                    A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseCreateConversationalTrainingAssignment._get_http_options()

            request, metadata = self._interceptor.pre_create_conversational_training_assignment(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseCreateConversationalTrainingAssignment._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseCreateConversationalTrainingAssignment._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseCreateConversationalTrainingAssignment._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.CreateConversationalTrainingAssignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "CreateConversationalTrainingAssignment",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._CreateConversationalTrainingAssignment._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversational_training_assignment.ConversationalTrainingAssignment()
            pb_resp = gcd_conversational_training_assignment.ConversationalTrainingAssignment.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_conversational_training_assignment(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_conversational_training_assignment_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversational_training_assignment.ConversationalTrainingAssignment.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.create_conversational_training_assignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "CreateConversationalTrainingAssignment",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteConversationalTrainingAssignment(_BaseConversationalTrainingAssignmentsRestTransport._BaseDeleteConversationalTrainingAssignment, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.DeleteConversationalTrainingAssignment")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete conversational
        training assignment method over HTTP.

            Args:
                request (~.conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest):
                    The request object. Request of
                DeleteConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseDeleteConversationalTrainingAssignment._get_http_options()

            request, metadata = self._interceptor.pre_delete_conversational_training_assignment(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseDeleteConversationalTrainingAssignment._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseDeleteConversationalTrainingAssignment._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.DeleteConversationalTrainingAssignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "DeleteConversationalTrainingAssignment",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._DeleteConversationalTrainingAssignment._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _FinalizeSimulationAttempt(_BaseConversationalTrainingAssignmentsRestTransport._BaseFinalizeSimulationAttempt, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.FinalizeSimulationAttempt")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.FinalizeSimulationAttemptRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.ConversationalTrainingAssignment:
            r"""Call the finalize simulation
        attempt method over HTTP.

            Args:
                request (~.conversational_training_assignment.FinalizeSimulationAttemptRequest):
                    The request object. Request message of
                FinalizeSimulationAttempt.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.ConversationalTrainingAssignment:
                    A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseFinalizeSimulationAttempt._get_http_options()

            request, metadata = self._interceptor.pre_finalize_simulation_attempt(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseFinalizeSimulationAttempt._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseFinalizeSimulationAttempt._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseFinalizeSimulationAttempt._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.FinalizeSimulationAttempt",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "FinalizeSimulationAttempt",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._FinalizeSimulationAttempt._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.ConversationalTrainingAssignment()
            pb_resp = conversational_training_assignment.ConversationalTrainingAssignment.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_finalize_simulation_attempt(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_finalize_simulation_attempt_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.ConversationalTrainingAssignment.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.finalize_simulation_attempt",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "FinalizeSimulationAttempt",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetConversationalTrainingAssignment(_BaseConversationalTrainingAssignmentsRestTransport._BaseGetConversationalTrainingAssignment, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.GetConversationalTrainingAssignment")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.GetConversationalTrainingAssignmentRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.ConversationalTrainingAssignment:
            r"""Call the get conversational
        training assignment method over HTTP.

            Args:
                request (~.conversational_training_assignment.GetConversationalTrainingAssignmentRequest):
                    The request object. Request message of
                GetConversationalTrainingAssignment.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.ConversationalTrainingAssignment:
                    A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetConversationalTrainingAssignment._get_http_options()

            request, metadata = self._interceptor.pre_get_conversational_training_assignment(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetConversationalTrainingAssignment._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetConversationalTrainingAssignment._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.GetConversationalTrainingAssignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetConversationalTrainingAssignment",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._GetConversationalTrainingAssignment._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.ConversationalTrainingAssignment()
            pb_resp = conversational_training_assignment.ConversationalTrainingAssignment.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_conversational_training_assignment(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_conversational_training_assignment_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.ConversationalTrainingAssignment.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.get_conversational_training_assignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetConversationalTrainingAssignment",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListConversationalTrainingAssignments(_BaseConversationalTrainingAssignmentsRestTransport._BaseListConversationalTrainingAssignments, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.ListConversationalTrainingAssignments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversational_training_assignment.ListConversationalTrainingAssignmentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversational_training_assignment.ListConversationalTrainingAssignmentsResponse:
            r"""Call the list conversational
        training assignments method over HTTP.

            Args:
                request (~.conversational_training_assignment.ListConversationalTrainingAssignmentsRequest):
                    The request object. Request message of
                ListConversationalTrainingAssignments.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversational_training_assignment.ListConversationalTrainingAssignmentsResponse:
                    Response of
                ListConversationalTrainingAssignments.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseListConversationalTrainingAssignments._get_http_options()

            request, metadata = self._interceptor.pre_list_conversational_training_assignments(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseListConversationalTrainingAssignments._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseListConversationalTrainingAssignments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.ListConversationalTrainingAssignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListConversationalTrainingAssignments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._ListConversationalTrainingAssignments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversational_training_assignment.ListConversationalTrainingAssignmentsResponse()
            pb_resp = conversational_training_assignment.ListConversationalTrainingAssignmentsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_conversational_training_assignments(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_conversational_training_assignments_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversational_training_assignment.ListConversationalTrainingAssignmentsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.list_conversational_training_assignments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListConversationalTrainingAssignments",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _UpdateConversationalTrainingAssignment(_BaseConversationalTrainingAssignmentsRestTransport._BaseUpdateConversationalTrainingAssignment, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.UpdateConversationalTrainingAssignment")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversational_training_assignment.ConversationalTrainingAssignment:
            r"""Call the update conversational
        training assignment method over HTTP.

            Args:
                request (~.gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest):
                    The request object. Request of
                UpdateConversationalTrainingAssignment.
                Should only be used by managers to
                prevent directly setting assignment
                progress.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversational_training_assignment.ConversationalTrainingAssignment:
                    A conversational training assignment
                that includes members that should get
                similar assignments and managed by the
                same group of managers.

            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseUpdateConversationalTrainingAssignment._get_http_options()

            request, metadata = self._interceptor.pre_update_conversational_training_assignment(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseUpdateConversationalTrainingAssignment._get_transcoded_request(http_options, request)

            body = _BaseConversationalTrainingAssignmentsRestTransport._BaseUpdateConversationalTrainingAssignment._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseUpdateConversationalTrainingAssignment._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.UpdateConversationalTrainingAssignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "UpdateConversationalTrainingAssignment",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._UpdateConversationalTrainingAssignment._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversational_training_assignment.ConversationalTrainingAssignment()
            pb_resp = gcd_conversational_training_assignment.ConversationalTrainingAssignment.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_update_conversational_training_assignment(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_update_conversational_training_assignment_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversational_training_assignment.ConversationalTrainingAssignment.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.update_conversational_training_assignment",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "UpdateConversationalTrainingAssignment",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def batch_create_conversational_training_assignments(self) -> Callable[
            [conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsRequest],
            conversational_training_assignment.BatchCreateConversationalTrainingAssignmentsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._BatchCreateConversationalTrainingAssignments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def batch_delete_conversational_training_assignments(self) -> Callable[
            [conversational_training_assignment.BatchDeleteConversationalTrainingAssignmentsRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._BatchDeleteConversationalTrainingAssignments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def batch_update_conversational_training_assignments(self) -> Callable[
            [conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsRequest],
            conversational_training_assignment.BatchUpdateConversationalTrainingAssignmentsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._BatchUpdateConversationalTrainingAssignments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def complete_conversational_training_assignment(self) -> Callable[
            [conversational_training_assignment.CompleteConversationalTrainingAssignmentRequest],
            conversational_training_assignment.ConversationalTrainingAssignment]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CompleteConversationalTrainingAssignment(self._session, self._host, self._interceptor) # type: ignore

    @property
    def create_conversational_training_assignment(self) -> Callable[
            [gcd_conversational_training_assignment.CreateConversationalTrainingAssignmentRequest],
            gcd_conversational_training_assignment.ConversationalTrainingAssignment]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateConversationalTrainingAssignment(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_conversational_training_assignment(self) -> Callable[
            [conversational_training_assignment.DeleteConversationalTrainingAssignmentRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteConversationalTrainingAssignment(self._session, self._host, self._interceptor) # type: ignore

    @property
    def finalize_simulation_attempt(self) -> Callable[
            [conversational_training_assignment.FinalizeSimulationAttemptRequest],
            conversational_training_assignment.ConversationalTrainingAssignment]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._FinalizeSimulationAttempt(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_conversational_training_assignment(self) -> Callable[
            [conversational_training_assignment.GetConversationalTrainingAssignmentRequest],
            conversational_training_assignment.ConversationalTrainingAssignment]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetConversationalTrainingAssignment(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_conversational_training_assignments(self) -> Callable[
            [conversational_training_assignment.ListConversationalTrainingAssignmentsRequest],
            conversational_training_assignment.ListConversationalTrainingAssignmentsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListConversationalTrainingAssignments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def update_conversational_training_assignment(self) -> Callable[
            [gcd_conversational_training_assignment.UpdateConversationalTrainingAssignmentRequest],
            gcd_conversational_training_assignment.ConversationalTrainingAssignment]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._UpdateConversationalTrainingAssignment(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseConversationalTrainingAssignmentsRestTransport._BaseGetLocation, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseConversationalTrainingAssignmentsRestTransport._BaseListLocations, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseConversationalTrainingAssignmentsRestTransport._BaseCancelOperation, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseConversationalTrainingAssignmentsRestTransport._BaseGetOperation, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseConversationalTrainingAssignmentsRestTransport._BaseListOperations, ConversationalTrainingAssignmentsRestStub):
        def __hash__(self):
            return hash("ConversationalTrainingAssignmentsRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseConversationalTrainingAssignmentsRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseConversationalTrainingAssignmentsRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationalTrainingAssignmentsRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationalTrainingAssignmentsRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationalTrainingAssignmentsAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.ConversationalTrainingAssignments",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'ConversationalTrainingAssignmentsRestTransport',
)
