
transport inheritance structure
_______________________________

`ConversationalTrainingModulesTransport` is the ABC for all transports.
- public child `ConversationalTrainingModulesGrpcTransport` for sync gRPC transport (defined in `grpc.py`).
- public child `ConversationalTrainingModulesGrpcAsyncIOTransport` for async gRPC transport (defined in `grpc_asyncio.py`).
- private child `_BaseConversationalTrainingModulesRestTransport` for base REST transport with inner classes `_BaseMETHOD` (defined in `rest_base.py`).
- public child `ConversationalTrainingModulesRestTransport` for sync REST transport with inner classes `METHOD` derived from the parent's corresponding `_BaseMETHOD` classes (defined in `rest.py`).
