# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import inspect
import json
import pickle
import logging as std_logging
import warnings
from typing import Awaitable, Callable, Dict, Optional, Sequence, Tuple, Union

from google.api_core import gapic_v1
from google.api_core import grpc_helpers_async
from google.api_core import exceptions as core_exceptions
from google.api_core import retry_async as retries
from google.api_core import operations_v1
from google.auth import credentials as ga_credentials   # type: ignore
from google.auth.transport.grpc import SslCredentials  # type: ignore
from google.protobuf.json_format import MessageToJson
import google.protobuf.message

import grpc                        # type: ignore
import proto                       # type: ignore
from grpc.experimental import aio  # type: ignore

from google.cloud.dialogflow_v2beta1.types import conversation
from google.cloud.dialogflow_v2beta1.types import conversation as gcd_conversation
from google.cloud.dialogflow_v2beta1.types import interaction_monitoring
from google.cloud.dialogflow_v2beta1.types import participant
from google.cloud.location import locations_pb2 # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from google.protobuf import empty_pb2  # type: ignore
from .base import ConversationsTransport, DEFAULT_CLIENT_INFO
from .grpc import ConversationsGrpcTransport

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = std_logging.getLogger(__name__)


class _LoggingClientAIOInterceptor(grpc.aio.UnaryUnaryClientInterceptor):  # pragma: NO COVER
    async def intercept_unary_unary(self, continuation, client_call_details, request):
        logging_enabled = CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(std_logging.DEBUG)
        if logging_enabled:  # pragma: NO COVER
            request_metadata = client_call_details.metadata
            if isinstance(request, proto.Message):
                request_payload = type(request).to_json(request)
            elif isinstance(request, google.protobuf.message.Message):
                request_payload = MessageToJson(request)
            else:
                request_payload = f"{type(request).__name__}: {pickle.dumps(request)}"

            request_metadata = {
                key: value.decode("utf-8") if isinstance(value, bytes) else value
                for key, value in request_metadata
            }
            grpc_request = {
                "payload": request_payload,
                "requestMethod": "grpc",
                "metadata": dict(request_metadata),
            }
            _LOGGER.debug(
                f"Sending request for {client_call_details.method}",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                    "rpcName": str(client_call_details.method),
                    "request": grpc_request,
                    "metadata": grpc_request["metadata"],
                },
            )
        response = await continuation(client_call_details, request)
        if logging_enabled:  # pragma: NO COVER
            response_metadata = await response.trailing_metadata()
            # Convert gRPC metadata `<class 'grpc.aio._metadata.Metadata'>` to list of tuples
            metadata = dict([(k, str(v)) for k, v in response_metadata]) if response_metadata else None
            result = await response
            if isinstance(result, proto.Message):
                response_payload = type(result).to_json(result)
            elif isinstance(result, google.protobuf.message.Message):
                response_payload = MessageToJson(result)
            else:
                response_payload = f"{type(result).__name__}: {pickle.dumps(result)}"
            grpc_response = {
                "payload": response_payload,
                "metadata": metadata,
                "status": "OK",
            }
            _LOGGER.debug(
                f"Received response to rpc {client_call_details.method}.",
                extra = {
                    "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                    "rpcName": str(client_call_details.method),
                    "response": grpc_response,
                    "metadata": grpc_response["metadata"],
                },
            )
        return response


class ConversationsGrpcAsyncIOTransport(ConversationsTransport):
    """gRPC AsyncIO backend transport for Conversations.

    Service for managing
    [Conversations][google.cloud.dialogflow.v2beta1.Conversation].

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends protocol buffers over the wire using gRPC (which is built on
    top of HTTP/2); the ``grpcio`` package must be installed.
    """

    _grpc_channel: aio.Channel
    _stubs: Dict[str, Callable] = {}

    @classmethod
    def create_channel(cls,
                       host: str = 'dialogflow.googleapis.com',
                       credentials: Optional[ga_credentials.Credentials] = None,
                       credentials_file: Optional[str] = None,
                       scopes: Optional[Sequence[str]] = None,
                       quota_project_id: Optional[str] = None,
                       **kwargs) -> aio.Channel:
        """Create and return a gRPC AsyncIO channel object.
        Args:
            host (Optional[str]): The host for the channel to use.
            credentials (Optional[~.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify this application to the service. If
                none are specified, the client will attempt to ascertain
                the credentials from the environment.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`. This argument will be
                removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            kwargs (Optional[dict]): Keyword arguments, which are passed to the
                channel creation.
        Returns:
            aio.Channel: A gRPC AsyncIO channel object.
        """

        return grpc_helpers_async.create_channel(
            host,
            credentials=credentials,
            credentials_file=credentials_file,
            quota_project_id=quota_project_id,
            default_scopes=cls.AUTH_SCOPES,
            scopes=scopes,
            default_host=cls.DEFAULT_HOST,
            **kwargs
        )

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            channel: Optional[Union[aio.Channel, Callable[..., aio.Channel]]] = None,
            api_mtls_endpoint: Optional[str] = None,
            client_cert_source: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            ssl_channel_credentials: Optional[grpc.ChannelCredentials] = None,
            client_cert_source_for_mtls: Optional[Callable[[], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.
                This argument is ignored if a ``channel`` instance is provided.
            credentials_file (Optional[str]): Deprecated. A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if a ``channel`` instance is provided.
                This argument will be removed in the next major version of this library.
            scopes (Optional[Sequence[str]]): A optional list of scopes needed for this
                service. These are only used when credentials are not specified and
                are passed to :func:`google.auth.default`.
            channel (Optional[Union[aio.Channel, Callable[..., aio.Channel]]]):
                A ``Channel`` instance through which to make calls, or a Callable
                that constructs and returns one. If set to None, ``self.create_channel``
                is used to create the channel. If a Callable is given, it will be called
                with the same arguments as used in ``self.create_channel``.
            api_mtls_endpoint (Optional[str]): Deprecated. The mutual TLS endpoint.
                If provided, it overrides the ``host`` argument and tries to create
                a mutual TLS channel with client SSL credentials from
                ``client_cert_source`` or application default SSL credentials.
            client_cert_source (Optional[Callable[[], Tuple[bytes, bytes]]]):
                Deprecated. A callback to provide client SSL certificate bytes and
                private key bytes, both in PEM format. It is ignored if
                ``api_mtls_endpoint`` is None.
            ssl_channel_credentials (grpc.ChannelCredentials): SSL credentials
                for the grpc channel. It is ignored if a ``channel`` instance is provided.
            client_cert_source_for_mtls (Optional[Callable[[], Tuple[bytes, bytes]]]):
                A callback to provide client certificate bytes and private key bytes,
                both in PEM format. It is used to configure a mutual TLS channel. It is
                ignored if a ``channel`` instance or ``ssl_channel_credentials`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you're developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.

        Raises:
            google.auth.exceptions.MutualTlsChannelError: If mutual TLS transport
              creation failed for any reason.
          google.api_core.exceptions.DuplicateCredentialArgs: If both ``credentials``
              and ``credentials_file`` are passed.
        """
        self._grpc_channel = None
        self._ssl_channel_credentials = ssl_channel_credentials
        self._stubs: Dict[str, Callable] = {}
        self._operations_client: Optional[operations_v1.OperationsAsyncClient] = None

        if api_mtls_endpoint:
            warnings.warn("api_mtls_endpoint is deprecated", DeprecationWarning)
        if client_cert_source:
            warnings.warn("client_cert_source is deprecated", DeprecationWarning)

        if isinstance(channel, aio.Channel):
            # Ignore credentials if a channel was passed.
            credentials = None
            self._ignore_credentials = True
            # If a channel was explicitly provided, set it.
            self._grpc_channel = channel
            self._ssl_channel_credentials = None
        else:
            if api_mtls_endpoint:
                host = api_mtls_endpoint

                # Create SSL credentials with client_cert_source or application
                # default SSL credentials.
                if client_cert_source:
                    cert, key = client_cert_source()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )
                else:
                    self._ssl_channel_credentials = SslCredentials().ssl_credentials

            else:
                if client_cert_source_for_mtls and not ssl_channel_credentials:
                    cert, key = client_cert_source_for_mtls()
                    self._ssl_channel_credentials = grpc.ssl_channel_credentials(
                        certificate_chain=cert, private_key=key
                    )

        # The base transport sets the host, credentials and scopes
        super().__init__(
            host=host,
            credentials=credentials,
            credentials_file=credentials_file,
            scopes=scopes,
            quota_project_id=quota_project_id,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            api_audience=api_audience,
        )

        if not self._grpc_channel:
            # initialize with the provided callable or the default channel
            channel_init = channel or type(self).create_channel
            self._grpc_channel = channel_init(
                self._host,
                # use the credentials which are saved
                credentials=self._credentials,
                # Set ``credentials_file`` to ``None`` here as
                # the credentials that we saved earlier should be used.
                credentials_file=None,
                scopes=self._scopes,
                ssl_credentials=self._ssl_channel_credentials,
                quota_project_id=quota_project_id,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )

        self._interceptor = _LoggingClientAIOInterceptor()
        self._grpc_channel._unary_unary_interceptors.append(self._interceptor)
        self._logged_channel = self._grpc_channel
        self._wrap_with_kind = "kind" in inspect.signature(gapic_v1.method_async.wrap_method).parameters
        # Wrap messages. This must be done after self._logged_channel exists
        self._prep_wrapped_messages(client_info)

    @property
    def grpc_channel(self) -> aio.Channel:
        """Create the channel designed to connect to this service.

        This property caches on the instance; repeated calls return
        the same channel.
        """
        # Return the channel from cache.
        return self._grpc_channel

    @property
    def operations_client(self) -> operations_v1.OperationsAsyncClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Quick check: Only create a new client if we do not already have one.
        if self._operations_client is None:
            self._operations_client = operations_v1.OperationsAsyncClient(
                self._logged_channel
            )

        # Return the client from cache.
        return self._operations_client

    @property
    def create_conversation(self) -> Callable[
            [gcd_conversation.CreateConversationRequest],
            Awaitable[gcd_conversation.Conversation]]:
        r"""Return a callable for the create conversation method over gRPC.

        Creates a new conversation. Conversations are auto-completed
        after 24 hours.

        Conversation Lifecycle: There are two stages during a
        conversation: Automated Agent Stage and Assist Stage.

        For Automated Agent Stage, there will be a dialogflow agent
        responding to user queries.

        For Assist Stage, there's no dialogflow agent responding to user
        queries. But we will provide suggestions which are generated
        from conversation.

        If
        [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
        is configured for a dialogflow agent, conversation will start
        from ``Automated Agent Stage``, otherwise, it will start from
        ``Assist Stage``. And during ``Automated Agent Stage``, once an
        [Intent][google.cloud.dialogflow.v2beta1.Intent] with
        [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
        is triggered, conversation will transfer to Assist Stage.

        Returns:
            Callable[[~.CreateConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'create_conversation' not in self._stubs:
            self._stubs['create_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/CreateConversation',
                request_serializer=gcd_conversation.CreateConversationRequest.serialize,
                response_deserializer=gcd_conversation.Conversation.deserialize,
            )
        return self._stubs['create_conversation']

    @property
    def list_conversations(self) -> Callable[
            [conversation.ListConversationsRequest],
            Awaitable[conversation.ListConversationsResponse]]:
        r"""Return a callable for the list conversations method over gRPC.

        Returns the list of all conversations in the
        specified project.

        Returns:
            Callable[[~.ListConversationsRequest],
                    Awaitable[~.ListConversationsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_conversations' not in self._stubs:
            self._stubs['list_conversations'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListConversations',
                request_serializer=conversation.ListConversationsRequest.serialize,
                response_deserializer=conversation.ListConversationsResponse.deserialize,
            )
        return self._stubs['list_conversations']

    @property
    def get_conversation(self) -> Callable[
            [conversation.GetConversationRequest],
            Awaitable[conversation.Conversation]]:
        r"""Return a callable for the get conversation method over gRPC.

        Retrieves the specific conversation.

        Returns:
            Callable[[~.GetConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_conversation' not in self._stubs:
            self._stubs['get_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GetConversation',
                request_serializer=conversation.GetConversationRequest.serialize,
                response_deserializer=conversation.Conversation.deserialize,
            )
        return self._stubs['get_conversation']

    @property
    def add_conversation_phone_number(self) -> Callable[
            [conversation.AddConversationPhoneNumberRequest],
            Awaitable[conversation.ConversationPhoneNumber]]:
        r"""Return a callable for the add conversation phone number method over gRPC.

        Sets a phone number for this conversation to connect to. Note:
        The conversation in the request must be in IN_PROGRESS status
        and must have no phone number attached.

        Returns:
            Callable[[~.AddConversationPhoneNumberRequest],
                    Awaitable[~.ConversationPhoneNumber]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'add_conversation_phone_number' not in self._stubs:
            self._stubs['add_conversation_phone_number'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/AddConversationPhoneNumber',
                request_serializer=conversation.AddConversationPhoneNumberRequest.serialize,
                response_deserializer=conversation.ConversationPhoneNumber.deserialize,
            )
        return self._stubs['add_conversation_phone_number']

    @property
    def activate_conversation(self) -> Callable[
            [gcd_conversation.ActivateConversationRequest],
            Awaitable[gcd_conversation.Conversation]]:
        r"""Return a callable for the activate conversation method over gRPC.

        Activates the specified conversation.
        Used for telephony-based conversations that are started
        with inactive SIP attribute.

        Returns:
            Callable[[~.ActivateConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'activate_conversation' not in self._stubs:
            self._stubs['activate_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ActivateConversation',
                request_serializer=gcd_conversation.ActivateConversationRequest.serialize,
                response_deserializer=gcd_conversation.Conversation.deserialize,
            )
        return self._stubs['activate_conversation']

    @property
    def deactivate_conversation(self) -> Callable[
            [gcd_conversation.DeactivateConversationRequest],
            Awaitable[gcd_conversation.Conversation]]:
        r"""Return a callable for the deactivate conversation method over gRPC.

        Deactivates the specified conversation.
        Sets the SDP direction of the telephony call associated
        with this conversation to inactive.

        Returns:
            Callable[[~.DeactivateConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'deactivate_conversation' not in self._stubs:
            self._stubs['deactivate_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/DeactivateConversation',
                request_serializer=gcd_conversation.DeactivateConversationRequest.serialize,
                response_deserializer=gcd_conversation.Conversation.deserialize,
            )
        return self._stubs['deactivate_conversation']

    @property
    def complete_conversation(self) -> Callable[
            [conversation.CompleteConversationRequest],
            Awaitable[conversation.Conversation]]:
        r"""Return a callable for the complete conversation method over gRPC.

        Completes the specified conversation. Finished
        conversations are purged from the database after 30
        days.

        Returns:
            Callable[[~.CompleteConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'complete_conversation' not in self._stubs:
            self._stubs['complete_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/CompleteConversation',
                request_serializer=conversation.CompleteConversationRequest.serialize,
                response_deserializer=conversation.Conversation.deserialize,
            )
        return self._stubs['complete_conversation']

    @property
    def update_conversation(self) -> Callable[
            [gcd_conversation.UpdateConversationRequest],
            Awaitable[gcd_conversation.Conversation]]:
        r"""Return a callable for the update conversation method over gRPC.

        Updates the specified conversation.

        Returns:
            Callable[[~.UpdateConversationRequest],
                    Awaitable[~.Conversation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'update_conversation' not in self._stubs:
            self._stubs['update_conversation'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/UpdateConversation',
                request_serializer=gcd_conversation.UpdateConversationRequest.serialize,
                response_deserializer=gcd_conversation.Conversation.deserialize,
            )
        return self._stubs['update_conversation']

    @property
    def ingest_context_references(self) -> Callable[
            [gcd_conversation.IngestContextReferencesRequest],
            Awaitable[gcd_conversation.IngestContextReferencesResponse]]:
        r"""Return a callable for the ingest context references method over gRPC.

        Data ingestion API.
        Ingests context references for an existing conversation.

        Returns:
            Callable[[~.IngestContextReferencesRequest],
                    Awaitable[~.IngestContextReferencesResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'ingest_context_references' not in self._stubs:
            self._stubs['ingest_context_references'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/IngestContextReferences',
                request_serializer=gcd_conversation.IngestContextReferencesRequest.serialize,
                response_deserializer=gcd_conversation.IngestContextReferencesResponse.deserialize,
            )
        return self._stubs['ingest_context_references']

    @property
    def create_call_matcher(self) -> Callable[
            [conversation.CreateCallMatcherRequest],
            Awaitable[conversation.CallMatcher]]:
        r"""Return a callable for the create call matcher method over gRPC.

        Creates a call matcher that links incoming SIP calls
        to the specified conversation if they fulfill specified
        criteria.

        Returns:
            Callable[[~.CreateCallMatcherRequest],
                    Awaitable[~.CallMatcher]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'create_call_matcher' not in self._stubs:
            self._stubs['create_call_matcher'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/CreateCallMatcher',
                request_serializer=conversation.CreateCallMatcherRequest.serialize,
                response_deserializer=conversation.CallMatcher.deserialize,
            )
        return self._stubs['create_call_matcher']

    @property
    def list_call_matchers(self) -> Callable[
            [conversation.ListCallMatchersRequest],
            Awaitable[conversation.ListCallMatchersResponse]]:
        r"""Return a callable for the list call matchers method over gRPC.

        Returns the list of all call matchers in the
        specified conversation.

        Returns:
            Callable[[~.ListCallMatchersRequest],
                    Awaitable[~.ListCallMatchersResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_call_matchers' not in self._stubs:
            self._stubs['list_call_matchers'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListCallMatchers',
                request_serializer=conversation.ListCallMatchersRequest.serialize,
                response_deserializer=conversation.ListCallMatchersResponse.deserialize,
            )
        return self._stubs['list_call_matchers']

    @property
    def delete_call_matcher(self) -> Callable[
            [conversation.DeleteCallMatcherRequest],
            Awaitable[empty_pb2.Empty]]:
        r"""Return a callable for the delete call matcher method over gRPC.

        Requests deletion of a call matcher.

        Returns:
            Callable[[~.DeleteCallMatcherRequest],
                    Awaitable[~.Empty]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'delete_call_matcher' not in self._stubs:
            self._stubs['delete_call_matcher'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/DeleteCallMatcher',
                request_serializer=conversation.DeleteCallMatcherRequest.serialize,
                response_deserializer=empty_pb2.Empty.FromString,
            )
        return self._stubs['delete_call_matcher']

    @property
    def batch_create_messages(self) -> Callable[
            [conversation.BatchCreateMessagesRequest],
            Awaitable[conversation.BatchCreateMessagesResponse]]:
        r"""Return a callable for the batch create messages method over gRPC.

        Batch ingests messages to conversation. Customers can
        use this RPC to ingest historical messages to
        conversation.

        Returns:
            Callable[[~.BatchCreateMessagesRequest],
                    Awaitable[~.BatchCreateMessagesResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'batch_create_messages' not in self._stubs:
            self._stubs['batch_create_messages'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/BatchCreateMessages',
                request_serializer=conversation.BatchCreateMessagesRequest.serialize,
                response_deserializer=conversation.BatchCreateMessagesResponse.deserialize,
            )
        return self._stubs['batch_create_messages']

    @property
    def list_messages(self) -> Callable[
            [conversation.ListMessagesRequest],
            Awaitable[conversation.ListMessagesResponse]]:
        r"""Return a callable for the list messages method over gRPC.

        Lists messages that belong to a given conversation. ``messages``
        are ordered by ``create_time`` in descending order. To fetch
        updates without duplication, send request with filter
        ``create_time_epoch_microseconds > [first item's create_time of previous request]``
        and empty page_token.

        Returns:
            Callable[[~.ListMessagesRequest],
                    Awaitable[~.ListMessagesResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_messages' not in self._stubs:
            self._stubs['list_messages'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListMessages',
                request_serializer=conversation.ListMessagesRequest.serialize,
                response_deserializer=conversation.ListMessagesResponse.deserialize,
            )
        return self._stubs['list_messages']

    @property
    def export_messages(self) -> Callable[
            [conversation.ExportMessagesRequest],
            Awaitable[operations_pb2.Operation]]:
        r"""Return a callable for the export messages method over gRPC.

        Exports messages from a range of conversations to a
        Google Cloud Storage bucket. Each conversation is
        exported as a separate JSON transcript to the bucket.
        Only closed conversations are exported, and if redaction
        is configured, the exported text messages are redacted
        as well. Note: this method is pre-alpha and is subject
        to incompatible changes.

        Returns:
            Callable[[~.ExportMessagesRequest],
                    Awaitable[~.Operation]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'export_messages' not in self._stubs:
            self._stubs['export_messages'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ExportMessages',
                request_serializer=conversation.ExportMessagesRequest.serialize,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs['export_messages']

    @property
    def suggest_conversation_summary(self) -> Callable[
            [gcd_conversation.SuggestConversationSummaryRequest],
            Awaitable[gcd_conversation.SuggestConversationSummaryResponse]]:
        r"""Return a callable for the suggest conversation summary method over gRPC.

        Suggest summary for a conversation based on specific
        historical messages. The range of the messages to be
        used for summary can be specified in the request.

        Returns:
            Callable[[~.SuggestConversationSummaryRequest],
                    Awaitable[~.SuggestConversationSummaryResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_conversation_summary' not in self._stubs:
            self._stubs['suggest_conversation_summary'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/SuggestConversationSummary',
                request_serializer=gcd_conversation.SuggestConversationSummaryRequest.serialize,
                response_deserializer=gcd_conversation.SuggestConversationSummaryResponse.deserialize,
            )
        return self._stubs['suggest_conversation_summary']

    @property
    def generate_stateless_summary(self) -> Callable[
            [conversation.GenerateStatelessSummaryRequest],
            Awaitable[conversation.GenerateStatelessSummaryResponse]]:
        r"""Return a callable for the generate stateless summary method over gRPC.

        Generates and returns a summary for a conversation
        that does not have a resource created for it.

        Returns:
            Callable[[~.GenerateStatelessSummaryRequest],
                    Awaitable[~.GenerateStatelessSummaryResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'generate_stateless_summary' not in self._stubs:
            self._stubs['generate_stateless_summary'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GenerateStatelessSummary',
                request_serializer=conversation.GenerateStatelessSummaryRequest.serialize,
                response_deserializer=conversation.GenerateStatelessSummaryResponse.deserialize,
            )
        return self._stubs['generate_stateless_summary']

    @property
    def generate_stateless_suggestion(self) -> Callable[
            [conversation.GenerateStatelessSuggestionRequest],
            Awaitable[conversation.GenerateStatelessSuggestionResponse]]:
        r"""Return a callable for the generate stateless suggestion method over gRPC.

        Generates and returns a suggestion for a conversation
        that does not have a resource created for it.

        Returns:
            Callable[[~.GenerateStatelessSuggestionRequest],
                    Awaitable[~.GenerateStatelessSuggestionResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'generate_stateless_suggestion' not in self._stubs:
            self._stubs['generate_stateless_suggestion'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GenerateStatelessSuggestion',
                request_serializer=conversation.GenerateStatelessSuggestionRequest.serialize,
                response_deserializer=conversation.GenerateStatelessSuggestionResponse.deserialize,
            )
        return self._stubs['generate_stateless_suggestion']

    @property
    def suggest_conversation_key_moments(self) -> Callable[
            [gcd_conversation.SuggestConversationKeyMomentsRequest],
            Awaitable[gcd_conversation.SuggestConversationKeyMomentsResponse]]:
        r"""Return a callable for the suggest conversation key
        moments method over gRPC.

        Suggest key moments for a conversation based on
        specific historical messages.

        Returns:
            Callable[[~.SuggestConversationKeyMomentsRequest],
                    Awaitable[~.SuggestConversationKeyMomentsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'suggest_conversation_key_moments' not in self._stubs:
            self._stubs['suggest_conversation_key_moments'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/SuggestConversationKeyMoments',
                request_serializer=gcd_conversation.SuggestConversationKeyMomentsRequest.serialize,
                response_deserializer=gcd_conversation.SuggestConversationKeyMomentsResponse.deserialize,
            )
        return self._stubs['suggest_conversation_key_moments']

    @property
    def search_articles(self) -> Callable[
            [gcd_conversation.SearchArticlesRequest],
            Awaitable[gcd_conversation.SearchArticlesResponse]]:
        r"""Return a callable for the search articles method over gRPC.

        Gets relevant articles by performing a search using
        the given query.

        Returns:
            Callable[[~.SearchArticlesRequest],
                    Awaitable[~.SearchArticlesResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'search_articles' not in self._stubs:
            self._stubs['search_articles'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/SearchArticles',
                request_serializer=gcd_conversation.SearchArticlesRequest.serialize,
                response_deserializer=gcd_conversation.SearchArticlesResponse.deserialize,
            )
        return self._stubs['search_articles']

    @property
    def list_past_call_companion_events(self) -> Callable[
            [gcd_conversation.ListPastCallCompanionEventsRequest],
            Awaitable[gcd_conversation.ListPastCallCompanionEventsResponse]]:
        r"""Return a callable for the list past call companion
        events method over gRPC.

        For the Call Companion UI, gets all Call Companion
        conversation events that have occurred so far.

        Returns:
            Callable[[~.ListPastCallCompanionEventsRequest],
                    Awaitable[~.ListPastCallCompanionEventsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_past_call_companion_events' not in self._stubs:
            self._stubs['list_past_call_companion_events'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListPastCallCompanionEvents',
                request_serializer=gcd_conversation.ListPastCallCompanionEventsRequest.serialize,
                response_deserializer=gcd_conversation.ListPastCallCompanionEventsResponse.deserialize,
            )
        return self._stubs['list_past_call_companion_events']

    @property
    def streaming_list_upcoming_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest],
            Awaitable[gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse]]:
        r"""Return a callable for the streaming list upcoming call
        companion events method over gRPC.

        For the Call Companion UI, gets the incoming
        conversation events as a server-side stream.

        Returns:
            Callable[[~.StreamingListUpcomingCallCompanionEventsRequest],
                    Awaitable[~.StreamingListUpcomingCallCompanionEventsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'streaming_list_upcoming_call_companion_events' not in self._stubs:
            self._stubs['streaming_list_upcoming_call_companion_events'] = self._logged_channel.unary_stream(
                '/google.cloud.dialogflow.v2beta1.Conversations/StreamingListUpcomingCallCompanionEvents',
                request_serializer=gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest.serialize,
                response_deserializer=gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse.deserialize,
            )
        return self._stubs['streaming_list_upcoming_call_companion_events']

    @property
    def inject_call_companion_user_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionUserInputRequest],
            Awaitable[gcd_conversation.InjectCallCompanionUserInputResponse]]:
        r"""Return a callable for the inject call companion user
        input method over gRPC.

        For the Call Companion UI, injects a conversation
        event which is a user input into the conversation.

        Returns:
            Callable[[~.InjectCallCompanionUserInputRequest],
                    Awaitable[~.InjectCallCompanionUserInputResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'inject_call_companion_user_input' not in self._stubs:
            self._stubs['inject_call_companion_user_input'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/InjectCallCompanionUserInput',
                request_serializer=gcd_conversation.InjectCallCompanionUserInputRequest.serialize,
                response_deserializer=gcd_conversation.InjectCallCompanionUserInputResponse.deserialize,
            )
        return self._stubs['inject_call_companion_user_input']

    @property
    def streaming_list_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListCallCompanionEventsRequest],
            Awaitable[gcd_conversation.StreamingListCallCompanionEventsResponse]]:
        r"""Return a callable for the streaming list call companion
        events method over gRPC.

        For the anonymous Call Companion UI to get
        conversation events as a stream.

        Returns:
            Callable[[~.StreamingListCallCompanionEventsRequest],
                    Awaitable[~.StreamingListCallCompanionEventsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'streaming_list_call_companion_events' not in self._stubs:
            self._stubs['streaming_list_call_companion_events'] = self._logged_channel.unary_stream(
                '/google.cloud.dialogflow.v2beta1.Conversations/StreamingListCallCompanionEvents',
                request_serializer=gcd_conversation.StreamingListCallCompanionEventsRequest.serialize,
                response_deserializer=gcd_conversation.StreamingListCallCompanionEventsResponse.deserialize,
            )
        return self._stubs['streaming_list_call_companion_events']

    @property
    def inject_call_companion_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionInputRequest],
            Awaitable[gcd_conversation.InjectCallCompanionInputResponse]]:
        r"""Return a callable for the inject call companion input method over gRPC.

        For the anonymous Call Companion UI, injects a
        conversation event which is a user input into the
        conversation.

        Returns:
            Callable[[~.InjectCallCompanionInputRequest],
                    Awaitable[~.InjectCallCompanionInputResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'inject_call_companion_input' not in self._stubs:
            self._stubs['inject_call_companion_input'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/InjectCallCompanionInput',
                request_serializer=gcd_conversation.InjectCallCompanionInputRequest.serialize,
                response_deserializer=gcd_conversation.InjectCallCompanionInputResponse.deserialize,
            )
        return self._stubs['inject_call_companion_input']

    @property
    def initialize_call_companion(self) -> Callable[
            [gcd_conversation.InitializeCallCompanionRequest],
            Awaitable[empty_pb2.Empty]]:
        r"""Return a callable for the initialize call companion method over gRPC.

        Initialize the resources for Call Companion UI.

        Returns:
            Callable[[~.InitializeCallCompanionRequest],
                    Awaitable[~.Empty]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'initialize_call_companion' not in self._stubs:
            self._stubs['initialize_call_companion'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/InitializeCallCompanion',
                request_serializer=gcd_conversation.InitializeCallCompanionRequest.serialize,
                response_deserializer=empty_pb2.Empty.FromString,
            )
        return self._stubs['initialize_call_companion']

    @property
    def get_call_companion_settings(self) -> Callable[
            [gcd_conversation.GetCallCompanionSettingsRequest],
            Awaitable[gcd_conversation.CallCompanionSettings]]:
        r"""Return a callable for the get call companion settings method over gRPC.

        Gets the settings for Call Companion UI.

        Returns:
            Callable[[~.GetCallCompanionSettingsRequest],
                    Awaitable[~.CallCompanionSettings]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_call_companion_settings' not in self._stubs:
            self._stubs['get_call_companion_settings'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GetCallCompanionSettings',
                request_serializer=gcd_conversation.GetCallCompanionSettingsRequest.serialize,
                response_deserializer=gcd_conversation.CallCompanionSettings.deserialize,
            )
        return self._stubs['get_call_companion_settings']

    @property
    def search_knowledge(self) -> Callable[
            [conversation.SearchKnowledgeRequest],
            Awaitable[conversation.SearchKnowledgeResponse]]:
        r"""Return a callable for the search knowledge method over gRPC.

        Get answers for the given query based on knowledge
        documents.

        Returns:
            Callable[[~.SearchKnowledgeRequest],
                    Awaitable[~.SearchKnowledgeResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'search_knowledge' not in self._stubs:
            self._stubs['search_knowledge'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/SearchKnowledge',
                request_serializer=conversation.SearchKnowledgeRequest.serialize,
                response_deserializer=conversation.SearchKnowledgeResponse.deserialize,
            )
        return self._stubs['search_knowledge']

    @property
    def generate_suggestions(self) -> Callable[
            [gcd_conversation.GenerateSuggestionsRequest],
            Awaitable[participant.GenerateSuggestionsResponse]]:
        r"""Return a callable for the generate suggestions method over gRPC.

        Generates all the suggestions using generators
        configured in the conversation profile. A generator is
        used only if its trigger event is matched.

        Returns:
            Callable[[~.GenerateSuggestionsRequest],
                    Awaitable[~.GenerateSuggestionsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'generate_suggestions' not in self._stubs:
            self._stubs['generate_suggestions'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GenerateSuggestions',
                request_serializer=gcd_conversation.GenerateSuggestionsRequest.serialize,
                response_deserializer=participant.GenerateSuggestionsResponse.deserialize,
            )
        return self._stubs['generate_suggestions']

    @property
    def initiate_phone_call(self) -> Callable[
            [gcd_conversation.InitiatePhoneCallRequest],
            Awaitable[gcd_conversation.InitiatePhoneCallResponse]]:
        r"""Return a callable for the initiate phone call method over gRPC.

        Initiates an outbound phone call with this
        conversation.

        Returns:
            Callable[[~.InitiatePhoneCallRequest],
                    Awaitable[~.InitiatePhoneCallResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'initiate_phone_call' not in self._stubs:
            self._stubs['initiate_phone_call'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/InitiatePhoneCall',
                request_serializer=gcd_conversation.InitiatePhoneCallRequest.serialize,
                response_deserializer=gcd_conversation.InitiatePhoneCallResponse.deserialize,
            )
        return self._stubs['initiate_phone_call']

    @property
    def inject_supervisor_input(self) -> Callable[
            [gcd_conversation.InjectSupervisorInputRequest],
            Awaitable[gcd_conversation.InjectSupervisorInputResponse]]:
        r"""Return a callable for the inject supervisor input method over gRPC.

        Injects input from a human supervisor into the
        conversation.

        Returns:
            Callable[[~.InjectSupervisorInputRequest],
                    Awaitable[~.InjectSupervisorInputResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'inject_supervisor_input' not in self._stubs:
            self._stubs['inject_supervisor_input'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/InjectSupervisorInput',
                request_serializer=gcd_conversation.InjectSupervisorInputRequest.serialize,
                response_deserializer=gcd_conversation.InjectSupervisorInputResponse.deserialize,
            )
        return self._stubs['inject_supervisor_input']

    @property
    def get_interaction_monitoring_alert(self) -> Callable[
            [conversation.GetInteractionMonitoringAlertRequest],
            Awaitable[interaction_monitoring.InteractionMonitoringAlert]]:
        r"""Return a callable for the get interaction monitoring
        alert method over gRPC.

        Retrieves a interaction monitoring alert.

        Returns:
            Callable[[~.GetInteractionMonitoringAlertRequest],
                    Awaitable[~.InteractionMonitoringAlert]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'get_interaction_monitoring_alert' not in self._stubs:
            self._stubs['get_interaction_monitoring_alert'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/GetInteractionMonitoringAlert',
                request_serializer=conversation.GetInteractionMonitoringAlertRequest.serialize,
                response_deserializer=interaction_monitoring.InteractionMonitoringAlert.deserialize,
            )
        return self._stubs['get_interaction_monitoring_alert']

    @property
    def list_interaction_monitoring_alerts(self) -> Callable[
            [conversation.ListInteractionMonitoringAlertsRequest],
            Awaitable[conversation.ListInteractionMonitoringAlertsResponse]]:
        r"""Return a callable for the list interaction monitoring
        alerts method over gRPC.

        Returns the list of all interaction monitoring alerts
        in the specified project.

        Returns:
            Callable[[~.ListInteractionMonitoringAlertsRequest],
                    Awaitable[~.ListInteractionMonitoringAlertsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_interaction_monitoring_alerts' not in self._stubs:
            self._stubs['list_interaction_monitoring_alerts'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListInteractionMonitoringAlerts',
                request_serializer=conversation.ListInteractionMonitoringAlertsRequest.serialize,
                response_deserializer=conversation.ListInteractionMonitoringAlertsResponse.deserialize,
            )
        return self._stubs['list_interaction_monitoring_alerts']

    @property
    def ack_interaction_monitoring_alert(self) -> Callable[
            [conversation.AckInteractionMonitoringAlertRequest],
            Awaitable[interaction_monitoring.InteractionMonitoringAlert]]:
        r"""Return a callable for the ack interaction monitoring
        alert method over gRPC.

        Acks the specified interaction monitoring alert by marking it's
        state as ``ACKNOWLEDGED``.

        Returns:
            Callable[[~.AckInteractionMonitoringAlertRequest],
                    Awaitable[~.InteractionMonitoringAlert]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'ack_interaction_monitoring_alert' not in self._stubs:
            self._stubs['ack_interaction_monitoring_alert'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/AckInteractionMonitoringAlert',
                request_serializer=conversation.AckInteractionMonitoringAlertRequest.serialize,
                response_deserializer=interaction_monitoring.InteractionMonitoringAlert.deserialize,
            )
        return self._stubs['ack_interaction_monitoring_alert']

    @property
    def list_interaction_monitoring_metrics(self) -> Callable[
            [conversation.ListInteractionMonitoringMetricsRequest],
            Awaitable[conversation.ListInteractionMonitoringMetricsResponse]]:
        r"""Return a callable for the list interaction monitoring
        metrics method over gRPC.

        Returns all interaction monitoring metrics in the
        specified conversation or session context.

        Returns:
            Callable[[~.ListInteractionMonitoringMetricsRequest],
                    Awaitable[~.ListInteractionMonitoringMetricsResponse]]:
                A function that, when called, will call the underlying RPC
                on the server.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if 'list_interaction_monitoring_metrics' not in self._stubs:
            self._stubs['list_interaction_monitoring_metrics'] = self._logged_channel.unary_unary(
                '/google.cloud.dialogflow.v2beta1.Conversations/ListInteractionMonitoringMetrics',
                request_serializer=conversation.ListInteractionMonitoringMetricsRequest.serialize,
                response_deserializer=conversation.ListInteractionMonitoringMetricsResponse.deserialize,
            )
        return self._stubs['list_interaction_monitoring_metrics']

    def _prep_wrapped_messages(self, client_info):
        """ Precompute the wrapped methods, overriding the base class method to use async wrappers."""
        self._wrapped_methods = {
            self.create_conversation: self._wrap_method(
                self.create_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_conversations: self._wrap_method(
                self.list_conversations,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_conversation: self._wrap_method(
                self.get_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.add_conversation_phone_number: self._wrap_method(
                self.add_conversation_phone_number,
                default_timeout=None,
                client_info=client_info,
            ),
            self.activate_conversation: self._wrap_method(
                self.activate_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.deactivate_conversation: self._wrap_method(
                self.deactivate_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.complete_conversation: self._wrap_method(
                self.complete_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.update_conversation: self._wrap_method(
                self.update_conversation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.ingest_context_references: self._wrap_method(
                self.ingest_context_references,
                default_timeout=None,
                client_info=client_info,
            ),
            self.create_call_matcher: self._wrap_method(
                self.create_call_matcher,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_call_matchers: self._wrap_method(
                self.list_call_matchers,
                default_timeout=None,
                client_info=client_info,
            ),
            self.delete_call_matcher: self._wrap_method(
                self.delete_call_matcher,
                default_timeout=None,
                client_info=client_info,
            ),
            self.batch_create_messages: self._wrap_method(
                self.batch_create_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_messages: self._wrap_method(
                self.list_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.export_messages: self._wrap_method(
                self.export_messages,
                default_timeout=None,
                client_info=client_info,
            ),
            self.suggest_conversation_summary: self._wrap_method(
                self.suggest_conversation_summary,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_stateless_summary: self._wrap_method(
                self.generate_stateless_summary,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_stateless_suggestion: self._wrap_method(
                self.generate_stateless_suggestion,
                default_timeout=None,
                client_info=client_info,
            ),
            self.suggest_conversation_key_moments: self._wrap_method(
                self.suggest_conversation_key_moments,
                default_timeout=None,
                client_info=client_info,
            ),
            self.search_articles: self._wrap_method(
                self.search_articles,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_past_call_companion_events: self._wrap_method(
                self.list_past_call_companion_events,
                default_timeout=None,
                client_info=client_info,
            ),
            self.streaming_list_upcoming_call_companion_events: self._wrap_method(
                self.streaming_list_upcoming_call_companion_events,
                default_timeout=600.0,
                client_info=client_info,
            ),
            self.inject_call_companion_user_input: self._wrap_method(
                self.inject_call_companion_user_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.streaming_list_call_companion_events: self._wrap_method(
                self.streaming_list_call_companion_events,
                default_timeout=600.0,
                client_info=client_info,
            ),
            self.inject_call_companion_input: self._wrap_method(
                self.inject_call_companion_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.initialize_call_companion: self._wrap_method(
                self.initialize_call_companion,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_call_companion_settings: self._wrap_method(
                self.get_call_companion_settings,
                default_timeout=None,
                client_info=client_info,
            ),
            self.search_knowledge: self._wrap_method(
                self.search_knowledge,
                default_timeout=None,
                client_info=client_info,
            ),
            self.generate_suggestions: self._wrap_method(
                self.generate_suggestions,
                default_timeout=None,
                client_info=client_info,
            ),
            self.initiate_phone_call: self._wrap_method(
                self.initiate_phone_call,
                default_timeout=None,
                client_info=client_info,
            ),
            self.inject_supervisor_input: self._wrap_method(
                self.inject_supervisor_input,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_interaction_monitoring_alert: self._wrap_method(
                self.get_interaction_monitoring_alert,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_interaction_monitoring_alerts: self._wrap_method(
                self.list_interaction_monitoring_alerts,
                default_timeout=None,
                client_info=client_info,
            ),
            self.ack_interaction_monitoring_alert: self._wrap_method(
                self.ack_interaction_monitoring_alert,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_interaction_monitoring_metrics: self._wrap_method(
                self.list_interaction_monitoring_metrics,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_location: self._wrap_method(
                self.get_location,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_locations: self._wrap_method(
                self.list_locations,
                default_timeout=None,
                client_info=client_info,
            ),
            self.cancel_operation: self._wrap_method(
                self.cancel_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.get_operation: self._wrap_method(
                self.get_operation,
                default_timeout=None,
                client_info=client_info,
            ),
            self.list_operations: self._wrap_method(
                self.list_operations,
                default_timeout=None,
                client_info=client_info,
            ),
        }

    def _wrap_method(self, func, *args, **kwargs):
        if self._wrap_with_kind:  # pragma: NO COVER
            kwargs["kind"] = self.kind
        return gapic_v1.method_async.wrap_method(func, *args, **kwargs)

    def close(self):
        return self._logged_channel.close()

    @property
    def kind(self) -> str:
        return "grpc_asyncio"

    @property
    def cancel_operation(
        self,
    ) -> Callable[[operations_pb2.CancelOperationRequest], None]:
        r"""Return a callable for the cancel_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "cancel_operation" not in self._stubs:
            self._stubs["cancel_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/CancelOperation",
                request_serializer=operations_pb2.CancelOperationRequest.SerializeToString,
                response_deserializer=None,
            )
        return self._stubs["cancel_operation"]

    @property
    def get_operation(
        self,
    ) -> Callable[[operations_pb2.GetOperationRequest], operations_pb2.Operation]:
        r"""Return a callable for the get_operation method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_operation" not in self._stubs:
            self._stubs["get_operation"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/GetOperation",
                request_serializer=operations_pb2.GetOperationRequest.SerializeToString,
                response_deserializer=operations_pb2.Operation.FromString,
            )
        return self._stubs["get_operation"]

    @property
    def list_operations(
        self,
    ) -> Callable[[operations_pb2.ListOperationsRequest], operations_pb2.ListOperationsResponse]:
        r"""Return a callable for the list_operations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_operations" not in self._stubs:
            self._stubs["list_operations"] = self._logged_channel.unary_unary(
                "/google.longrunning.Operations/ListOperations",
                request_serializer=operations_pb2.ListOperationsRequest.SerializeToString,
                response_deserializer=operations_pb2.ListOperationsResponse.FromString,
            )
        return self._stubs["list_operations"]

    @property
    def list_locations(
        self,
    ) -> Callable[[locations_pb2.ListLocationsRequest], locations_pb2.ListLocationsResponse]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "list_locations" not in self._stubs:
            self._stubs["list_locations"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/ListLocations",
                request_serializer=locations_pb2.ListLocationsRequest.SerializeToString,
                response_deserializer=locations_pb2.ListLocationsResponse.FromString,
            )
        return self._stubs["list_locations"]

    @property
    def get_location(
        self,
    ) -> Callable[[locations_pb2.GetLocationRequest], locations_pb2.Location]:
        r"""Return a callable for the list locations method over gRPC.
        """
        # Generate a "stub function" on-the-fly which will actually make
        # the request.
        # gRPC handles serialization and deserialization, so we just need
        # to pass in the functions for each.
        if "get_location" not in self._stubs:
            self._stubs["get_location"] = self._logged_channel.unary_unary(
                "/google.cloud.location.Locations/GetLocation",
                request_serializer=locations_pb2.GetLocationRequest.SerializeToString,
                response_deserializer=locations_pb2.Location.FromString,
            )
        return self._stubs["get_location"]


__all__ = (
    'ConversationsGrpcAsyncIOTransport',
)
