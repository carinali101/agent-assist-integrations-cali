# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.rpc import status_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'DocumentCollectionOperationMetadata',
    },
)


class DocumentCollectionOperationMetadata(proto.Message):
    r"""Metadata for [DocumentCollections][CreateDocumentCollection].

    Attributes:
        state (google.cloud.dialogflow_v2beta1.types.DocumentCollectionOperationMetadata.State):
            Required. The current state of this
            operation.
        status (MutableSequence[google.rpc.status_pb2.Status]):
            The failure statuses.
        knowledge_base (str):
            The name of the knowledge base interacted
            with during the operation.
        completion_percentage (int):
            The percentage of completeness of the
            operation
    """
    class State(proto.Enum):
        r"""State of the operation.

        Values:
            STATE_UNSPECIFIED (0):
                Unspecified state. Should never be used.
            PENDING (1):
                The operation has been created.
            RUNNING (2):
                The operation is currently running.
            DONE (3):
                The operation is done, either cancelled or
                completed.
        """
        STATE_UNSPECIFIED = 0
        PENDING = 1
        RUNNING = 2
        DONE = 3

    state: State = proto.Field(
        proto.ENUM,
        number=1,
        enum=State,
    )
    status: MutableSequence[status_pb2.Status] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=status_pb2.Status,
    )
    knowledge_base: str = proto.Field(
        proto.STRING,
        number=3,
    )
    completion_percentage: int = proto.Field(
        proto.INT64,
        number=4,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
