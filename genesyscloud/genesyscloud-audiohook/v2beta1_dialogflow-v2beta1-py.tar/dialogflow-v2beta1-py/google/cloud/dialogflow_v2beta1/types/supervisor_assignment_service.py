# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'Availability',
        'Supervisor',
        'CreateSupervisorRequest',
        'ListSupervisorsRequest',
        'ListSupervisorsResponse',
        'UpdateSupervisorStatusRequest',
        'SupervisorStatus',
        'AssignSupervisorRequest',
        'AssignSupervisorResponse',
        'ListConversationAssignmentsRequest',
        'ConversationAssignment',
        'ListConversationAssignmentsResponse',
        'DeleteSupervisorRequest',
    },
)


class Availability(proto.Enum):
    r"""Enum representing the availability of a supervisor.

    Values:
        AVAILABILITY_UNSPECIFIED (0):
            Availability is not specified.
        AVAILABLE (1):
            Supervisor is available.
        UNAVAILABLE (2):
            Supervisor is unavailable.
    """
    AVAILABILITY_UNSPECIFIED = 0
    AVAILABLE = 1
    UNAVAILABLE = 2


class Supervisor(proto.Message):
    r"""Represents a supervisor.

    Attributes:
        name (str):
            Output only. Identifier. The unique identifier of this
            supervisor. Format:
            ``projects/<Project ID>/locations/<Location ID>/supervisors/<Supervisor ID>``.
        username (str):
            Optional. The optional identifying username
            of the supervisor.
        supervisor_status (google.cloud.dialogflow_v2beta1.types.SupervisorStatus):
            Optional. The status of the supervisor.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    username: str = proto.Field(
        proto.STRING,
        number=2,
    )
    supervisor_status: 'SupervisorStatus' = proto.Field(
        proto.MESSAGE,
        number=3,
        message='SupervisorStatus',
    )


class CreateSupervisorRequest(proto.Message):
    r"""Request message for CreateSupervisor.

    Attributes:
        parent (str):
            Required. Resource identifier of the project creating the
            supervisor. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        supervisor (google.cloud.dialogflow_v2beta1.types.Supervisor):
            Optional. The supervisor to create.
            If not provided, a default supervisor will be
            created.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    supervisor: 'Supervisor' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='Supervisor',
    )


class ListSupervisorsRequest(proto.Message):
    r"""Request message for ListSupervisors.

    Attributes:
        parent (str):
            Required. Resource identifier of the project to list
            supervisors for. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        page_size (int):
            Optional. The maximum number of results to
            return per page.
        page_token (str):
            Optional. The page token, received from a
            previous call.
        filter (str):
            Optional. Filter to apply to the list of supervisors. The
            filter syntax is defined in https://google.aip.dev/160. The
            only currently supported filter is ``username=...``.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListSupervisorsResponse(proto.Message):
    r"""Response message for ListSupervisors.

    Attributes:
        supervisors (MutableSequence[google.cloud.dialogflow_v2beta1.types.Supervisor]):
            The list of supervisors.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    supervisors: MutableSequence['Supervisor'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='Supervisor',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class UpdateSupervisorStatusRequest(proto.Message):
    r"""Request message for UpdateSupervisorStatus.

    Attributes:
        name (str):
            Required. The unique resource identifier of the supervisor
            whose status is to be updated. Format:
            ``projects/<Project ID>/locations/<Location ID>/supervisors/<Supervisor ID>``.
        supervisor_status (google.cloud.dialogflow_v2beta1.types.SupervisorStatus):
            Required. The supervisor status to update.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    supervisor_status: 'SupervisorStatus' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='SupervisorStatus',
    )


class SupervisorStatus(proto.Message):
    r"""Represents the status of a supervisor.

    Attributes:
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The last time the supervisor's
            status was updated.
        availability (google.cloud.dialogflow_v2beta1.types.Availability):
            Required. The supervisor's availability for
            routing.
    """

    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=1,
        message=timestamp_pb2.Timestamp,
    )
    availability: 'Availability' = proto.Field(
        proto.ENUM,
        number=2,
        enum='Availability',
    )


class AssignSupervisorRequest(proto.Message):
    r"""Request message for AssignSupervisor.

    Attributes:
        conversation (str):
            Required. The conversation to assign a supervisor to.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class AssignSupervisorResponse(proto.Message):
    r"""Response message for AssignSupervisor.

    Attributes:
        supervisor (google.cloud.dialogflow_v2beta1.types.Supervisor):
            The supervisor assigned to the conversation.
    """

    supervisor: 'Supervisor' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='Supervisor',
    )


class ListConversationAssignmentsRequest(proto.Message):
    r"""Request message for ListConversationAssignments.

    Attributes:
        parent (str):
            Required. The supervisor to list conversation assignments
            for. Format:
            ``projects/<Project ID>/locations/<Location ID>/supervisors/<Supervisor ID>``.
        page_size (int):
            Optional. The maximum number of results to
            return per page.
        page_token (str):
            Optional. The page token, received from a
            previous call.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ConversationAssignment(proto.Message):
    r"""Represents a conversation assignment.

    Attributes:
        conversation (str):
            The conversation assigned to the supervisor. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationAssignmentsResponse(proto.Message):
    r"""Response message for ListConversationAssignments.

    Attributes:
        conversation_assignments (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationAssignment]):
            The list of conversation assignments for the
            supervisor.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversation_assignments: MutableSequence['ConversationAssignment'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationAssignment',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteSupervisorRequest(proto.Message):
    r"""Request message for DeleteSupervisor.

    Attributes:
        name (str):
            Required. The unique resource identifier of the supervisor
            to delete. Format:
            ``projects/<Project ID>/locations/<Location ID>/supervisors/<Supervisor ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
