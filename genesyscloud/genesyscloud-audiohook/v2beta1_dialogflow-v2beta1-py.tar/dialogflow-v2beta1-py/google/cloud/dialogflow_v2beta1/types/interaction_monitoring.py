# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import generator
from google.cloud.dialogflow_v2beta1.types import session
from google.cloud.dialogflow_v2beta1.types import toolset
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'RawMetricValue',
        'MetricValues',
        'AlertMetadata',
        'InteractionMonitoringAlert',
    },
)


class RawMetricValue(proto.Message):
    r"""Raw metric value from computations done by the real time
    monitoring.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        sentiment (google.cloud.dialogflow_v2beta1.types.Sentiment):
            Optional. Sentiment value computed by the real time
            monitoring. ``sentiment.score`` field is used to define the
            corresponding alerting rules, and ``sentiment.magnitude``
            field is used for converting the ``score`` to a fine-grained
            sentiment label (e.g. "mixed_balanced", "neutral").

            This field is a member of `oneof`_ ``value``.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Create time of the metric value.
        advanced_values (google.cloud.dialogflow_v2beta1.types.RawMetricValue.AdvancedMetricValueCalculations):
            Optional. Advanced metric calculations for
            the current utterance done on top of the current
            and past metric values. Only set if advanced
            heuritics such as moving average are configured
            within the internal alerting config.
    """

    class AdvancedMetricValueCalculations(proto.Message):
        r"""Advanced metrics calculated on top of the raw metric value.

        Attributes:
            moving_average_value (float):
                Optional. Output only. Moving average value
                of the metric for the current utterance. Only
                supported for numeric values (such as sentiment
                score) and if moving average calculation is
                configured in the internal alerting config.
            exponential_moving_average_value (float):
                Optional. Output only. Exponential moving
                average value of the metric for the current
                utterance. Only supported for numeric values
                (such as sentiment score) and if exponential
                moving average calculation is configured in the
                internal alerting config.
        """

        moving_average_value: float = proto.Field(
            proto.DOUBLE,
            number=1,
        )
        exponential_moving_average_value: float = proto.Field(
            proto.DOUBLE,
            number=2,
        )

    sentiment: session.Sentiment = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='value',
        message=session.Sentiment,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=1,
        message=timestamp_pb2.Timestamp,
    )
    advanced_values: AdvancedMetricValueCalculations = proto.Field(
        proto.MESSAGE,
        number=3,
        message=AdvancedMetricValueCalculations,
    )


class MetricValues(proto.Message):
    r"""Stores all values for a given metric type computed by the
    real time monitoring.

    Attributes:
        metric_type (google.cloud.dialogflow_v2beta1.types.MetricValues.MetricType):
            Required. Type of the metric.
        values (MutableSequence[google.cloud.dialogflow_v2beta1.types.RawMetricValue]):
            Optional. List of computed values for the given metric type.
            NOTE: The values must be ordered by descending order of the
            ``create_time``.
    """
    class MetricType(proto.Enum):
        r"""Types of metrics available within the real time monitoring.

        Values:
            METRIC_TYPE_UNSPECIFIED (0):
                Invalid metric type.
            SENTIMENT_SCORE (1):
                Sentiment score for ongoing conversation/session.
                ``sentiment`` value will be populated in the
                ``RawMetricValue`` for this metric type. Metric type is
                defined as ``SENTIMENT_SCORE`` instead of ``SENTIMENT`` as
                alerting trigger conditions are only supported on
                ``sentiment.score`` value.
        """
        METRIC_TYPE_UNSPECIFIED = 0
        SENTIMENT_SCORE = 1

    metric_type: MetricType = proto.Field(
        proto.ENUM,
        number=1,
        enum=MetricType,
    )
    values: MutableSequence['RawMetricValue'] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='RawMetricValue',
    )


class AlertMetadata(proto.Message):
    r"""Metadata for the alert generated by the real time monitoring.
    This contains additional information about the alert such as the
    summary of the conversation, the rules that triggered the alert
    along with their computed metric values etc.

    Attributes:
        summary (google.cloud.dialogflow_v2beta1.types.SummarySuggestion):
            Optional. Summary of the ongoing
            conversation/session.
        alert_trigger_rules (MutableSequence[google.cloud.dialogflow_v2beta1.types.AlertMetadata.EvaluatedAlertRule]):
            Optional. List of rules that triggerd the
            given alert along with their computed metric
            values. NOTE: Currently, only one alert rule can
            be present in the list, until we support
            batching.
        tool_metadata (MutableSequence[google.cloud.dialogflow_v2beta1.types.AlertMetadata.ToolMetadata]):
            Optional. Output only. A list of metadata
            extracted from tools.
        virtual_agent_display_name (str):
            Optional. Output only. Display name of the
            active virtual agent.
        playbook_display_name (str):
            Optional. Output only. Display name of the
            active playbook.
        channel_type (google.cloud.dialogflow_v2beta1.types.AlertMetadata.ChannelType):
            Optional. Output only. The type of the
            interaction channel of the ongoing
            conversation/session.
        assigned_supervisor (str):
            Optional. Output only. The name of the supervisor assigned
            as a result of the alert. Format:
            ``projects/<Project ID>/locations/<Location ID>/supervisors/<Supervisor ID>``.
    """
    class ChannelType(proto.Enum):
        r"""The type of the interaction channel.

        Values:
            CHANNEL_TYPE_UNSPECIFIED (0):
                Unspecified channel type.
            CHAT (1):
                All streams are text.
            VOICE (2):
                At least one input stream is voice.
        """
        CHANNEL_TYPE_UNSPECIFIED = 0
        CHAT = 1
        VOICE = 2

    class EvaluatedAlertRule(proto.Message):
        r"""Evaluated alert rule with the corresponding computed metrics.

        Attributes:
            alert_rule_id (str):
                Required. Unique Identifier of the alert
                rule. This should be short, readable and unique
                name (within the project configuration) to
                briefly describe the alert rule.
            description (str):
                Optional. The detailed description of this
                alert rule that is visible to the customer.
            historical_metric_values (MutableSequence[google.cloud.dialogflow_v2beta1.types.MetricValues]):
                Optional. List of historical metric values
                computed or used as part of this alert rule to
                decide whether to trigger an alert or not. This
                may be one metric value per metric type, or all
                its historical values over a certain predefined
                window/duration (e.g. last 10 minutes, or
                ongoing session). Duration/Window is dependent
                on how the alert trigger condition is defined
                for the given metric in Alerting Config.
        """

        alert_rule_id: str = proto.Field(
            proto.STRING,
            number=1,
        )
        description: str = proto.Field(
            proto.STRING,
            number=2,
        )
        historical_metric_values: MutableSequence['MetricValues'] = proto.RepeatedField(
            proto.MESSAGE,
            number=3,
            message='MetricValues',
        )

    class ToolMetadata(proto.Message):
        r"""Represents metadata extracted from a tool.

        This message has `oneof`_ fields (mutually exclusive fields).
        For each oneof, at most one member field can be set at the same time.
        Setting any member of the oneof automatically clears all other
        members.

        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            tool (str):
                Optional. Extracted using a tool. Format:
                ``projects/{project}/locations/{location}/apps/{app}/tools/{tool}``

                This field is a member of `oneof`_ ``source``.
            toolset_tool (google.cloud.dialogflow_v2beta1.types.ToolsetTool):
                Optional. Extracted using a toolset tool.

                This field is a member of `oneof`_ ``source``.
            metadata_key_path (str):
                Optional. Extracted from Playbook Live
                session parameters.

                This field is a member of `oneof`_ ``source``.
            display_name (str):
                Optional. Display name.
            content (str):
                Optional. Content extracted from tool
                response.
        """

        tool: str = proto.Field(
            proto.STRING,
            number=1,
            oneof='source',
        )
        toolset_tool: toolset.ToolsetTool = proto.Field(
            proto.MESSAGE,
            number=5,
            oneof='source',
            message=toolset.ToolsetTool,
        )
        metadata_key_path: str = proto.Field(
            proto.STRING,
            number=4,
            oneof='source',
        )
        display_name: str = proto.Field(
            proto.STRING,
            number=2,
        )
        content: str = proto.Field(
            proto.STRING,
            number=3,
        )

    summary: generator.SummarySuggestion = proto.Field(
        proto.MESSAGE,
        number=1,
        message=generator.SummarySuggestion,
    )
    alert_trigger_rules: MutableSequence[EvaluatedAlertRule] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=EvaluatedAlertRule,
    )
    tool_metadata: MutableSequence[ToolMetadata] = proto.RepeatedField(
        proto.MESSAGE,
        number=3,
        message=ToolMetadata,
    )
    virtual_agent_display_name: str = proto.Field(
        proto.STRING,
        number=4,
    )
    playbook_display_name: str = proto.Field(
        proto.STRING,
        number=5,
    )
    channel_type: ChannelType = proto.Field(
        proto.ENUM,
        number=6,
        enum=ChannelType,
    )
    assigned_supervisor: str = proto.Field(
        proto.STRING,
        number=7,
    )


class InteractionMonitoringAlert(proto.Message):
    r"""Represents an alert generated by the real time monitoring.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            Identifier. The unique identifier of the alert. Format:
            ``projects/<Project ID>/locations/<Location ID>/interactionMonitoringAlerts/<Alert ID>``.
        conversation (str):
            Optional. The unique identifier of the conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.

            This field is a member of `oneof`_ ``context_id``.
        trigger_time (google.protobuf.timestamp_pb2.Timestamp):
            Optional. Timestamp of the last
            stream/message which triggered the alert.
        alert_state (google.cloud.dialogflow_v2beta1.types.InteractionMonitoringAlert.AlertState):
            Optional. Output only. Current State of the alert. Unless
            explicitly marked ``ACKNOWLEDGED`` via the AcknowledgeAlert
            API, the state remains to be ``CREATED`` by default.
        alert_metadata (google.cloud.dialogflow_v2beta1.types.AlertMetadata):
            Optional. Additional information useful for
            the alert, such as summary, values of all
            computed metrics, conditions/rules that
            triggered the alert etc.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Creation time of this alert.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Update time of this alert.
    """
    class AlertState(proto.Enum):
        r"""Defines the State of the alert.

        Values:
            ALERT_STATE_UNSPECIFIED (0):
                Invalid state.
            CREATED (1):
                The alert has been successfully created
                within our system.
            ACKNOWLEDGED (2):
                The alert state has been updated to
                acknowledged by the customer.
        """
        ALERT_STATE_UNSPECIFIED = 0
        CREATED = 1
        ACKNOWLEDGED = 2

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation: str = proto.Field(
        proto.STRING,
        number=2,
        oneof='context_id',
    )
    trigger_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    alert_state: AlertState = proto.Field(
        proto.ENUM,
        number=7,
        enum=AlertState,
    )
    alert_metadata: 'AlertMetadata' = proto.Field(
        proto.MESSAGE,
        number=8,
        message='AlertMetadata',
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=9,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=10,
        message=timestamp_pb2.Timestamp,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
