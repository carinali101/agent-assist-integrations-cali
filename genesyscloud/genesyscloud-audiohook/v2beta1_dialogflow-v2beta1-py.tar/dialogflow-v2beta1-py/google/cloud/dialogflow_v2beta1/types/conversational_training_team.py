# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateConversationalTrainingTeamRequest',
        'GetConversationalTrainingTeamRequest',
        'ListConversationalTrainingTeamsRequest',
        'ListConversationalTrainingTeamsResponse',
        'DeleteConversationalTrainingTeamRequest',
        'UpdateConversationalTrainingTeamRequest',
        'ConversationalTrainingTeam',
    },
)


class CreateConversationalTrainingTeamRequest(proto.Message):
    r"""Request message of CreateConversationalTrainingTeam.

    Attributes:
        parent (str):
            Required. The project/location to create conversational
            training team for. Format:
            ``projects/<ProjectID>/locations/<LocationID>``.
        conversational_training_team (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingTeam):
            Required. The conversational training team to
            create.
        conversational_training_team_id (str):
            Optional. The ID to use for the conversational training
            team, which will become the final component of the
            conversational training team's resource name.

            The conversational training team ID must be compliant with
            the regression fomula ``[a-zA-Z][a-zA-Z0-9_-]*`` with the
            characters length in range of [3,64]. If the field is not
            provide, an Id will be auto-generated. If the field is
            provided, the caller is responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversational_training_team: 'ConversationalTrainingTeam' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationalTrainingTeam',
    )
    conversational_training_team_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class GetConversationalTrainingTeamRequest(proto.Message):
    r"""Request message of GetConversationalTrainingTeam.

    Attributes:
        name (str):
            Required. The conversational training team resource name to
            retrieve. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationalTrainingTeamsRequest(proto.Message):
    r"""Request message of ListConversationalTrainingTeams.

    Attributes:
        parent (str):
            Required. The project/location to list
            conversationalTrainingTeams for. Format:
            ``projects/<ProjectID>/locations/<LocationID>``.
        page_size (int):
            Optional. Maximum number of conversational
            training teams to return in a single page.
            Default to 10.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
        filter (str):
            Optional. Filter on managers field. Currently only supports
            ``managers:<user_id_value>``.

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListConversationalTrainingTeamsResponse(proto.Message):
    r"""Response of ListConversationalTrainingTeams.

    Attributes:
        conversational_training_teams (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingTeam]):
            List of conversationalTrainingTeams
            retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversational_training_teams: MutableSequence['ConversationalTrainingTeam'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingTeam',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationalTrainingTeamRequest(proto.Message):
    r"""Request of DeleteConversationalTrainingTeam.

    Attributes:
        name (str):
            Required. The conversational training team resource name to
            delete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateConversationalTrainingTeamRequest(proto.Message):
    r"""Request of UpdateConversationalTrainingTeam.

    Attributes:
        conversational_training_team (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingTeam):
            Required. The conversational training team to
            update. The name field of conversational
            training team is to identify the conversational
            training team to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The list of fields to update.
    """

    conversational_training_team: 'ConversationalTrainingTeam' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingTeam',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class ConversationalTrainingTeam(proto.Message):
    r"""A conversational training team that includes members that
    should get similar assignments and managed by the same group of
    managers.

    Attributes:
        name (str):
            Immutable. Identifier. The resource name of the
            conversational training team. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>``.
        display_name (str):
            Required. The display name of the
            conversational training team.
        managers (MutableSequence[str]):
            Optional. The user identifiers of the
            managers for the team
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The creation time of the
            conversational training team.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The last update time of the
            conversational training team.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    managers: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=3,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=4,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
