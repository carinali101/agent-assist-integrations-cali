# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateConversationalTrainingModuleRequest',
        'GetConversationalTrainingModuleRequest',
        'ListConversationalTrainingModulesRequest',
        'ListConversationalTrainingModulesResponse',
        'DeleteConversationalTrainingModuleRequest',
        'UpdateConversationalTrainingModuleRequest',
        'ConversationalTrainingModule',
    },
)


class CreateConversationalTrainingModuleRequest(proto.Message):
    r"""Request message of CreateConversationalTrainingModule.

    Attributes:
        parent (str):
            Required. The project/location to create conversational
            training module for. Format:
            ``projects/<ProjectID>/locations/<LocationID>``.
        conversational_training_module (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule):
            Required. The conversational training module
            to create.
        conversational_training_module_id (str):
            Optional. The ID to use for the conversational training
            module, which will become the final component of the
            conversational training module's resource name.

            The conversational training module ID must be compliant with
            the regression formula ``[a-zA-Z][a-zA-Z0-9_-]*`` with the
            characters length in range of [3,64]. If the field is not
            provide, an Id will be auto-generated. If the field is
            provided, the caller is responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversational_training_module: 'ConversationalTrainingModule' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationalTrainingModule',
    )
    conversational_training_module_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class GetConversationalTrainingModuleRequest(proto.Message):
    r"""Request message of GetConversationalTrainingModule.

    Attributes:
        name (str):
            Required. The conversational training module resource name
            to retrieve. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingModules/<ConversationalTrainingModuleID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationalTrainingModulesRequest(proto.Message):
    r"""Request message of ListConversationalTrainingModules.

    Attributes:
        parent (str):
            Required. The project/location to list
            conversationalTrainingModules for. Format:
            ``projects/<ProjectID>/locations/<LocationID>``.
        page_size (int):
            Optional. Maximum number of conversational
            training models to return in a single page.
            Default to 10.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListConversationalTrainingModulesResponse(proto.Message):
    r"""Response of ListConversationalTrainingModules.

    Attributes:
        conversational_training_modules (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule]):
            List of conversationalTrainingModules
            retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversational_training_modules: MutableSequence['ConversationalTrainingModule'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingModule',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationalTrainingModuleRequest(proto.Message):
    r"""Request of DeleteConversationalTrainingModule.

    Attributes:
        name (str):
            Required. The conversational training module resource name
            to delete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingModules/<ConversationalTrainingModuleID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateConversationalTrainingModuleRequest(proto.Message):
    r"""Request of UpdateConversationalTrainingModule.

    Attributes:
        conversational_training_module (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule):
            Required. The conversational training module
            to update. The name field of conversational
            training module is to identify the
            conversational training module to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The list of fields to update.
    """

    conversational_training_module: 'ConversationalTrainingModule' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingModule',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class ConversationalTrainingModule(proto.Message):
    r"""A conversational training module which bundles training
    resources into an assignable unit of training.

    Attributes:
        name (str):
            Immutable. Identifier. The resource name of the
            conversational training module. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingModules/<ConversationalTrainingModuleID>``.
        display_name (str):
            Required. The display name of the
            conversational training module.
        description (str):
            Optional. The description of the
            conversational training module.
        learning_objectives (str):
            Optional. Learning objectives for this
            training module to present to trainees.
        conversation_modality (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule.ConversationModality):
            Required. The modality of the training
            conversations.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The creation time of the
            conversational training module.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The last update time of the
            conversational training module.
        qa_scorecard (str):
            Optional. The full name of a QAI scorecard Format:
            ``projects/<ProjectID>/locations/<LocationID>/qaScorecards/<QaScorecardID>``.
        components (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule.ModuleComponent]):
            Required. Training components configured for
            this module.
        module_stage (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule.Stage):
            Required. Current status of the module.
    """
    class ConversationModality(proto.Enum):
        r"""The modality of a training conversation.

        Values:
            CONVERSATION_MODALITY_UNSPECIFIED (0):
                Not specified.
            VOICE (1):
                Voice conversations.
            CHAT (2):
                Chat conversations.
        """
        CONVERSATION_MODALITY_UNSPECIFIED = 0
        VOICE = 1
        CHAT = 2

    class Stage(proto.Enum):
        r"""Stages for a module.

        Values:
            STAGE_UNSPECIFIED (0):
                Not specified.
            DRAFT (1):
                Module is in the draft state and not ready to
                assign.
            PUBLISHED (2):
                Module is ready to be used.
            ARCHIVED (3):
                Module is no longer in use.
        """
        STAGE_UNSPECIFIED = 0
        DRAFT = 1
        PUBLISHED = 2
        ARCHIVED = 3

    class SimulationComponent(proto.Message):
        r"""Module's training simulation and how it should work within a
        training module.

        Attributes:
            simulation (str):
                Required. The full name of the referenced training
                simulation conversational profile. Format:
                ``projects/<ProjectID>/locations/<LocationID>/conversationalProfiles/<ConversationalProfileID>``.
        """

        simulation: str = proto.Field(
            proto.STRING,
            number=1,
        )

    class ModuleComponent(proto.Message):
        r"""A piece of a training module that initially only supports
        simulations.


        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            module_component_uuid (str):
                Optional. Immutable. Module component uuid to
                identify the component and track through
                component order changes, addition, or removal.
                If not provided, a random uuid will be generated
                and it will be considered a new component on the
                module.
            module_simulation (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingModule.SimulationComponent):
                The simulation and relevant wrapping data.

                This field is a member of `oneof`_ ``component``.
        """

        module_component_uuid: str = proto.Field(
            proto.STRING,
            number=1,
        )
        module_simulation: 'ConversationalTrainingModule.SimulationComponent' = proto.Field(
            proto.MESSAGE,
            number=2,
            oneof='component',
            message='ConversationalTrainingModule.SimulationComponent',
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    learning_objectives: str = proto.Field(
        proto.STRING,
        number=4,
    )
    conversation_modality: ConversationModality = proto.Field(
        proto.ENUM,
        number=5,
        enum=ConversationModality,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=7,
        message=timestamp_pb2.Timestamp,
    )
    qa_scorecard: str = proto.Field(
        proto.STRING,
        number=8,
    )
    components: MutableSequence[ModuleComponent] = proto.RepeatedField(
        proto.MESSAGE,
        number=9,
        message=ModuleComponent,
    )
    module_stage: Stage = proto.Field(
        proto.ENUM,
        number=10,
        enum=Stage,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
