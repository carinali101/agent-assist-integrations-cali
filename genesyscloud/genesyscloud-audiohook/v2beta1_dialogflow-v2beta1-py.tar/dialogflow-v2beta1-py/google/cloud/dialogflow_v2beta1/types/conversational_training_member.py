# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateConversationalTrainingMemberRequest',
        'GetConversationalTrainingMemberRequest',
        'ListConversationalTrainingMembersRequest',
        'ListConversationalTrainingMembersResponse',
        'DeleteConversationalTrainingMemberRequest',
        'UpdateConversationalTrainingMemberRequest',
        'ConversationalTrainingMember',
    },
)


class CreateConversationalTrainingMemberRequest(proto.Message):
    r"""Request message of CreateConversationalTrainingMember.

    Attributes:
        parent (str):
            Required. The team to create conversational training member
            for. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>``.
        conversational_training_member (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingMember):
            Required. The conversational training member
            to create.
        conversational_training_member_id (str):
            Optional. The ID to use for the conversational training
            member, which will become the final component of the
            conversational training member's resource name.

            The conversational training member ID must be compliant with
            the regression fomula ``[a-zA-Z][a-zA-Z0-9_-]*`` with the
            characters length in range of [3,64]. If the field is not
            provide, an Id will be auto-generated. If the field is
            provided, the caller is responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversational_training_member: 'ConversationalTrainingMember' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationalTrainingMember',
    )
    conversational_training_member_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class GetConversationalTrainingMemberRequest(proto.Message):
    r"""Request message of GetConversationalTrainingMember.

    Attributes:
        name (str):
            Required. The conversational training member resource name
            to retrieve. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationalTrainingMembersRequest(proto.Message):
    r"""Request message of ListConversationalTrainingMembers.

    Attributes:
        parent (str):
            Required. The team to list conversationalTrainingMembers
            for. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>``.
            or
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/-``.
        page_size (int):
            Optional. Maximum number of conversational
            training members to return in a single page.
            Default to 10.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
        filter (str):
            Optional. Filter on member fields. Currently only supports
            ``username = <username_value>``.

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListConversationalTrainingMembersResponse(proto.Message):
    r"""Response of ListConversationalTrainingMembers.

    Attributes:
        conversational_training_members (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingMember]):
            List of conversationalTrainingMembers
            retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversational_training_members: MutableSequence['ConversationalTrainingMember'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingMember',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationalTrainingMemberRequest(proto.Message):
    r"""Request of DeleteConversationalTrainingMember.

    Attributes:
        name (str):
            Required. The conversational training member resource name
            to delete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/members/<MemberID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateConversationalTrainingMemberRequest(proto.Message):
    r"""Request of UpdateConversationalTrainingMember.

    Attributes:
        conversational_training_member (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingMember):
            Required. The conversational training member
            to update. The name field of conversational
            training member is to identify the
            conversational training member to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The list of fields to update.
    """

    conversational_training_member: 'ConversationalTrainingMember' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingMember',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class ConversationalTrainingMember(proto.Message):
    r"""Represents a user in the context of a conversational training
    team. A user can be a member of multiple teams.

    Attributes:
        name (str):
            Immutable. Identifier. The resource name of the
            conversational training member. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``.
        display_name (str):
            Required. The name of the member.
        username (str):
            Required. The username of the member.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The creation time of the
            conversational training member.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The last update time of the
            conversational training member.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    username: str = proto.Field(
        proto.STRING,
        number=3,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=4,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
