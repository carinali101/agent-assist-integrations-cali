# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import webhook
from google.rpc import status_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'PushFulfillmentResultRequest',
        'FulfillmentResult',
    },
)


class PushFulfillmentResultRequest(proto.Message):
    r"""The request message for
    [AsynchronousFulfillment.PushFulfillmentResult][google.cloud.dialogflow.v2beta1.AsynchronousFulfillment.PushFulfillmentResult].

    Attributes:
        session (str):
            Required. The name of the session to push the fulfillment
            result for. Format:
            ``projects/<Project ID>/agent/sessions/<Session ID>``, or
            ``projects/<Project ID>/agent/environments/<Environment ID>/users/<User ID>/sessions/<Session ID>``.
            If ``Environment ID`` is not specified, we assume default
            'draft' environment. If ``User ID`` is not specified, we are
            using "-". It's up to the API caller to choose an
            appropriate ``Session ID`` and ``User Id``. They can be a
            random numbers or some type of user and session identifiers
            (preferably hashed). The length of the ``Session ID`` and
            ``User ID`` must not exceed 36 characters.
        fulfillment_result (google.cloud.dialogflow_v2beta1.types.FulfillmentResult):
            Required. The fulfillment result to push to
            Dialogflow.
    """

    session: str = proto.Field(
        proto.STRING,
        number=1,
    )
    fulfillment_result: 'FulfillmentResult' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='FulfillmentResult',
    )


class FulfillmentResult(proto.Message):
    r"""The response message for
    [AsynchronousFulfillment.PushFulfillmentResult][google.cloud.dialogflow.v2beta1.AsynchronousFulfillment.PushFulfillmentResult].

    Attributes:
        event_name (str):
            Required. The name of the event that the async fulfillment
            is associated. The format of full event name is:
            ASYNC_FULFILLMENT_POLL\_.
        fulfillment_response (google.cloud.dialogflow_v2beta1.types.WebhookResponse):
            Optional. The response message for a fulfillment call. If
            fulfillment_status is not OK, the fulfillment may not be
            populated.
        fulfillment_status (google.rpc.status_pb2.Status):
            Required. The status of the fulfillment.
    """

    event_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    fulfillment_response: webhook.WebhookResponse = proto.Field(
        proto.MESSAGE,
        number=2,
        message=webhook.WebhookResponse,
    )
    fulfillment_status: status_pb2.Status = proto.Field(
        proto.MESSAGE,
        number=3,
        message=status_pb2.Status,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
