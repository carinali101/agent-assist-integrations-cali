# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import conversation_profile as gcd_conversation_profile
from google.cloud.dialogflow_v2beta1.types import gcs
from google.cloud.dialogflow_v2beta1.types import generator as gcd_generator
from google.cloud.dialogflow_v2beta1.types import interaction_monitoring
from google.cloud.dialogflow_v2beta1.types import participant
from google.cloud.dialogflow_v2beta1.types import session
from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import struct_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore
from google.rpc import status_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'Conversation',
        'ConversationPhoneNumber',
        'UpdateConversationRequest',
        'CallMatcher',
        'CreateConversationRequest',
        'ListConversationsRequest',
        'ListConversationsResponse',
        'GetConversationRequest',
        'AddConversationPhoneNumberRequest',
        'ActivateConversationRequest',
        'DeactivateConversationRequest',
        'CompleteConversationRequest',
        'CreateCallMatcherRequest',
        'ListCallMatchersRequest',
        'ListCallMatchersResponse',
        'DeleteCallMatcherRequest',
        'CreateMessageRequest',
        'BatchCreateMessagesRequest',
        'BatchCreateMessagesResponse',
        'ListMessagesRequest',
        'ListMessagesResponse',
        'ExportMessagesRequest',
        'ExportMessagesResponse',
        'IngestContextReferencesRequest',
        'IngestContextReferencesResponse',
        'SuggestConversationSummaryRequest',
        'SuggestConversationSummaryResponse',
        'SuggestConversationKeyMomentsRequest',
        'SuggestConversationKeyMomentsResponse',
        'SearchArticleAnswer',
        'SearchArticlesRequest',
        'SearchArticlesResponse',
        'ListPastCallCompanionEventsRequest',
        'ListPastCallCompanionEventsResponse',
        'StreamingListUpcomingCallCompanionEventsRequest',
        'StreamingListUpcomingCallCompanionEventsResponse',
        'InjectCallCompanionUserInputRequest',
        'InjectCallCompanionUserInputResponse',
        'StreamingListCallCompanionEventsRequest',
        'StreamingListCallCompanionEventsResponse',
        'InjectCallCompanionInputRequest',
        'InjectCallCompanionInputResponse',
        'InitializeCallCompanionRequest',
        'GetCallCompanionSettingsRequest',
        'CallCompanionSettings',
        'CallCompanionUserInput',
        'CallCompanionConversationEvent',
        'GenerateStatelessSummaryRequest',
        'GenerateStatelessSummaryResponse',
        'GenerateStatelessSuggestionRequest',
        'GenerateStatelessSuggestionResponse',
        'SearchKnowledgeRequest',
        'SearchKnowledgeDebugInfo',
        'SearchKnowledgeResponse',
        'SearchKnowledgeAnswer',
        'GenerateSuggestionsRequest',
        'InitiatePhoneCallRequest',
        'InitiatePhoneCallResponse',
        'InjectSupervisorInputRequest',
        'InjectSupervisorInputResponse',
        'GetInteractionMonitoringAlertRequest',
        'ListInteractionMonitoringAlertsRequest',
        'ListInteractionMonitoringAlertsResponse',
        'AckInteractionMonitoringAlertRequest',
        'ListInteractionMonitoringMetricsRequest',
        'ListInteractionMonitoringMetricsResponse',
    },
)


class Conversation(proto.Message):
    r"""Represents a conversation.
    A conversation is an interaction between an agent, including
    live agents and Dialogflow agents, and a support customer.
    Conversations can include phone calls and text-based chat
    sessions.

    Attributes:
        name (str):
            Output only. Identifier. The unique identifier of this
            conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        lifecycle_state (google.cloud.dialogflow_v2beta1.types.Conversation.LifecycleState):
            Output only. The current state of the
            Conversation.
        conversation_profile (str):
            Required. The Conversation Profile to be used to configure
            this Conversation. This field cannot be updated. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversationProfiles/<Conversation Profile ID>``.
        phone_number (google.cloud.dialogflow_v2beta1.types.ConversationPhoneNumber):
            Output only. Required if the conversation is
            to be connected over telephony.
        conversation_stage (google.cloud.dialogflow_v2beta1.types.Conversation.ConversationStage):
            Optional. The stage of a conversation. It indicates whether
            the virtual agent or a human agent is handling the
            conversation.

            If the conversation is created with the conversation profile
            that has Dialogflow config set, defaults to
            [ConversationStage.VIRTUAL_AGENT_STAGE][google.cloud.dialogflow.v2beta1.Conversation.ConversationStage.VIRTUAL_AGENT_STAGE];
            Otherwise, defaults to
            [ConversationStage.HUMAN_ASSIST_STAGE][google.cloud.dialogflow.v2beta1.Conversation.ConversationStage.HUMAN_ASSIST_STAGE].

            If the conversation is created with the conversation profile
            that has Dialogflow config set but explicitly sets
            conversation_stage to
            [ConversationStage.HUMAN_ASSIST_STAGE][google.cloud.dialogflow.v2beta1.Conversation.ConversationStage.HUMAN_ASSIST_STAGE],
            it skips
            [ConversationStage.VIRTUAL_AGENT_STAGE][google.cloud.dialogflow.v2beta1.Conversation.ConversationStage.VIRTUAL_AGENT_STAGE]
            stage and directly goes to
            [ConversationStage.HUMAN_ASSIST_STAGE][google.cloud.dialogflow.v2beta1.Conversation.ConversationStage.HUMAN_ASSIST_STAGE].
        start_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The time the conversation was
            started.
        end_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The time the conversation was
            finished.
        transcribe_mode (google.cloud.dialogflow_v2beta1.types.Conversation.TranscribeMode):
            Optional. The transcribe mode of a
            conversation.
        telephony_connection_info (google.cloud.dialogflow_v2beta1.types.Conversation.TelephonyConnectionInfo):
            Output only. The telephony connection
            information.
        ingested_context_references (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference]):
            Output only. The context reference updates
            provided by external systems.
        supervisor_mapping_status (google.cloud.dialogflow_v2beta1.types.Conversation.SupervisorMappingStatus):
            Output only. The supervisor mapping status of
            the session.
    """
    class LifecycleState(proto.Enum):
        r"""Enumeration of the completion status of the conversation.

        Values:
            LIFECYCLE_STATE_UNSPECIFIED (0):
                Unknown.
            IN_PROGRESS (1):
                Conversation is currently open for media
                analysis.
            COMPLETED (2):
                Conversation has been completed.
        """
        LIFECYCLE_STATE_UNSPECIFIED = 0
        IN_PROGRESS = 1
        COMPLETED = 2

    class ConversationStage(proto.Enum):
        r"""Enumeration of the different conversation stages a conversation can
        be in. Reference:
        https://cloud.google.com/agent-assist/docs/basics#conversation_stages

        Values:
            CONVERSATION_STAGE_UNSPECIFIED (0):
                Unknown. Should never be used after a
                conversation is successfully created.
            VIRTUAL_AGENT_STAGE (1):
                The conversation should return virtual agent
                responses into the conversation.
            HUMAN_ASSIST_STAGE (2):
                The conversation should not provide
                responses, just listen and provide suggestions.
        """
        CONVERSATION_STAGE_UNSPECIFIED = 0
        VIRTUAL_AGENT_STAGE = 1
        HUMAN_ASSIST_STAGE = 2

    class TranscribeMode(proto.Enum):
        r"""The transcribe mode of a conversation. By default the transcribe
        mode is "TRANSCRIBE_ON". It indicates whether we should transcribe
        the voice conversation through telephony.

        Values:
            TRANSCRIBE_MODE_UNSPECIFIED (0):
                Unknown.
            TRANSCRIBE_ON (1):
                The conversation is actively being
                transcribed.
            TRANSCRIBE_OFF (2):
                The conversation stops transcribing.
        """
        TRANSCRIBE_MODE_UNSPECIFIED = 0
        TRANSCRIBE_ON = 1
        TRANSCRIBE_OFF = 2

    class TelephonyConnectionInfo(proto.Message):
        r"""The information about phone calls connected via phone gateway
        to the conversation.

        Attributes:
            dialed_number (str):
                Output only. The number dialed to connect
                this call in E.164 format.
            sdp (str):
                Optional. SDP of the call. It's initially the
                SDP answer to the incoming call, but maybe later
                updated for the purpose of making the link
                active, etc.
            sip_headers (MutableSequence[google.cloud.dialogflow_v2beta1.types.Conversation.TelephonyConnectionInfo.SipHeader]):
                Output only. The SIP headers from the initial
                SIP INVITE.
            extra_mime_contents (MutableSequence[google.cloud.dialogflow_v2beta1.types.Conversation.TelephonyConnectionInfo.MimeContent]):
                Output only. The mime content from the
                initial SIP INVITE.
        """

        class SipHeader(proto.Message):
            r"""The SIP headers from the initial SIP INVITE.

            Attributes:
                name (str):
                    Optional. The name of the header.
                value (str):
                    Optional. The value of the header.
            """

            name: str = proto.Field(
                proto.STRING,
                number=1,
            )
            value: str = proto.Field(
                proto.STRING,
                number=2,
            )

        class MimeContent(proto.Message):
            r"""The mime content from the initial SIP INVITE.

            Attributes:
                mime_type (str):
                    Optional. The mime type of the content.
                content (bytes):
                    Optional. The content payload.
            """

            mime_type: str = proto.Field(
                proto.STRING,
                number=1,
            )
            content: bytes = proto.Field(
                proto.BYTES,
                number=2,
            )

        dialed_number: str = proto.Field(
            proto.STRING,
            number=2,
        )
        sdp: str = proto.Field(
            proto.STRING,
            number=5,
        )
        sip_headers: MutableSequence['Conversation.TelephonyConnectionInfo.SipHeader'] = proto.RepeatedField(
            proto.MESSAGE,
            number=12,
            message='Conversation.TelephonyConnectionInfo.SipHeader',
        )
        extra_mime_contents: MutableSequence['Conversation.TelephonyConnectionInfo.MimeContent'] = proto.RepeatedField(
            proto.MESSAGE,
            number=13,
            message='Conversation.TelephonyConnectionInfo.MimeContent',
        )

    class ContextReference(proto.Message):
        r"""Represents a piece of ingested context information.

        Attributes:
            context_contents (MutableSequence[google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference.ContextContent]):
                Required. The list of content updates for a
                context reference.
            update_mode (google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference.UpdateMode):
                Required. The mode in which context reference
                contents are updated.
            language_code (str):
                Optional. The language of the information
                ingested, defaults to "en-US" if not set.
            create_time (google.protobuf.timestamp_pb2.Timestamp):
                Output only. The time the context reference
                was first created.
        """
        class UpdateMode(proto.Enum):
            r"""Represents the mode in which context reference contents are
            updated.

            Values:
                UPDATE_MODE_UNSPECIFIED (0):
                    Unspecified update mode.
                APPEND (1):
                    Context content updates are applied in append
                    mode.
                OVERWRITE (2):
                    Context content updates are applied in
                    overwrite mode.
            """
            UPDATE_MODE_UNSPECIFIED = 0
            APPEND = 1
            OVERWRITE = 2

        class ContextContent(proto.Message):
            r"""Contents ingested.

            Attributes:
                content (str):
                    Required. The information ingested in a
                    single request.
                content_format (google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference.ContextContent.ContentFormat):
                    Required. The format of the ingested string.
                ingestion_time (google.protobuf.timestamp_pb2.Timestamp):
                    Output only. The time when this information
                    was incorporated into the relevant context
                    reference.
                answer_record (str):
                    If the context content was generated from a tool call,
                    specify the answer record associated with the tool call.
                    Format:
                    ``projects/<Project ID>/locations/<Location ID>/answerRecords/<Answer Record ID>``.
            """
            class ContentFormat(proto.Enum):
                r"""Represents the format of the ingested string.

                Values:
                    CONTENT_FORMAT_UNSPECIFIED (0):
                        Unspecified content format.
                    JSON (1):
                        Content was provided in JSON format.
                    PLAIN_TEXT (2):
                        Content was provided as plain text.
                """
                CONTENT_FORMAT_UNSPECIFIED = 0
                JSON = 1
                PLAIN_TEXT = 2

            content: str = proto.Field(
                proto.STRING,
                number=1,
            )
            content_format: 'Conversation.ContextReference.ContextContent.ContentFormat' = proto.Field(
                proto.ENUM,
                number=2,
                enum='Conversation.ContextReference.ContextContent.ContentFormat',
            )
            ingestion_time: timestamp_pb2.Timestamp = proto.Field(
                proto.MESSAGE,
                number=3,
                message=timestamp_pb2.Timestamp,
            )
            answer_record: str = proto.Field(
                proto.STRING,
                number=4,
            )

        context_contents: MutableSequence['Conversation.ContextReference.ContextContent'] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='Conversation.ContextReference.ContextContent',
        )
        update_mode: 'Conversation.ContextReference.UpdateMode' = proto.Field(
            proto.ENUM,
            number=2,
            enum='Conversation.ContextReference.UpdateMode',
        )
        language_code: str = proto.Field(
            proto.STRING,
            number=3,
        )
        create_time: timestamp_pb2.Timestamp = proto.Field(
            proto.MESSAGE,
            number=4,
            message=timestamp_pb2.Timestamp,
        )

    class SupervisorMappingStatus(proto.Message):
        r"""The supervisor mapping status of the session.

        Attributes:
            monitored (bool):
                Output only. The session is being
                monitored/scanned.
            escalated_to_supervisor (bool):
                Output only. The session is escalated to a
                supervisor for intervention.
            assigned_supervisor (str):
                Optional. The supervisor assigned to the
                session.
            transferred_to_human_agent (bool):
                Output only. The session is transferred to a
                human agent.
            call_transfer_reason (str):
                Optional. Supervisor's reason for
                transferring conversation to a human agent.
            aggregated_end_user_sentiment_ema (float):
                Output only. The aggregated end user
                sentiment score of the session, calculated by
                exponential moving average.
        """

        monitored: bool = proto.Field(
            proto.BOOL,
            number=1,
        )
        escalated_to_supervisor: bool = proto.Field(
            proto.BOOL,
            number=2,
        )
        assigned_supervisor: str = proto.Field(
            proto.STRING,
            number=3,
        )
        transferred_to_human_agent: bool = proto.Field(
            proto.BOOL,
            number=4,
        )
        call_transfer_reason: str = proto.Field(
            proto.STRING,
            number=5,
        )
        aggregated_end_user_sentiment_ema: float = proto.Field(
            proto.FLOAT,
            number=6,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    lifecycle_state: LifecycleState = proto.Field(
        proto.ENUM,
        number=2,
        enum=LifecycleState,
    )
    conversation_profile: str = proto.Field(
        proto.STRING,
        number=3,
    )
    phone_number: 'ConversationPhoneNumber' = proto.Field(
        proto.MESSAGE,
        number=4,
        message='ConversationPhoneNumber',
    )
    conversation_stage: ConversationStage = proto.Field(
        proto.ENUM,
        number=7,
        enum=ConversationStage,
    )
    start_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )
    end_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    transcribe_mode: TranscribeMode = proto.Field(
        proto.ENUM,
        number=9,
        enum=TranscribeMode,
    )
    telephony_connection_info: TelephonyConnectionInfo = proto.Field(
        proto.MESSAGE,
        number=10,
        message=TelephonyConnectionInfo,
    )
    ingested_context_references: MutableMapping[str, ContextReference] = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=17,
        message=ContextReference,
    )
    supervisor_mapping_status: SupervisorMappingStatus = proto.Field(
        proto.MESSAGE,
        number=19,
        message=SupervisorMappingStatus,
    )


class ConversationPhoneNumber(proto.Message):
    r"""Represents a phone number for telephony integration. It
    allows for connecting a particular conversation over telephony.

    Attributes:
        country_code (int):
            Output only. Desired country code for the
            phone number.
        phone_number (str):
            Output only. The phone number to connect to
            this conversation.
    """

    country_code: int = proto.Field(
        proto.INT32,
        number=2,
    )
    phone_number: str = proto.Field(
        proto.STRING,
        number=3,
    )


class UpdateConversationRequest(proto.Message):
    r"""The request message for
    [Conversations.UpdateConversation][google.cloud.dialogflow.v2beta1.Conversations.UpdateConversation].

    Attributes:
        conversation (google.cloud.dialogflow_v2beta1.types.Conversation):
            Required. The conversation to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Required. The mask to control which fields to
            update.
    """

    conversation: 'Conversation' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='Conversation',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class CallMatcher(proto.Message):
    r"""Represents a call matcher that describes criteria for matching
    incoming SIP calls to a conversation. When Dialogflow get a SIP call
    from a third-party carrier, Dialogflow matches the call to an
    existing conversation by either:

    - Extracting the conversation id from the `Call-Info
      header <https://tools.ietf.org/html/rfc3261#section-20.9>`__,
      e.g.,
      ``Call-Info: <http://dialogflow.googleapis.com/v2beta1/projects/111/conversations/222> ;purpose=Goog-ContactCenter-Conversation``.
    - Or, if that doesn't work, matching incoming `SIP
      headers <https://tools.ietf.org/html/rfc3261#section-7.3>`__
      against any
      [CallMatcher][google.cloud.dialogflow.v2beta1.CallMatcher] for the
      conversation.

    If an incoming SIP call without valid ``Call-Info`` header matches
    to zero or multiple conversations with ``CallMatcher``, we reject
    it.

    A call matcher contains equality conditions for SIP headers that all
    have to be fulfilled in order for a SIP call to match.

    The matched SIP headers consist of well-known headers (``To``,
    ``From``, ``Call-ID``) and custom headers. A
    [CallMatcher][google.cloud.dialogflow.v2beta1.CallMatcher] is only
    valid if it specifies:

    - At least 1 custom header,
    - or at least 2 well-known headers.

    Attributes:
        name (str):
            Output only. Identifier. The unique identifier of this call
            matcher. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/callMatchers/<Call Matcher ID>``.
        to_header (str):
            Optional. Value of the ```To``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.2>`__
            to match. If empty or unspecified, we don't match to the
            ```To``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.2>`__.
        from_header (str):
            Optional. Value of the ```From``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.3>`__
            to match. If empty or unspecified, we don't match to the
            ```From``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.3>`__.
        call_id_header (str):
            Optional. Value of the ```Call-ID``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.4>`__
            to match. If empty or unspecified, we don't match to the
            ```Call-ID``
            header <https://tools.ietf.org/html/rfc3261#section-8.1.1.4>`__.
        custom_headers (google.cloud.dialogflow_v2beta1.types.CallMatcher.CustomHeaders):
            Optional. Custom SIP headers that must match.
    """

    class CustomHeaders(proto.Message):
        r"""Custom SIP headers. See the `description of headers in the
        RFC <https://tools.ietf.org/html/rfc3261#section-7.3>`__.

        Attributes:
            cisco_guid (str):
                Optional. Cisco's proprietary ``Cisco-Guid`` header.
        """

        cisco_guid: str = proto.Field(
            proto.STRING,
            number=1,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    to_header: str = proto.Field(
        proto.STRING,
        number=2,
    )
    from_header: str = proto.Field(
        proto.STRING,
        number=3,
    )
    call_id_header: str = proto.Field(
        proto.STRING,
        number=4,
    )
    custom_headers: CustomHeaders = proto.Field(
        proto.MESSAGE,
        number=5,
        message=CustomHeaders,
    )


class CreateConversationRequest(proto.Message):
    r"""The request message for
    [Conversations.CreateConversation][google.cloud.dialogflow.v2beta1.Conversations.CreateConversation].

    Attributes:
        parent (str):
            Required. Resource identifier of the project creating the
            conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        conversation (google.cloud.dialogflow_v2beta1.types.Conversation):
            Required. The conversation to create.
        conversation_id (str):
            Optional. Identifier of the conversation. Generally it's
            auto generated by Google. Only set it if you cannot wait for
            the response to return a auto-generated one to you.

            The conversation ID must be compliant with the regression
            formula ``[a-zA-Z][a-zA-Z0-9_-]*`` with the characters
            length in range of [3,64]. If the field is provided, the
            caller is responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation: 'Conversation' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='Conversation',
    )
    conversation_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListConversationsRequest(proto.Message):
    r"""The request message for
    [Conversations.ListConversations][google.cloud.dialogflow.v2beta1.Conversations.ListConversations].

    Attributes:
        parent (str):
            Required. The project from which to list all conversation.
            Format: ``projects/<Project ID>/locations/<Location ID>``.
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. By default 100 and at
            most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
        filter (str):
            Optional. A filter expression that filters conversations
            listed in the response. Only ``lifecycle_state`` can be
            filtered on in this way. For example, the following
            expression only returns ``COMPLETED`` conversations:

            ``lifecycle_state = "COMPLETED"``

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListConversationsResponse(proto.Message):
    r"""The response message for
    [Conversations.ListConversations][google.cloud.dialogflow.v2beta1.Conversations.ListConversations].

    Attributes:
        conversations (MutableSequence[google.cloud.dialogflow_v2beta1.types.Conversation]):
            The list of conversations. There will be a maximum number of
            items returned based on the page_size field in the request.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversations: MutableSequence['Conversation'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='Conversation',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class GetConversationRequest(proto.Message):
    r"""The request message for
    [Conversations.GetConversation][google.cloud.dialogflow.v2beta1.Conversations.GetConversation].

    Attributes:
        name (str):
            Required. The name of the conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class AddConversationPhoneNumberRequest(proto.Message):
    r"""The request message for
    [Conversations.AddConversationPhoneNumber][google.cloud.dialogflow.v2beta1.Conversations.AddConversationPhoneNumber].

    Attributes:
        name (str):
            Required. The name of this conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ActivateConversationRequest(proto.Message):
    r"""The request message for [Conversations.ActiveConversation][].

    Attributes:
        conversation (str):
            Required. Resource identifier of the conversation to
            activate. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class DeactivateConversationRequest(proto.Message):
    r"""The request message for [Conversations.DeactiveConversation][].

    Attributes:
        conversation (str):
            Required. Resource identifier of the conversation to
            deactivate. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CompleteConversationRequest(proto.Message):
    r"""The request message for
    [Conversations.CompleteConversation][google.cloud.dialogflow.v2beta1.Conversations.CompleteConversation].

    Attributes:
        name (str):
            Required. Resource identifier of the conversation to close.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CreateCallMatcherRequest(proto.Message):
    r"""The request message for
    [Conversations.CreateCallMatcher][google.cloud.dialogflow.v2beta1.Conversations.CreateCallMatcher].

    Attributes:
        parent (str):
            Required. Resource identifier of the conversation adding the
            call matcher. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        call_matcher (google.cloud.dialogflow_v2beta1.types.CallMatcher):
            Required. The call matcher to create.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    call_matcher: 'CallMatcher' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='CallMatcher',
    )


class ListCallMatchersRequest(proto.Message):
    r"""The request message for
    [Conversations.ListCallMatchers][google.cloud.dialogflow.v2beta1.Conversations.ListCallMatchers].

    Attributes:
        parent (str):
            Required. The conversation to list all call matchers from.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. By default 100 and at
            most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListCallMatchersResponse(proto.Message):
    r"""The response message for
    [Conversations.ListCallMatchers][google.cloud.dialogflow.v2beta1.Conversations.ListCallMatchers].

    Attributes:
        call_matchers (MutableSequence[google.cloud.dialogflow_v2beta1.types.CallMatcher]):
            The list of call matchers. There is a maximum number of
            items returned based on the page_size field in the request.
        next_page_token (str):
            Token to retrieve the next page of results or
            empty if there are no more results in the list.
    """

    @property
    def raw_page(self):
        return self

    call_matchers: MutableSequence['CallMatcher'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='CallMatcher',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteCallMatcherRequest(proto.Message):
    r"""The request message for
    [Conversations.DeleteCallMatcher][google.cloud.dialogflow.v2beta1.Conversations.DeleteCallMatcher].

    Attributes:
        name (str):
            Required. The unique identifier of the
            [CallMatcher][google.cloud.dialogflow.v2beta1.CallMatcher]
            to delete. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/callMatchers/<CallMatcher ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CreateMessageRequest(proto.Message):
    r"""The request message to create one Message. Currently it is
    only used in BatchCreateMessagesRequest.

    Attributes:
        parent (str):
            Required. Resource identifier of the conversation to create
            message. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        message (google.cloud.dialogflow_v2beta1.types.Message):
            Required. The message to create.
            [Message.participant][google.cloud.dialogflow.v2beta1.Message.participant]
            is required.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    message: participant.Message = proto.Field(
        proto.MESSAGE,
        number=2,
        message=participant.Message,
    )


class BatchCreateMessagesRequest(proto.Message):
    r"""The request message for
    [Conversations.BatchCreateMessagesRequest][].

    Attributes:
        parent (str):
            Required. Resource identifier of the conversation to create
            message. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        requests (MutableSequence[google.cloud.dialogflow_v2beta1.types.CreateMessageRequest]):
            Required. A maximum of 300 messages can be created in a
            batch. [CreateMessageRequest.message.send_time][] is
            required. All created messages will have identical
            [Message.create_time][google.cloud.dialogflow.v2beta1.Message.create_time].
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    requests: MutableSequence['CreateMessageRequest'] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='CreateMessageRequest',
    )


class BatchCreateMessagesResponse(proto.Message):
    r"""The request message for
    [Conversations.BatchCreateMessagesResponse][].

    Attributes:
        messages (MutableSequence[google.cloud.dialogflow_v2beta1.types.Message]):
            Messages created.
    """

    messages: MutableSequence[participant.Message] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=participant.Message,
    )


class ListMessagesRequest(proto.Message):
    r"""The request message for
    [Conversations.ListMessages][google.cloud.dialogflow.v2beta1.Conversations.ListMessages].

    Attributes:
        parent (str):
            Required. The name of the conversation to list messages for.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``
        filter (str):
            Optional. Filter on message fields. Currently predicates on
            ``create_time`` and ``create_time_epoch_microseconds`` are
            supported. ``create_time`` only support milliseconds
            accuracy. E.g.,
            ``create_time_epoch_microseconds > 1551790877964485`` or
            ``create_time > "2017-01-15T01:30:15.01Z"``.

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. By default 100 and at
            most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListMessagesResponse(proto.Message):
    r"""The response message for
    [Conversations.ListMessages][google.cloud.dialogflow.v2beta1.Conversations.ListMessages].

    Attributes:
        messages (MutableSequence[google.cloud.dialogflow_v2beta1.types.Message]):
            Required. The list of messages. There will be a maximum
            number of items returned based on the page_size field in the
            request. ``messages`` is sorted by ``create_time`` in
            descending order.
        next_page_token (str):
            Optional. Token to retrieve the next page of
            results, or empty if there are no more results
            in the list.
    """

    @property
    def raw_page(self):
        return self

    messages: MutableSequence[participant.Message] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=participant.Message,
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class ExportMessagesRequest(proto.Message):
    r"""The request message for
    [Conversations.ExportMessages][google.cloud.dialogflow.v2beta1.Conversations.ExportMessages].
    Note: this message is pre-alpha and is subject to incompatible
    changes.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        parent (str):
            Required. The project from which messages are exported.
            Format: ``projects/<Project ID>/locations/<Location ID>``.
        filter (str):
            Required. A filter expression that filters which
            conversations are exported. The only field currently
            supported is ``start_time``, e.g.,
            ``start_time > "2019-06-01T01:23:45Z"`` (the timestamp
            literal must be double-quoted). It corresponds to the
            ``start_time`` field on the ``Conversation`` resource.

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
        gcs_destination (google.cloud.dialogflow_v2beta1.types.GcsDestination):
            The messages are exported to Cloud Storage, of the form:
            gs://bucket-name/[optional/object/prefix]

            This field is a member of `oneof`_ ``destination``.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=2,
    )
    gcs_destination: gcs.GcsDestination = proto.Field(
        proto.MESSAGE,
        number=3,
        oneof='destination',
        message=gcs.GcsDestination,
    )


class ExportMessagesResponse(proto.Message):
    r"""The response message for
    [Conversations.ExportMessages][google.cloud.dialogflow.v2beta1.Conversations.ExportMessages],
    as returned by ``Operations.GetOperation``. For pre-alpha, the
    operation will return an error if any of the conversations failed to
    export. Note: this message is pre-alpha and is subject to
    incompatible changes.

    Attributes:
        exported_conversations_count (int):
            The number of conversations successfully written to the
            destination. Since the caller specified a high-level filter
            in the ``ExportMessagesRequest``, they may not necessarily
            know beforehand how many conversations will be exported.
        export_failures (MutableSequence[google.cloud.dialogflow_v2beta1.types.ExportMessagesResponse.ExportFailure]):
            The conversations that failed to export.
    """

    class ExportFailure(proto.Message):
        r"""Represents a failed export.

        Attributes:
            conversation (str):
                The resource name of the conversation that failed to export.
                Format:
                ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``
            status (google.rpc.status_pb2.Status):
                The status indicating why the export failed.
        """

        conversation: str = proto.Field(
            proto.STRING,
            number=1,
        )
        status: status_pb2.Status = proto.Field(
            proto.MESSAGE,
            number=2,
            message=status_pb2.Status,
        )

    exported_conversations_count: int = proto.Field(
        proto.INT32,
        number=2,
    )
    export_failures: MutableSequence[ExportFailure] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=ExportFailure,
    )


class IngestContextReferencesRequest(proto.Message):
    r"""The request message for
    [ConversationsService.IngestContextReferences][].

    Attributes:
        conversation (str):
            Required. Resource identifier of the conversation to ingest
            context information for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        context_references (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference]):
            Required. The context references to ingest.
            The key is the name of the context reference and
            the value contains the contents of the context
            reference. The key is used to incorporate
            ingested context references to enhance the
            generator.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    context_references: MutableMapping[str, 'Conversation.ContextReference'] = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=2,
        message='Conversation.ContextReference',
    )


class IngestContextReferencesResponse(proto.Message):
    r"""The response message for
    [ConversationsService.IngestContextReferences][].

    Attributes:
        ingested_context_references (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference]):
            All context references ingested.
    """

    ingested_context_references: MutableMapping[str, 'Conversation.ContextReference'] = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=1,
        message='Conversation.ContextReference',
    )


class SuggestConversationSummaryRequest(proto.Message):
    r"""The request message for
    [Conversations.SuggestConversationSummary][google.cloud.dialogflow.v2beta1.Conversations.SuggestConversationSummary].

    Attributes:
        conversation (str):
            Required. The conversation to fetch suggestion for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        latest_message (str):
            Optional. The name of the latest conversation message used
            as context for compiling suggestion. If empty, the latest
            message of the conversation will be used.

            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        context_size (int):
            Optional. Max number of messages prior to and including
            [latest_message] to use as context when compiling the
            suggestion. By default 500 and at most 1000.
        assist_query_params (google.cloud.dialogflow_v2beta1.types.AssistQueryParameters):
            Optional. Parameters for a human assist
            query. Only used for POC/demo purpose.
        filter (str):
            Optional. Filter on conversation messages used as context
            for compiling suggestion. Currently, only the
            ``create_time`` predicate is supported, and it only supports
            millisecond accuracy. E.g.,
            ``create_time > "2017-01-15T01:30:15.01Z"``.

            To filter on multiple expressions, such as specifying the
            start and end time, separate the expressions with ``AND``
            operator. E.g.,
            ``create_time > "2017-01-15T01:30:15.01Z" AND``\ create_time
            < "2017-01-16T02:30:15.01Z"\`

            For more information about filtering, see `API
            Filtering <https://aip.dev/160>`__.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=3,
    )
    context_size: int = proto.Field(
        proto.INT32,
        number=4,
    )
    assist_query_params: participant.AssistQueryParameters = proto.Field(
        proto.MESSAGE,
        number=5,
        message=participant.AssistQueryParameters,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=6,
    )


class SuggestConversationSummaryResponse(proto.Message):
    r"""The response message for
    [Conversations.SuggestConversationSummary][google.cloud.dialogflow.v2beta1.Conversations.SuggestConversationSummary].

    Attributes:
        summary (google.cloud.dialogflow_v2beta1.types.SuggestConversationSummaryResponse.Summary):
            Generated summary.
        latest_message (str):
            The name of the latest conversation message used as context
            for compiling suggestion.

            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        context_size (int):
            Number of messages prior to and including
            [last_conversation_message][] used to compile the
            suggestion. It may be smaller than the
            [SuggestSummaryRequest.context_size][] field in the request
            if there weren't that many messages in the conversation.
    """

    class Summary(proto.Message):
        r"""Generated summary for a conversation.

        Attributes:
            text (str):
                The summary content that is concatenated into
                one string.
            text_sections (MutableMapping[str, str]):
                The summary content that is divided into
                sections. The key is the section's name and the
                value is the section's content. There is no
                specific format for the key or value.
            confidence (float):
                The confidence score of the summary.
            answer_record (str):
                The name of the answer record. Format:

                "projects/<Project ID>/answerRecords/<Answer
                Record ID>".
            baseline_model_version (str):
                The baseline model version used to generate
                this summary. It is empty if a baseline model
                was not used to generate this summary.
        """

        text: str = proto.Field(
            proto.STRING,
            number=1,
        )
        text_sections: MutableMapping[str, str] = proto.MapField(
            proto.STRING,
            proto.STRING,
            number=4,
        )
        confidence: float = proto.Field(
            proto.FLOAT,
            number=2,
        )
        answer_record: str = proto.Field(
            proto.STRING,
            number=3,
        )
        baseline_model_version: str = proto.Field(
            proto.STRING,
            number=5,
        )

    summary: Summary = proto.Field(
        proto.MESSAGE,
        number=1,
        message=Summary,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=2,
    )
    context_size: int = proto.Field(
        proto.INT32,
        number=3,
    )


class SuggestConversationKeyMomentsRequest(proto.Message):
    r"""The request message for
    [Participants.SuggestConversationKeyMoments][].

    Attributes:
        conversation (str):
            Required. The conversation to fetch suggestions for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        latest_message (str):
            The name of the latest conversation message used as context
            for compiling suggestions. If empty, the latest message of
            the conversation will be used.

            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        context_size (int):
            Max number of messages prior to and including
            [latest_message] to use as context when compiling the
            suggestion. By default 500 and at most 1000.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=3,
    )
    context_size: int = proto.Field(
        proto.INT32,
        number=4,
    )


class SuggestConversationKeyMomentsResponse(proto.Message):
    r"""The response message for
    [Participants.SuggestConversationKeyMoments][].

    Attributes:
        key_moments (MutableSequence[google.cloud.dialogflow_v2beta1.types.SuggestConversationKeyMomentsResponse.KeyMoment]):
            Selected key moments.
        latest_message (str):
            The name of the latest conversation message used as context
            for compiling suggestions.

            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        context_size (int):
            Number of messages prior to and including
            [last_conversation_message][] used to compile the
            suggestions. It may be smaller than the
            [CompileSuggestionRequest.context_messages_count][] field in
            the request if there weren't that many messages in the
            conversation.
    """

    class KeyMoment(proto.Message):
        r"""Selected key moment in a conversation.

        Attributes:
            message (str):
                Required. Message id of the key moment.
            confidence (float):
                Confidence of the key moment.
            answer_record (str):
                The name of answer record, in the format of
                "projects/<Project ID>/answerRecords/<Answer
                Record ID>".
        """

        message: str = proto.Field(
            proto.STRING,
            number=1,
        )
        confidence: float = proto.Field(
            proto.FLOAT,
            number=2,
        )
        answer_record: str = proto.Field(
            proto.STRING,
            number=3,
        )

    key_moments: MutableSequence[KeyMoment] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=KeyMoment,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=2,
    )
    context_size: int = proto.Field(
        proto.INT32,
        number=3,
    )


class SearchArticleAnswer(proto.Message):
    r"""Represents a SearchArticles answer.

    Attributes:
        title (str):
            The article title.
        uri (str):
            The article URI.
        snippets (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchArticleAnswer.SnippetAnswer]):
            Matching (most relevant) article snippets,
            ordered by their position in the original
            document.
        metadata (MutableMapping[str, str]):
            A map that contains metadata about the answer
            and the document from which it originates.
        answer_record (str):
            The name of answer record, in the format of
            "projects/<Project ID>/locations/<Location
            ID>/answerRecords/<Answer Record ID>".
    """

    class SnippetAnswer(proto.Message):
        r"""Represents an article snippet answer

        Attributes:
            position (int):
                Snippet position within the article.
            content (str):
                Snippet content.
        """

        position: int = proto.Field(
            proto.INT32,
            number=1,
        )
        content: str = proto.Field(
            proto.STRING,
            number=2,
        )

    title: str = proto.Field(
        proto.STRING,
        number=1,
    )
    uri: str = proto.Field(
        proto.STRING,
        number=2,
    )
    snippets: MutableSequence[SnippetAnswer] = proto.RepeatedField(
        proto.MESSAGE,
        number=3,
        message=SnippetAnswer,
    )
    metadata: MutableMapping[str, str] = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=5,
    )
    answer_record: str = proto.Field(
        proto.STRING,
        number=6,
    )


class SearchArticlesRequest(proto.Message):
    r"""The request message for
    [Conversations.SearchArticles][google.cloud.dialogflow.v2beta1.Conversations.SearchArticles].

    Attributes:
        conversation (str):
            Required. The name of the conversation in which Smart Search
            is performed. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        query (google.cloud.dialogflow_v2beta1.types.TextInput):
            Required. The natural language text query to
            search articles using.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    query: session.TextInput = proto.Field(
        proto.MESSAGE,
        number=2,
        message=session.TextInput,
    )


class SearchArticlesResponse(proto.Message):
    r"""The response message for
    [Conversations.SearchArticles][google.cloud.dialogflow.v2beta1.Conversations.SearchArticles].

    Attributes:
        article_answers (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchArticleAnswer]):
            Output only. Articles ordered by score in
            descending order.
    """

    article_answers: MutableSequence['SearchArticleAnswer'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='SearchArticleAnswer',
    )


class ListPastCallCompanionEventsRequest(proto.Message):
    r"""Request message for 'ListPastCallCompanionEvents' method.

    Attributes:
        conversation (str):
            Required. The conversation to list all
            conversation events for. Format:
            "/projects/.../locations/.../conversations/...".
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. By default 100 and at
            most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListPastCallCompanionEventsResponse(proto.Message):
    r"""Response message for 'ListPastCallCompanionEvents' method.

    Attributes:
        call_companion_conversation_events (MutableSequence[google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent]):
            List of events in the conversation
            transcript.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    call_companion_conversation_events: MutableSequence['CallCompanionConversationEvent'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='CallCompanionConversationEvent',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class StreamingListUpcomingCallCompanionEventsRequest(proto.Message):
    r"""Request message for
    'StreamingListUpcomingCallCompanionEvents' method.

    Attributes:
        conversation (str):
            Required. The conversation to list incoming conversation
            events for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class StreamingListUpcomingCallCompanionEventsResponse(proto.Message):
    r"""Response message for
    'StreamingListUpcomingCallCompanionEvents' method.

    Attributes:
        call_companion_conversation_event (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent):
            Incoming Call Companion conversation event.
    """

    call_companion_conversation_event: 'CallCompanionConversationEvent' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='CallCompanionConversationEvent',
    )


class InjectCallCompanionUserInputRequest(proto.Message):
    r"""Request message for 'InjectCallCompanionUserInput' method.

    Attributes:
        conversation (str):
            Required. The conversation to inject user input into.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        user_input (google.cloud.dialogflow_v2beta1.types.CallCompanionUserInput):
            Required. User input to inject.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    user_input: 'CallCompanionUserInput' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='CallCompanionUserInput',
    )


class InjectCallCompanionUserInputResponse(proto.Message):
    r"""Response message for 'InjectCallCompanionUserInput' method.
    """


class StreamingListCallCompanionEventsRequest(proto.Message):
    r"""Request message for [StreamingListCallCompanionEvents][]. method.

    Attributes:
        conversation (str):
            Required. The conversation to list incoming conversation
            events for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        authentication_code (bytes):
            Optional. Authentication code for accessing
            the conversation, included in the Call Companion
            SMS link.
        include_past_events (bool):
            Optional. Whether to return past events as
            well.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    authentication_code: bytes = proto.Field(
        proto.BYTES,
        number=2,
    )
    include_past_events: bool = proto.Field(
        proto.BOOL,
        number=3,
    )


class StreamingListCallCompanionEventsResponse(proto.Message):
    r"""Response message for [StreamingListCallCompanionEvents][]. method.

    Attributes:
        call_companion_conversation_event (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent):
            Incoming Call Companion conversation event.
    """

    call_companion_conversation_event: 'CallCompanionConversationEvent' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='CallCompanionConversationEvent',
    )


class InjectCallCompanionInputRequest(proto.Message):
    r"""Request message for [InjectCallCompanionInput][].

    Attributes:
        conversation (str):
            Required. The conversation to inject user input into.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        user_input (google.cloud.dialogflow_v2beta1.types.CallCompanionUserInput):
            Required. User input to inject.
        authentication_code (bytes):
            Optional. Authentication code for accessing
            the conversation, sent by the Call Companion SMS
            link.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    user_input: 'CallCompanionUserInput' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='CallCompanionUserInput',
    )
    authentication_code: bytes = proto.Field(
        proto.BYTES,
        number=3,
    )


class InjectCallCompanionInputResponse(proto.Message):
    r"""Response message for [InjectCallCompanionInput][]'.
    """


class InitializeCallCompanionRequest(proto.Message):
    r"""Request message for [InitializeCallCompanion][].

    Attributes:
        conversation (str):
            Required. The conversation to perform the initialization.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )


class GetCallCompanionSettingsRequest(proto.Message):
    r"""Request message for [GetCallCompanionSettings][].

    Attributes:
        conversation (str):
            Required. The conversation to get settings for. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        authentication_code (bytes):
            Optional. Authentication code for accessing
            the conversation, sent by the Call Companion SMS
            link.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    authentication_code: bytes = proto.Field(
        proto.BYTES,
        number=2,
    )


class CallCompanionSettings(proto.Message):
    r"""Response message for [GetCallCompanionSettings][].

    Attributes:
        company (str):
            The company name to be displayed on UI.
        logo_uri (str):
            URI of the logo image.
        font (str):
            Font face used for the text.
        text_color (str):
            Text color of the web page.
        background_color (str):
            Background color of the web page.
        user_input_color (str):
            User input background color of the web page.
        agent_response_color (str):
            Agent response background color of the web
            page.
        user_input_text_color (str):
            User input text color of the web page.
        agent_response_text_color (str):
            Agent response text color of the web page.
        box_border_radius (str):
            CSS style of text box border radius.
    """

    company: str = proto.Field(
        proto.STRING,
        number=1,
    )
    logo_uri: str = proto.Field(
        proto.STRING,
        number=2,
    )
    font: str = proto.Field(
        proto.STRING,
        number=3,
    )
    text_color: str = proto.Field(
        proto.STRING,
        number=4,
    )
    background_color: str = proto.Field(
        proto.STRING,
        number=5,
    )
    user_input_color: str = proto.Field(
        proto.STRING,
        number=6,
    )
    agent_response_color: str = proto.Field(
        proto.STRING,
        number=7,
    )
    user_input_text_color: str = proto.Field(
        proto.STRING,
        number=8,
    )
    agent_response_text_color: str = proto.Field(
        proto.STRING,
        number=9,
    )
    box_border_radius: str = proto.Field(
        proto.STRING,
        number=10,
    )


class CallCompanionUserInput(proto.Message):
    r"""User input when interacting with the Call Companion UI.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        text (str):
            Text query to inject.

            This field is a member of `oneof`_ ``user_input``.
        user_event (google.cloud.dialogflow_v2beta1.types.CallCompanionUserInput.UserEvent):
            User event occurred.

            This field is a member of `oneof`_ ``user_input``.
    """
    class UserEvent(proto.Enum):
        r"""Defines a user event at the Call Companion UI.

        Values:
            USER_EVENT_UNSPECIFIED (0):
                Default value.
            USER_EVENT_START_TYPING (1):
                Indicating that the user has started typing
                at the Call Companion UI.
        """
        USER_EVENT_UNSPECIFIED = 0
        USER_EVENT_START_TYPING = 1

    text: str = proto.Field(
        proto.STRING,
        number=1,
        oneof='user_input',
    )
    user_event: UserEvent = proto.Field(
        proto.ENUM,
        number=2,
        oneof='user_input',
        enum=UserEvent,
    )


class CallCompanionConversationEvent(proto.Message):
    r"""Event in the conversation transcript.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when event was created.
        conversation_started (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.ConversationStarted):
            Conversation started.

            This field is a member of `oneof`_ ``event_type``.
        conversation_ended (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.ConversationEnded):
            Conversation ended.

            This field is a member of `oneof`_ ``event_type``.
        message (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.TextMessage):
            Text message sent by end user or virtual
            agent.

            This field is a member of `oneof`_ ``event_type``.
        image (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.ImageMessage):
            Image message. Only virtual agent can send
            images.

            This field is a member of `oneof`_ ``event_type``.
        response_options (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.ResponseOptionsMessage):
            Response options. Virtual agent can specify
            sample responses. They will be rendered as
            buttons.

            This field is a member of `oneof`_ ``event_type``.
        input_form (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.InputFormMessage):
            Input form specification for the user
            response. Virtual agent can define user input
            format via this message.

            This field is a member of `oneof`_ ``event_type``.
        payload (google.protobuf.struct_pb2.Struct):
            Custom payload. Can be used by custom call
            companion clients.

            This field is a member of `oneof`_ ``event_type``.
        session_parameters (google.protobuf.struct_pb2.Struct):
            Latest session parameters of the virtual
            agent state.

            This field is a member of `oneof`_ ``event_type``.
        webhook_payloads (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.WebhookPayloads):
            Webhook payloads during the virtual agent
            interaction.

            This field is a member of `oneof`_ ``event_type``.
        virtual_agent_response (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.VirtualAgentResponse):
            Virtual agent response.

            This field is a member of `oneof`_ ``event_type``.
        conversation_message_id (str):
            Conversation message ID.
    """
    class SenderRole(proto.Enum):
        r"""Role of the message sender.

        Values:
            SENDER_ROLE_UNSPECIFIED (0):
                Unspecified.
            SENDER_ROLE_END_USER (1):
                End user.
            SENDER_ROLE_VIRTUAL_AGENT (2):
                Virtual agent.
        """
        SENDER_ROLE_UNSPECIFIED = 0
        SENDER_ROLE_END_USER = 1
        SENDER_ROLE_VIRTUAL_AGENT = 2

    class ConversationStarted(proto.Message):
        r"""Event representing initiation of the conversation. This is
        fired when a telephone call is answered, or a conversation is
        created via the API.

        """

    class ConversationEnded(proto.Message):
        r"""Event representing end of the conversation. This is fired
        when a telephone call is terminated, or a conversation is closed
        via the API.

        """

    class TextMessage(proto.Message):
        r"""Event representing a text message created by user or agent.

        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            text (str):
                Message text.
            sender_role (google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.SenderRole):
                Sender role.

                This field is a member of `oneof`_ ``_sender_role``.
            is_injected_text (bool):
                Whether it's from an injected text query. Only valid if the
                sender_role is SENDER_ROLE_END_USER.
        """

        text: str = proto.Field(
            proto.STRING,
            number=1,
        )
        sender_role: 'CallCompanionConversationEvent.SenderRole' = proto.Field(
            proto.ENUM,
            number=2,
            optional=True,
            enum='CallCompanionConversationEvent.SenderRole',
        )
        is_injected_text: bool = proto.Field(
            proto.BOOL,
            number=3,
        )

    class ImageMessage(proto.Message):
        r"""Image sent by agent.

        Attributes:
            image_uri (str):
                Image URI.
            alt_text (str):
                Image alternative text.
            width (int):
                Image width (px).
            height (int):
                Image height (px).
        """

        image_uri: str = proto.Field(
            proto.STRING,
            number=1,
        )
        alt_text: str = proto.Field(
            proto.STRING,
            number=2,
        )
        width: int = proto.Field(
            proto.INT64,
            number=3,
        )
        height: int = proto.Field(
            proto.INT64,
            number=4,
        )

    class ResponseOptionsMessage(proto.Message):
        r"""Agent message defining response options to the user. They
        will be rendered as buttons.

        Attributes:
            response_options (MutableSequence[google.cloud.dialogflow_v2beta1.types.CallCompanionConversationEvent.ResponseOption]):
                Response option.
        """

        response_options: MutableSequence['CallCompanionConversationEvent.ResponseOption'] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='CallCompanionConversationEvent.ResponseOption',
        )

    class ResponseOption(proto.Message):
        r"""A single option for the user to respond in the conversation.
        Will be rendered as a button.

        Attributes:
            user_input (google.cloud.dialogflow_v2beta1.types.CallCompanionUserInput):
                User response that Call Companion sends to
                the agent when user chooses this response
                option.
        """

        user_input: 'CallCompanionUserInput' = proto.Field(
            proto.MESSAGE,
            number=1,
            message='CallCompanionUserInput',
        )

    class InputFormMessage(proto.Message):
        r"""Input form specification for the user response.
        """

    class WebhookPayloads(proto.Message):
        r"""Webhook payloads during the virtual agent interaction.

        Attributes:
            payloads (MutableSequence[google.protobuf.struct_pb2.Struct]):
                Payloads received.
        """

        payloads: MutableSequence[struct_pb2.Struct] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message=struct_pb2.Struct,
        )

    class VirtualAgentResponse(proto.Message):
        r"""Virtual agent response.

        Attributes:
            text_messages (MutableSequence[str]):
                Text messages from the response
            session_parameters (google.protobuf.struct_pb2.Struct):
                Latest session parameters of the virtual
                agent state.
            webhook_payloads (MutableSequence[google.protobuf.struct_pb2.Struct]):
                Webhook payloads received.
            cx_current_page (str):
                The unique identifier of the current Dialogflow CX
                conversation page. Format:
                ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/flows/<Flow ID>/pages/<Page ID>``.
            custom_payloads (MutableSequence[google.protobuf.struct_pb2.Struct]):
                Custom payloads from the virtual agent response. Populated
                from V3
                [ResponseMessage][google.cloud.dialogflow.v2beta1.ResponseMessage.payload].
        """

        text_messages: MutableSequence[str] = proto.RepeatedField(
            proto.STRING,
            number=1,
        )
        session_parameters: struct_pb2.Struct = proto.Field(
            proto.MESSAGE,
            number=2,
            message=struct_pb2.Struct,
        )
        webhook_payloads: MutableSequence[struct_pb2.Struct] = proto.RepeatedField(
            proto.MESSAGE,
            number=3,
            message=struct_pb2.Struct,
        )
        cx_current_page: str = proto.Field(
            proto.STRING,
            number=4,
        )
        custom_payloads: MutableSequence[struct_pb2.Struct] = proto.RepeatedField(
            proto.MESSAGE,
            number=5,
            message=struct_pb2.Struct,
        )

    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=1,
        message=timestamp_pb2.Timestamp,
    )
    conversation_started: ConversationStarted = proto.Field(
        proto.MESSAGE,
        number=6,
        oneof='event_type',
        message=ConversationStarted,
    )
    conversation_ended: ConversationEnded = proto.Field(
        proto.MESSAGE,
        number=7,
        oneof='event_type',
        message=ConversationEnded,
    )
    message: TextMessage = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='event_type',
        message=TextMessage,
    )
    image: ImageMessage = proto.Field(
        proto.MESSAGE,
        number=3,
        oneof='event_type',
        message=ImageMessage,
    )
    response_options: ResponseOptionsMessage = proto.Field(
        proto.MESSAGE,
        number=4,
        oneof='event_type',
        message=ResponseOptionsMessage,
    )
    input_form: InputFormMessage = proto.Field(
        proto.MESSAGE,
        number=5,
        oneof='event_type',
        message=InputFormMessage,
    )
    payload: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=8,
        oneof='event_type',
        message=struct_pb2.Struct,
    )
    session_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=9,
        oneof='event_type',
        message=struct_pb2.Struct,
    )
    webhook_payloads: WebhookPayloads = proto.Field(
        proto.MESSAGE,
        number=10,
        oneof='event_type',
        message=WebhookPayloads,
    )
    virtual_agent_response: VirtualAgentResponse = proto.Field(
        proto.MESSAGE,
        number=11,
        oneof='event_type',
        message=VirtualAgentResponse,
    )
    conversation_message_id: str = proto.Field(
        proto.STRING,
        number=12,
    )


class GenerateStatelessSummaryRequest(proto.Message):
    r"""The request message for
    [Conversations.GenerateStatelessSummary][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSummary].

    Attributes:
        stateless_conversation (google.cloud.dialogflow_v2beta1.types.GenerateStatelessSummaryRequest.MinimalConversation):
            Required. The conversation to suggest a
            summary for.
        conversation_profile (google.cloud.dialogflow_v2beta1.types.ConversationProfile):
            Required. A ConversationProfile containing information
            required for Summary generation. Required fields:
            {language_code, security_settings} Optional fields:
            {agent_assistant_config}
        latest_message (str):
            Optional. The name of the latest conversation
            message used as context for generating a
            Summary. If empty, the latest message of the
            conversation will be used. The format is
            specific to the user and the names of the
            messages provided.
        max_context_size (int):
            Optional. Max number of messages prior to and including
            [latest_message] to use as context when compiling the
            suggestion. By default 500 and at most 1000.
    """

    class MinimalConversation(proto.Message):
        r"""The minimum amount of information required to generate a
        Summary without having a Conversation resource created.

        Attributes:
            messages (MutableSequence[google.cloud.dialogflow_v2beta1.types.Message]):
                Required. The messages that the Summary will be generated
                from. It is expected that this message content is already
                redacted and does not contain any PII. Required fields:
                {content, language_code, participant, participant_role}
                Optional fields: {send_time} If send_time is not provided,
                then the messages must be provided in chronological order.
            parent (str):
                Required. The parent resource to charge for the Summary's
                generation. Format:
                ``projects/<Project ID>/locations/<Location ID>``.
        """

        messages: MutableSequence[participant.Message] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message=participant.Message,
        )
        parent: str = proto.Field(
            proto.STRING,
            number=2,
        )

    stateless_conversation: MinimalConversation = proto.Field(
        proto.MESSAGE,
        number=1,
        message=MinimalConversation,
    )
    conversation_profile: gcd_conversation_profile.ConversationProfile = proto.Field(
        proto.MESSAGE,
        number=2,
        message=gcd_conversation_profile.ConversationProfile,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=3,
    )
    max_context_size: int = proto.Field(
        proto.INT32,
        number=4,
    )


class GenerateStatelessSummaryResponse(proto.Message):
    r"""The response message for
    [Conversations.GenerateStatelessSummary][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSummary].

    Attributes:
        summary (google.cloud.dialogflow_v2beta1.types.GenerateStatelessSummaryResponse.Summary):
            Generated summary.
        latest_message (str):
            The name of the latest conversation message
            used as context for compiling suggestion. The
            format is specific to the user and the names of
            the messages provided.
        context_size (int):
            Number of messages prior to and including
            [last_conversation_message][] used to compile the
            suggestion. It may be smaller than the
            [GenerateStatelessSummaryRequest.context_size][] field in
            the request if there weren't that many messages in the
            conversation.
    """

    class Summary(proto.Message):
        r"""Generated summary for a conversation.

        Attributes:
            text (str):
                The summary content that is concatenated into
                one string.
            text_sections (MutableMapping[str, str]):
                The summary content that is divided into
                sections. The key is the section's name and the
                value is the section's content. There is no
                specific format for the key or value.
            baseline_model_version (str):
                The baseline model version used to generate
                this summary. It is empty if a baseline model
                was not used to generate this summary.
        """

        text: str = proto.Field(
            proto.STRING,
            number=1,
        )
        text_sections: MutableMapping[str, str] = proto.MapField(
            proto.STRING,
            proto.STRING,
            number=2,
        )
        baseline_model_version: str = proto.Field(
            proto.STRING,
            number=4,
        )

    summary: Summary = proto.Field(
        proto.MESSAGE,
        number=1,
        message=Summary,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=2,
    )
    context_size: int = proto.Field(
        proto.INT32,
        number=3,
    )


class GenerateStatelessSuggestionRequest(proto.Message):
    r"""The request message for
    [Conversations.GenerateStatelessSuggestion][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSuggestion].

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        parent (str):
            Required. The parent resource to charge for the Suggestion's
            generation. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        generator (google.cloud.dialogflow_v2beta1.types.Generator):
            Uncreated generator. It should be a complete
            generator that includes all information about
            the generator.

            This field is a member of `oneof`_ ``generator_resource``.
        generator_name (str):
            The resource name of the existing created generator. Format:
            ``projects/<Project ID>/locations/<Location ID>/generators/<Generator ID>``

            This field is a member of `oneof`_ ``generator_resource``.
        context_references (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.Conversation.ContextReference]):
            Optional. A section of ingested context
            information. The key is the name of the context
            reference and the value contains the contents of
            the context reference. The key is used to
            incorporate ingested context references to
            enhance the generator.
        conversation_context (google.cloud.dialogflow_v2beta1.types.ConversationContext):
            Optional. Context of the conversation,
            including transcripts.
        trigger_events (MutableSequence[google.cloud.dialogflow_v2beta1.types.TriggerEvent]):
            Optional. A list of trigger events. Generator
            will be triggered only if it's trigger event is
            included here.
        security_settings (str):
            Optional. Name of the CX SecuritySettings which is used to
            redact generated response. If this field is empty, try to
            fetch v2 security_settings, which is a project level
            setting. If this field is empty and no v2 security_settings
            set up in this project, no redaction will be done.

            Format:
            ``projects/<Project ID>/locations/<Location ID>/securitySettings/<Security Settings ID>``.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    generator: gcd_generator.Generator = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='generator_resource',
        message=gcd_generator.Generator,
    )
    generator_name: str = proto.Field(
        proto.STRING,
        number=3,
        oneof='generator_resource',
    )
    context_references: MutableMapping[str, 'Conversation.ContextReference'] = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=4,
        message='Conversation.ContextReference',
    )
    conversation_context: gcd_generator.ConversationContext = proto.Field(
        proto.MESSAGE,
        number=5,
        message=gcd_generator.ConversationContext,
    )
    trigger_events: MutableSequence[gcd_generator.TriggerEvent] = proto.RepeatedField(
        proto.ENUM,
        number=6,
        enum=gcd_generator.TriggerEvent,
    )
    security_settings: str = proto.Field(
        proto.STRING,
        number=8,
    )


class GenerateStatelessSuggestionResponse(proto.Message):
    r"""The response message for
    [Conversations.GenerateStatelessSuggestion][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSuggestion].

    Attributes:
        generator_suggestion (google.cloud.dialogflow_v2beta1.types.GeneratorSuggestion):
            Required. Generated suggestion for a
            conversation.
    """

    generator_suggestion: gcd_generator.GeneratorSuggestion = proto.Field(
        proto.MESSAGE,
        number=1,
        message=gcd_generator.GeneratorSuggestion,
    )


class SearchKnowledgeRequest(proto.Message):
    r"""The request message for
    [Conversations.SearchKnowledge][google.cloud.dialogflow.v2beta1.Conversations.SearchKnowledge].

    Attributes:
        parent (str):
            Required. The parent resource contains the conversation
            profile Format: 'projects/' or
            ``projects/<Project ID>/locations/<Location ID>``.
        query (google.cloud.dialogflow_v2beta1.types.TextInput):
            Required. The natural language text query for
            knowledge search.
        conversation_profile (str):
            Required. The conversation profile used to configure the
            search. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversationProfiles/<Conversation Profile ID>``.
        session_id (str):
            Required. The ID of the search session. The session_id can
            be combined with Dialogflow V3 Agent ID retrieved from
            conversation profile or on its own to identify a search
            session. The search history of the same session will impact
            the search result. It's up to the API caller to choose an
            appropriate ``Session ID``. It can be a random number or
            some type of session identifiers (preferably hashed). The
            length must not exceed 36 characters.
        conversation (str):
            Optional. The conversation (between human agent and end
            user) where the search request is triggered. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        latest_message (str):
            Optional. The name of the latest conversation message when
            the request is triggered. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        query_source (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.QuerySource):
            Optional. The source of the query in the
            request.
        end_user_metadata (google.protobuf.struct_pb2.Struct):
            Optional. Information about the end-user to improve the
            relevance and accuracy of generative answers.

            This will be interpreted and used by a language model, so,
            for good results, the data should be self-descriptive, and
            in a simple structure.

            Example:

            .. code:: json

               {
                 "subscription plan": "Business Premium Plus",
                 "devices owned": [
                   {"model": "Google Pixel 7"},
                   {"model": "Google Pixel Tablet"}
                 ]
               }
        search_config (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig):
            Optional. Configuration specific to search
            queries with data stores.
        parameters (google.protobuf.struct_pb2.Struct):
            Optional. Parameters of the query. To remove a parameter
            from the session, clients should explicitly set the
            parameter value to null.

            Depending on your protocol or client library language, this
            is a map, associative array, symbol table, dictionary, or
            JSON object composed of a collection of (MapKey, MapValue)
            pairs:

            - MapKey type: string
            - MapKey value: parameter name
            - MapValue type: If parameter's entity type is a composite
              entity then use map, otherwise, depending on the parameter
              value type, it could be one of string, number, boolean,
              null, list or map.
            - MapValue value: If parameter's entity type is a composite
              entity then use map from composite entity property names
              to property values, otherwise, use parameter value.
              Deprecated: Use ``cx_parameters`` instead.
        query_params (google.cloud.dialogflow_v2beta1.types.QueryParameters):
            Optional. Query parameters for a Dialogflow
            virtual-agent query.
        cx_parameters (google.protobuf.struct_pb2.Struct):
            Optional. Additional parameters to be put
            into Dialogflow CX session parameters. To remove
            a parameter from the session, clients should
            explicitly set the parameter value to null.

            Note: this field should only be used if you are
            connecting to a Dialogflow CX agent.
        exact_search (bool):
            Optional. Whether to search the query exactly
            without query rewrite.
        cx_current_page (str):
            Optional. Used to override the previous state of a
            Dialogflow CX session. Format:
            ``projects/<Project ID>/locations/<Location ID>/agents/<Agent ID>/flows/<Flow ID>/pages/<Page ID>``.
    """
    class QuerySource(proto.Enum):
        r"""The source of the query. We use QuerySource to distinguish queries
        directly entered by agents and suggested queries from
        [Participants.SuggestKnowledgeAssist][google.cloud.dialogflow.v2beta1.Participants.SuggestKnowledgeAssist].
        If SUGGESTED_QUERY source is specified, we will treat it as a
        continuation of a SuggestKnowledgeAssist call.

        Values:
            QUERY_SOURCE_UNSPECIFIED (0):
                Unknown query source.
            AGENT_QUERY (1):
                The query is from agents.
            SUGGESTED_QUERY (2):
                The query is a suggested query from
                [Participants.SuggestKnowledgeAssist][google.cloud.dialogflow.v2beta1.Participants.SuggestKnowledgeAssist].
            END_USER_QUERY (3):
                The query is from the end user.
        """
        QUERY_SOURCE_UNSPECIFIED = 0
        AGENT_QUERY = 1
        SUGGESTED_QUERY = 2
        END_USER_QUERY = 3

    class SearchConfig(proto.Message):
        r"""Configuration specific to search queries with data stores.

        Attributes:
            boost_specs (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs]):
                Optional. Boost specifications for data
                stores.
            filter_specs (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.FilterSpecs]):
                Optional. Filter specification for data store
                queries.
                Maps from datastore name to the filter
                expression for that datastore. Do not specify
                more than one FilterSpecs for each datastore
                name. If multiple FilterSpecs are provided for
                the same datastore name, the behavior is
                undefined.
        """

        class BoostSpecs(proto.Message):
            r"""Boost specifications for data stores.

            Maps from datastore name to their boost configuration. Do not
            specify more than one BoostSpecs for each datastore name. If
            multiple BoostSpecs are provided for the same datastore name,
            the behavior is undefined.

            Attributes:
                data_stores (MutableSequence[str]):
                    Optional. Data Stores where the boosting configuration is
                    applied. The full names of the referenced data stores.
                    Formats:
                    ``projects/{project}/locations/{location}/collections/{collection}/dataStores/{data_store}``
                    ``projects/{project}/locations/{location}/dataStores/{data_store}``
                spec (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec]):
                    Optional. A list of boosting specifications.
            """

            class BoostSpec(proto.Message):
                r"""Boost specification to boost certain documents.
                A copy of google.cloud.discoveryengine.v1main.BoostSpec, field
                documentation is available at
                https://cloud.google.com/generative-ai-app-builder/docs/reference/rest/v1alpha/BoostSpec

                Attributes:
                    condition_boost_specs (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec]):
                        Optional. Condition boost specifications. If
                        a document matches multiple conditions in the
                        specifications, boost scores from these
                        specifications are all applied and combined in a
                        non-linear way. Maximum number of specifications
                        is 20.
                """

                class ConditionBoostSpec(proto.Message):
                    r"""Boost applies to documents which match a condition.

                    Attributes:
                        condition (str):
                            Optional. An expression which specifies a boost condition.
                            The syntax and supported fields are the same as a filter
                            expression. Examples:

                            - To boost documents with document ID "doc_1" or "doc_2",
                              and color "Red" or "Blue":

                              - (id: ANY("doc_1", "doc_2")) AND (color:
                                ANY("Red","Blue"))
                        boost (float):
                            Optional. Strength of the condition boost, which should be
                            in [-1, 1]. Negative boost means demotion. Default is 0.0.

                            Setting to 1.0 gives the document a big promotion. However,
                            it does not necessarily mean that the boosted document will
                            be the top result at all times, nor that other documents
                            will be excluded. Results could still be shown even when
                            none of them matches the condition. And results that are
                            significantly more relevant to the search query can still
                            trump your heavily favored but irrelevant documents.

                            Setting to -1.0 gives the document a big demotion. However,
                            results that are deeply relevant might still be shown. The
                            document will have an upstream battle to get a fairly high
                            ranking, but it is not blocked out completely.

                            Setting to 0.0 means no boost applied. The boosting
                            condition is ignored.
                        boost_control_spec (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec):
                            Optional. Complex specification for custom
                            ranking based on customer defined attribute
                            value.
                    """

                    class BoostControlSpec(proto.Message):
                        r"""Specification for custom ranking based on customer specified
                        attribute
                        value. It provides more controls for customized ranking than the
                        simple (condition, boost) combination above.

                        Attributes:
                            field_name (str):
                                Optional. The name of the field whose value
                                will be used to determine the boost amount.
                            attribute_type (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.AttributeType):
                                Optional. The attribute type to be used to determine the
                                boost amount. The attribute value can be derived from the
                                field value of the specified field_name. In the case of
                                numerical it is straightforward i.e. attribute_value =
                                numerical_field_value. In the case of freshness however,
                                attribute_value = (time.now() - datetime_field_value).
                            interpolation_type (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.InterpolationType):
                                Optional. The interpolation type to be
                                applied to connect the control points listed
                                below.
                            control_points (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.ControlPoint]):
                                Optional. The control points used to define the curve. The
                                monotonic function (defined through the interpolation_type
                                above) passes through the control points listed here.
                        """
                        class AttributeType(proto.Enum):
                            r"""The attribute(or function) for which the custom ranking is to
                            be applied.

                            Values:
                                ATTRIBUTE_TYPE_UNSPECIFIED (0):
                                    Unspecified AttributeType.
                                NUMERICAL (1):
                                    The value of the numerical field will be used to dynamically
                                    update the boost amount. In this case, the attribute_value
                                    (the x value) of the control point will be the actual value
                                    of the numerical field for which the boost_amount is
                                    specified.
                                FRESHNESS (2):
                                    For the freshness use case the attribute value will be the
                                    duration between the current time and the date in the
                                    datetime field specified. The value must be formatted as an
                                    XSD ``dayTimeDuration`` value (a restricted subset of an ISO
                                    8601 duration value). The pattern for this is:
                                    ``[nD][T[nH][nM][nS]]``. E.g. ``5D``, ``3DT12H30M``,
                                    ``T24H``.
                            """
                            ATTRIBUTE_TYPE_UNSPECIFIED = 0
                            NUMERICAL = 1
                            FRESHNESS = 2

                        class InterpolationType(proto.Enum):
                            r"""The interpolation type to be applied. Default will be linear
                            (Piecewise Linear).

                            Values:
                                INTERPOLATION_TYPE_UNSPECIFIED (0):
                                    Interpolation type is unspecified. In this
                                    case, it defaults to Linear.
                                LINEAR (1):
                                    Piecewise linear interpolation will be
                                    applied.
                            """
                            INTERPOLATION_TYPE_UNSPECIFIED = 0
                            LINEAR = 1

                        class ControlPoint(proto.Message):
                            r"""The control points used to define the curve. The curve
                            defined through these control points can only be monotonically
                            increasing or decreasing(constant values are acceptable).

                            Attributes:
                                attribute_value (str):
                                    Optional. Can be one of:

                                    1. The numerical field value.
                                    2. The duration spec for freshness: The value must be
                                       formatted as an XSD ``dayTimeDuration`` value (a
                                       restricted subset of an ISO 8601 duration value). The
                                       pattern for this is: ``[nD][T[nH][nM][nS]]``.
                                boost_amount (float):
                                    Optional. The value between -1 to 1 by which to boost the
                                    score if the attribute_value evaluates to the value
                                    specified above.
                            """

                            attribute_value: str = proto.Field(
                                proto.STRING,
                                number=1,
                            )
                            boost_amount: float = proto.Field(
                                proto.FLOAT,
                                number=2,
                            )

                        field_name: str = proto.Field(
                            proto.STRING,
                            number=1,
                        )
                        attribute_type: 'SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.AttributeType' = proto.Field(
                            proto.ENUM,
                            number=2,
                            enum='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.AttributeType',
                        )
                        interpolation_type: 'SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.InterpolationType' = proto.Field(
                            proto.ENUM,
                            number=3,
                            enum='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.InterpolationType',
                        )
                        control_points: MutableSequence['SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.ControlPoint'] = proto.RepeatedField(
                            proto.MESSAGE,
                            number=4,
                            message='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec.ControlPoint',
                        )

                    condition: str = proto.Field(
                        proto.STRING,
                        number=1,
                    )
                    boost: float = proto.Field(
                        proto.FLOAT,
                        number=2,
                    )
                    boost_control_spec: 'SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec' = proto.Field(
                        proto.MESSAGE,
                        number=4,
                        message='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec.BoostControlSpec',
                    )

                condition_boost_specs: MutableSequence['SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec'] = proto.RepeatedField(
                    proto.MESSAGE,
                    number=1,
                    message='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec.ConditionBoostSpec',
                )

            data_stores: MutableSequence[str] = proto.RepeatedField(
                proto.STRING,
                number=1,
            )
            spec: MutableSequence['SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec'] = proto.RepeatedField(
                proto.MESSAGE,
                number=2,
                message='SearchKnowledgeRequest.SearchConfig.BoostSpecs.BoostSpec',
            )

        class FilterSpecs(proto.Message):
            r"""Filter specification for data store queries.

            Attributes:
                data_stores (MutableSequence[str]):
                    Optional. The data store where the filter
                    configuration is applied. Full resource name of
                    data store, such as
                    projects/{project}/locations/{location}/collections/{collectionId}/
                    dataStores/{dataStoreId}.
                filter (str):
                    Optional. The filter expression to be
                    applied. Expression syntax is documented at
                    https://cloud.google.com/generative-ai-app-builder/docs/filter-search-metadata#filter-expression-syntax
            """

            data_stores: MutableSequence[str] = proto.RepeatedField(
                proto.STRING,
                number=1,
            )
            filter: str = proto.Field(
                proto.STRING,
                number=2,
            )

        boost_specs: MutableSequence['SearchKnowledgeRequest.SearchConfig.BoostSpecs'] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='SearchKnowledgeRequest.SearchConfig.BoostSpecs',
        )
        filter_specs: MutableSequence['SearchKnowledgeRequest.SearchConfig.FilterSpecs'] = proto.RepeatedField(
            proto.MESSAGE,
            number=2,
            message='SearchKnowledgeRequest.SearchConfig.FilterSpecs',
        )

    parent: str = proto.Field(
        proto.STRING,
        number=6,
    )
    query: session.TextInput = proto.Field(
        proto.MESSAGE,
        number=1,
        message=session.TextInput,
    )
    conversation_profile: str = proto.Field(
        proto.STRING,
        number=2,
    )
    session_id: str = proto.Field(
        proto.STRING,
        number=3,
    )
    conversation: str = proto.Field(
        proto.STRING,
        number=4,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=5,
    )
    query_source: QuerySource = proto.Field(
        proto.ENUM,
        number=7,
        enum=QuerySource,
    )
    end_user_metadata: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=9,
        message=struct_pb2.Struct,
    )
    search_config: SearchConfig = proto.Field(
        proto.MESSAGE,
        number=11,
        message=SearchConfig,
    )
    parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=10,
        message=struct_pb2.Struct,
    )
    query_params: session.QueryParameters = proto.Field(
        proto.MESSAGE,
        number=12,
        message=session.QueryParameters,
    )
    cx_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=13,
        message=struct_pb2.Struct,
    )
    exact_search: bool = proto.Field(
        proto.BOOL,
        number=14,
    )
    cx_current_page: str = proto.Field(
        proto.STRING,
        number=15,
    )


class SearchKnowledgeDebugInfo(proto.Message):
    r"""Debug information related to SearchKnowledge feature.

    Attributes:
        datastore_response_reason (google.cloud.dialogflow_v2beta1.types.DatastoreResponseReason):
            Response reason from datastore which
            indicates data serving status or answer quality
            degradation.
        search_knowledge_behavior (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeDebugInfo.SearchKnowledgeBehavior):
            Configured behaviors for SearchKnowledge.
        ingested_context_reference_debug_info (google.cloud.dialogflow_v2beta1.types.IngestedContextReferenceDebugInfo):
            Information about parameters ingested for
            search knowledge.
        service_latency (google.cloud.dialogflow_v2beta1.types.ServiceLatency):
            The latency of the service.
    """

    class SearchKnowledgeBehavior(proto.Message):
        r"""Configured behaviors for SearchKnowledge.

        Attributes:
            answer_generation_rewriter_on (bool):
                Whether data store agent rewriter was turned
                on for the request.
            end_user_metadata_included (bool):
                Whether end_user_metadata is included in the data store
                agent call.
            third_party_connector_allowed (bool):
                This field indicates whether third party
                connectors are enabled for the project. Note
                that this field only indicates if the project is
                allowlisted for connectors.
        """

        answer_generation_rewriter_on: bool = proto.Field(
            proto.BOOL,
            number=1,
        )
        end_user_metadata_included: bool = proto.Field(
            proto.BOOL,
            number=2,
        )
        third_party_connector_allowed: bool = proto.Field(
            proto.BOOL,
            number=4,
        )

    datastore_response_reason: participant.DatastoreResponseReason = proto.Field(
        proto.ENUM,
        number=1,
        enum=participant.DatastoreResponseReason,
    )
    search_knowledge_behavior: SearchKnowledgeBehavior = proto.Field(
        proto.MESSAGE,
        number=2,
        message=SearchKnowledgeBehavior,
    )
    ingested_context_reference_debug_info: participant.IngestedContextReferenceDebugInfo = proto.Field(
        proto.MESSAGE,
        number=3,
        message=participant.IngestedContextReferenceDebugInfo,
    )
    service_latency: participant.ServiceLatency = proto.Field(
        proto.MESSAGE,
        number=4,
        message=participant.ServiceLatency,
    )


class SearchKnowledgeResponse(proto.Message):
    r"""The response message for
    [Conversations.SearchKnowledge][google.cloud.dialogflow.v2beta1.Conversations.SearchKnowledge].

    Attributes:
        answers (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeAnswer]):
            Most relevant snippets extracted from
            articles in the given knowledge base, ordered by
            confidence.
        rewritten_query (str):
            The rewritten query used to search knowledge.
        search_knowledge_debug_info (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeDebugInfo):
            Debug info for SearchKnowledge.
    """

    answers: MutableSequence['SearchKnowledgeAnswer'] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='SearchKnowledgeAnswer',
    )
    rewritten_query: str = proto.Field(
        proto.STRING,
        number=3,
    )
    search_knowledge_debug_info: 'SearchKnowledgeDebugInfo' = proto.Field(
        proto.MESSAGE,
        number=4,
        message='SearchKnowledgeDebugInfo',
    )


class SearchKnowledgeAnswer(proto.Message):
    r"""Represents a SearchKnowledge answer.

    Attributes:
        answer (str):
            The piece of text from the knowledge base
            documents that answers the search query
        answer_type (google.cloud.dialogflow_v2beta1.types.SearchKnowledgeAnswer.AnswerType):
            The type of the answer.
        answer_sources (MutableSequence[google.cloud.dialogflow_v2beta1.types.SearchKnowledgeAnswer.AnswerSource]):
            All sources used to generate the answer.
        answer_record (str):
            The name of the answer record. Format:
            ``projects/<Project ID>/locations/<location ID>/answer Records/<Answer Record ID>``
        automated_agent_reply (google.cloud.dialogflow_v2beta1.types.AutomatedAgentReply):
            Response generated from an automated agent.
    """
    class AnswerType(proto.Enum):
        r"""The type of the answer.

        Values:
            ANSWER_TYPE_UNSPECIFIED (0):
                The answer has a unspecified type.
            FAQ (1):
                The answer is from FAQ documents.
            GENERATIVE (2):
                The answer is from generative model.
            INTENT (3):
                The answer is from intent matching.
            PLAYBOOK (4):
                The answer is from Playbook.
            EVENT (5):
                The answer is from event.
        """
        ANSWER_TYPE_UNSPECIFIED = 0
        FAQ = 1
        GENERATIVE = 2
        INTENT = 3
        PLAYBOOK = 4
        EVENT = 5

    class AnswerSource(proto.Message):
        r"""The sources of the answers.

        Attributes:
            title (str):
                The title of the article.
            uri (str):
                The URI of the article.
            snippet (str):
                The relevant snippet of the article.
            document (str):
                The document from which the snippet was extracted. Format:
                ``projects/<Project ID>/knowledgeBases/<Knowledge Base ID>/documents/<Document ID>``
            metadata (google.protobuf.struct_pb2.Struct):
                Metadata associated with the article.
        """

        title: str = proto.Field(
            proto.STRING,
            number=1,
        )
        uri: str = proto.Field(
            proto.STRING,
            number=2,
        )
        snippet: str = proto.Field(
            proto.STRING,
            number=3,
        )
        document: str = proto.Field(
            proto.STRING,
            number=4,
        )
        metadata: struct_pb2.Struct = proto.Field(
            proto.MESSAGE,
            number=5,
            message=struct_pb2.Struct,
        )

    answer: str = proto.Field(
        proto.STRING,
        number=1,
    )
    answer_type: AnswerType = proto.Field(
        proto.ENUM,
        number=2,
        enum=AnswerType,
    )
    answer_sources: MutableSequence[AnswerSource] = proto.RepeatedField(
        proto.MESSAGE,
        number=3,
        message=AnswerSource,
    )
    answer_record: str = proto.Field(
        proto.STRING,
        number=5,
    )
    automated_agent_reply: participant.AutomatedAgentReply = proto.Field(
        proto.MESSAGE,
        number=6,
        message=participant.AutomatedAgentReply,
    )


class GenerateSuggestionsRequest(proto.Message):
    r"""The request message for
    [Conversations.GenerateSuggestions][google.cloud.dialogflow.v2beta1.Conversations.GenerateSuggestions].

    Attributes:
        conversation (str):
            Required. The conversation for which the suggestions are
            generated. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.

            The conversation must be created with a conversation profile
            which has generators configured in it to be able to get
            suggestions.
        latest_message (str):
            Optional. The name of the latest conversation message for
            which the request is triggered. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>/messages/<Message ID>``.
        trigger_events (MutableSequence[google.cloud.dialogflow_v2beta1.types.TriggerEvent]):
            Optional. A list of trigger events. Only generators
            configured in the conversation_profile whose trigger_event
            is listed here will be triggered.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    latest_message: str = proto.Field(
        proto.STRING,
        number=2,
    )
    trigger_events: MutableSequence[gcd_generator.TriggerEvent] = proto.RepeatedField(
        proto.ENUM,
        number=3,
        enum=gcd_generator.TriggerEvent,
    )


class InitiatePhoneCallRequest(proto.Message):
    r"""The request message for
    [Conversations.InitiatePhoneCall][google.cloud.dialogflow.v2beta1.Conversations.InitiatePhoneCall].

    Attributes:
        conversation (str):
            Required. The conversation with which the phone call is
            made. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        callee (str):
            Required. The phone number of the callee in
            E.164 format.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    callee: str = proto.Field(
        proto.STRING,
        number=2,
    )


class InitiatePhoneCallResponse(proto.Message):
    r"""The response message for
    [Conversations.InitiatePhoneCall][google.cloud.dialogflow.v2beta1.Conversations.InitiatePhoneCall].

    """


class InjectSupervisorInputRequest(proto.Message):
    r"""The request message for
    [Conversations.InjectSupervisorInput][google.cloud.dialogflow.v2beta1.Conversations.InjectSupervisorInput].

    Attributes:
        conversation (str):
            Required. The conversation to inject the input to. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.
        call_transfer_reason (str):
            Optional. The reason given by the supervisor
            for transferring the conversation to a human
            agent.
    """

    conversation: str = proto.Field(
        proto.STRING,
        number=1,
    )
    call_transfer_reason: str = proto.Field(
        proto.STRING,
        number=2,
    )


class InjectSupervisorInputResponse(proto.Message):
    r"""The response message for
    [Conversations.InjectSupervisorInput][google.cloud.dialogflow.v2beta1.Conversations.InjectSupervisorInput].

    """


class GetInteractionMonitoringAlertRequest(proto.Message):
    r"""The request message for
    [Conversations.GetInteractionMonitoringAlert][google.cloud.dialogflow.v2beta1.Conversations.GetInteractionMonitoringAlert].

    Attributes:
        name (str):
            Required. The unique identifier of the alert to get all
            information for. Format:
            ``projects/<Project ID>/locations/<Location ID>/interactionMonitoringAlerts/<Alert ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListInteractionMonitoringAlertsRequest(proto.Message):
    r"""The request message for
    [Conversations.ListInteractionMonitoringAlerts][google.cloud.dialogflow.v2beta1.Conversations.ListInteractionMonitoringAlerts].

    Attributes:
        parent (str):
            Required. The parent resource name to list the alerts for.
            Format: ``projects/<Project ID>/locations/<Location ID>``
        page_size (int):
            Optional. Maximum number of alerts to return
            in a single page. Default to 10.
        page_token (str):
            Optional. The page_token value returned from a previous list
            request.
        filter (str):
            Optional. The filter expression used to filter alerts
            returned by the list method. The expression has the
            following syntax:

            [AND ] ...

            The following fields and operators are supported:

            - alert_state with equals(=) operator
            - create_time with greater-than-equal-to(>=) and
              less-than-equal-to(<=) operators

              - This is the create time of the alert and must follow
                RFC-3339 format as mentioned in
                https://google.aip.dev/160#comparison-operators.
              - Must use double quotations for the time value, Example:
                "create_time >="2025-07-13T01:00:00-00:00""
              - RFC-3339 uses the UTC timezone by default, and supports
                UTC offsets to mentioned in the time string to specify
                other timezones. More details can be found in
                https://datatracker.ietf.org/doc/html/rfc3339.

            - context_id with equals(=) operator

              - This is the resource name of the conversation or
                session.
              - Corresponds to one of the following context_id cases in
                ``google.cloud.dialogflow.v2beta1.InteractionMonitoringAlert.context_id``

            Examples:

            - "alert_state=CREATED" matches alerts with CREATED state.
            - "alert_state=ACKNOWLEDGED AND
              context_id=projects/project-id/locations/global/conversations/conv-id"
              matches all acknowledged alerts for the given
              conversation.
            - "create_time >= "2025-07-13T01:00:00-00:00" AND
              create_time <= "2025-07-13T02:00:00-00:00"" matches all
              alerts created between 13th July 2025 1 AM to 2 AM UTC.
              For more information about filtering, see `API
              Filtering <https://aip.dev/160>`__.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )
    filter: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListInteractionMonitoringAlertsResponse(proto.Message):
    r"""The response message for
    [Conversations.ListInteractionMonitoringAlerts][google.cloud.dialogflow.v2beta1.Conversations.ListInteractionMonitoringAlerts].

    Attributes:
        interaction_monitoring_alerts (MutableSequence[google.cloud.dialogflow_v2beta1.types.InteractionMonitoringAlert]):
            List of alerts retrieved ordered by ``create_time`` in
            descending order.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    interaction_monitoring_alerts: MutableSequence[interaction_monitoring.InteractionMonitoringAlert] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=interaction_monitoring.InteractionMonitoringAlert,
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class AckInteractionMonitoringAlertRequest(proto.Message):
    r"""The request message for
    [Conversations.AckInteractionMonitoringAlert][google.cloud.dialogflow.v2beta1.Conversations.AckInteractionMonitoringAlert].

    Attributes:
        name (str):
            Required. The unique identifier of the alert to ack. Format:
            ``projects/<Project ID>/locations/<Location ID>/interactionMonitoringAlerts/<Alert ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListInteractionMonitoringMetricsRequest(proto.Message):
    r"""The request message for
    [Conversations.ListInteractionMonitoringMetrics][google.cloud.dialogflow.v2beta1.Conversations.ListInteractionMonitoringMetrics].


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        parent (str):
            Required. The parent resource name to list the metrics for.
            Format: ``projects/<Project ID>/locations/<Location ID>``
        conversation (str):
            Optional. The unique identifier of the conversation. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversations/<Conversation ID>``.

            This field is a member of `oneof`_ ``context_id``.
        filter (str):
            Optional. The filter expression used to filter metrics
            returned by the list method. The expression has the
            following syntax:

            [AND ] ...

            The following fields and operators are supported:

            - metric_type with equals(=) operator
            - create_time with greater-than-equal-to(>=) and
              less-than-equal-to(<=) operators

              - This is the create time of the metric value and must
                follow RFC-3339 format as mentioned in
                https://google.aip.dev/160#comparison-operators.
              - Must use double quotations for the time value, Example:
                "create_time >="2025-07-13T01:00:00-00:00""
              - RFC-3339 uses the UTC timezone by default, and supports
                UTC offsets to mentioned in the time string to specify
                other timezones. More details can be found in
                https://datatracker.ietf.org/doc/html/rfc3339.

            Examples:

            - "metric_type=SENTIMENT_SCORE" matches metrics with type
              SENTIMENT_SCORE.
            - "create_time >= "2025-07-13T01:00:00-00:00" AND
              create_time <= "2025-07-13T02:00:00-00:00"" matches all
              metric values created/computed between 13th July 2025 1 AM
              to 2 AM UTC. For more information about filtering, see
              `API Filtering <https://aip.dev/160>`__.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation: str = proto.Field(
        proto.STRING,
        number=2,
        oneof='context_id',
    )
    filter: str = proto.Field(
        proto.STRING,
        number=8,
    )


class ListInteractionMonitoringMetricsResponse(proto.Message):
    r"""The response message for
    [Conversations.ListInteractionMonitoringMetrics][google.cloud.dialogflow.v2beta1.Conversations.ListInteractionMonitoringMetrics].

    Attributes:
        interaction_monitoring_metrics (MutableSequence[google.cloud.dialogflow_v2beta1.types.MetricValues]):
            List of all metrics retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    interaction_monitoring_metrics: MutableSequence[interaction_monitoring.MetricValues] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=interaction_monitoring.MetricValues,
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
