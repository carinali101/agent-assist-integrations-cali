# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'ConversationModel',
        'InputDataset',
        'ArticleSuggestionModelMetadata',
        'AssociateAllowlistInfo',
        'SmartReplyModelMetadata',
        'SmartComposeModelMetadata',
        'SummarizationModelMetadata',
        'KeyMomentModelMetadata',
        'CreateConversationModelRequest',
        'GetConversationModelRequest',
        'ListConversationModelsRequest',
        'ListConversationModelsResponse',
        'DeleteConversationModelRequest',
        'CopyConversationModelRequest',
        'DeployConversationModelRequest',
        'UndeployConversationModelRequest',
        'CopyConversationModelOperationMetadata',
    },
)


class ConversationModel(proto.Message):
    r"""Represents a conversation model.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            ConversationModel resource name. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model ID>``
        display_name (str):
            Required. The display name of the model. At
            most 64 bytes long.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Creation time of this model.
        datasets (MutableSequence[google.cloud.dialogflow_v2beta1.types.InputDataset]):
            Required. Datasets used to create model.
        state (google.cloud.dialogflow_v2beta1.types.ConversationModel.State):
            Output only. State of the model. A model can
            only serve prediction requests after it gets
            deployed.
        language_code (str):
            Language code for the conversation model. If not specified,
            the language is en-US. Language at ConversationModel should
            be set for all non en-us languages. This should be a
            `BCP-47 <https://www.rfc-editor.org/rfc/bcp/bcp47.txt>`__
            language tag. Example: "en-US".
        article_suggestion_model_metadata (google.cloud.dialogflow_v2beta1.types.ArticleSuggestionModelMetadata):
            Metadata for article suggestion models.

            This field is a member of `oneof`_ ``model_metadata``.
        smart_reply_model_metadata (google.cloud.dialogflow_v2beta1.types.SmartReplyModelMetadata):
            Metadata for smart reply models.

            This field is a member of `oneof`_ ``model_metadata``.
        smart_compose_model_metadata (google.cloud.dialogflow_v2beta1.types.SmartComposeModelMetadata):
            Metadata for smart compose models.

            This field is a member of `oneof`_ ``model_metadata``.
        summarization_model_metadata (google.cloud.dialogflow_v2beta1.types.SummarizationModelMetadata):
            Metadata for summarization models.

            This field is a member of `oneof`_ ``model_metadata``.
        key_moment_model_metadata (google.cloud.dialogflow_v2beta1.types.KeyMomentModelMetadata):
            Metadata for key moment models.

            This field is a member of `oneof`_ ``model_metadata``.
        satisfies_pzs (bool):
            Output only. A read only boolean field
            reflecting Zone Separation status of the model.

            This field is a member of `oneof`_ ``_satisfies_pzs``.
        satisfies_pzi (bool):
            Output only. A read only boolean field
            reflecting Zone Isolation status of the model.

            This field is a member of `oneof`_ ``_satisfies_pzi``.
    """
    class State(proto.Enum):
        r"""State of the model.

        Values:
            STATE_UNSPECIFIED (0):
                Should not be used, an un-set enum has this
                value by default.
            CREATING (1):
                Model being created.
            UNDEPLOYED (2):
                Model is not deployed but ready to deploy.
            DEPLOYING (3):
                Model is deploying.
            DEPLOYED (4):
                Model is deployed and ready to use.
            UNDEPLOYING (5):
                Model is undeploying.
            DELETING (6):
                Model is deleting.
            FAILED (7):
                Model is in error state. Not ready to deploy
                and use.
            PENDING (8):
                Model is being created but the training has
                not started, The model may remain in this state
                until there is enough capacity to start
                training.
        """
        STATE_UNSPECIFIED = 0
        CREATING = 1
        UNDEPLOYED = 2
        DEPLOYING = 3
        DEPLOYED = 4
        UNDEPLOYING = 5
        DELETING = 6
        FAILED = 7
        PENDING = 8

    class ModelType(proto.Enum):
        r"""Model type.

        Values:
            MODEL_TYPE_UNSPECIFIED (0):
                ModelType unspecified.
            ARTICLE_SUGGESTION_GBT_MODEL (1):
                ModelType article suggestion gbt.
            SMART_REPLY_DUAL_ENCODER_MODEL (2):
                ModelType smart reply dual encoder model.
            SMART_REPLY_BERT_MODEL (6):
                ModelType smart reply bert model.
            ARTICLE_SUGGESTION_DUAL_ENCODER_MODEL (3):
                ModelType article suggestion dual encoder
                model.
            SMART_COMPOSE_DUAL_ENCODER_MODEL (4):
                ModelType smart compose dual encoder model.
            ISSUE_SMART_COMPOSE_DUAL_ENCODER_MODEL (7):
                ModelType issue smart compose dual encoder
                model.
            ARTICLE_SUGGESTION_UNSUPERVISED_MODEL (5):
                ModelType article suggestion unsupervised
                model.
            SMART_REPLY_GENERATIVE_MODEL (9):
                ModelType smart reply generative model.
            SUMMARIZATION_MODEL (10):
                ModelType summarization model.
            SUMMARIZATION_V2_MODEL (17):
                ModelType summarization V2 model with
                improved performance.
        """
        MODEL_TYPE_UNSPECIFIED = 0
        ARTICLE_SUGGESTION_GBT_MODEL = 1
        SMART_REPLY_DUAL_ENCODER_MODEL = 2
        SMART_REPLY_BERT_MODEL = 6
        ARTICLE_SUGGESTION_DUAL_ENCODER_MODEL = 3
        SMART_COMPOSE_DUAL_ENCODER_MODEL = 4
        ISSUE_SMART_COMPOSE_DUAL_ENCODER_MODEL = 7
        ARTICLE_SUGGESTION_UNSUPERVISED_MODEL = 5
        SMART_REPLY_GENERATIVE_MODEL = 9
        SUMMARIZATION_MODEL = 10
        SUMMARIZATION_V2_MODEL = 17

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )
    datasets: MutableSequence['InputDataset'] = proto.RepeatedField(
        proto.MESSAGE,
        number=4,
        message='InputDataset',
    )
    state: State = proto.Field(
        proto.ENUM,
        number=7,
        enum=State,
    )
    language_code: str = proto.Field(
        proto.STRING,
        number=19,
    )
    article_suggestion_model_metadata: 'ArticleSuggestionModelMetadata' = proto.Field(
        proto.MESSAGE,
        number=8,
        oneof='model_metadata',
        message='ArticleSuggestionModelMetadata',
    )
    smart_reply_model_metadata: 'SmartReplyModelMetadata' = proto.Field(
        proto.MESSAGE,
        number=9,
        oneof='model_metadata',
        message='SmartReplyModelMetadata',
    )
    smart_compose_model_metadata: 'SmartComposeModelMetadata' = proto.Field(
        proto.MESSAGE,
        number=14,
        oneof='model_metadata',
        message='SmartComposeModelMetadata',
    )
    summarization_model_metadata: 'SummarizationModelMetadata' = proto.Field(
        proto.MESSAGE,
        number=15,
        oneof='model_metadata',
        message='SummarizationModelMetadata',
    )
    key_moment_model_metadata: 'KeyMomentModelMetadata' = proto.Field(
        proto.MESSAGE,
        number=16,
        oneof='model_metadata',
        message='KeyMomentModelMetadata',
    )
    satisfies_pzs: bool = proto.Field(
        proto.BOOL,
        number=25,
        optional=True,
    )
    satisfies_pzi: bool = proto.Field(
        proto.BOOL,
        number=26,
        optional=True,
    )


class InputDataset(proto.Message):
    r"""InputDataset used to create model or do evaluation.
    NextID:5

    Attributes:
        dataset (str):
            Required. ConversationDataset resource name. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
            or
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>/annotatedConversationDatasets/<Annotated Conversation Dataset ID>``
    """

    dataset: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ArticleSuggestionModelMetadata(proto.Message):
    r"""Metadata for article suggestion models.

    Attributes:
        model_type (str):
            Optional. DEPRECATED: Prefer defining and accessing the
            model type using training_model_type. Type of the article
            suggestion model. The available values are:

            - ``article-suggestion-gbt-1`` - (default) Article
              Suggestion Gbt model.
            - ``article-suggestion-unsupervised-1``

              - Article Suggestion Unsupervised Model.
        training_model_type (google.cloud.dialogflow_v2beta1.types.ConversationModel.ModelType):
            Optional. Type of the article suggestion model. If not
            provided, model_type is used.
    """

    model_type: str = proto.Field(
        proto.STRING,
        number=1,
    )
    training_model_type: 'ConversationModel.ModelType' = proto.Field(
        proto.ENUM,
        number=3,
        enum='ConversationModel.ModelType',
    )


class AssociateAllowlistInfo(proto.Message):
    r"""Information of the associated allowlist for the conversation
    model.

    Attributes:
        document (str):
            The resource name of the associated
            allowlist. Format: 'projects/<Project
            ID>/knowledgeBases/<KnowledgeBase
            ID>/documents/<Document ID>'
        source_type (google.cloud.dialogflow_v2beta1.types.AssociateAllowlistInfo.SourceType):
            Source of the associated allowlist document.
    """
    class SourceType(proto.Enum):
        r"""Source of the allowlist.

        Values:
            SOURCE_TYPE_UNSPECIFIED (0):
                Should not be used, default value when source
                unspecified.
            AUTOMATIC (1):
                The allowlist will be automatically generated
                along with the conversation model during
                training.
            PRETRAINED (2):
                The allowlist is previously generated, and
                explicitly associated with the conversation
                model.
        """
        SOURCE_TYPE_UNSPECIFIED = 0
        AUTOMATIC = 1
        PRETRAINED = 2

    document: str = proto.Field(
        proto.STRING,
        number=1,
    )
    source_type: SourceType = proto.Field(
        proto.ENUM,
        number=2,
        enum=SourceType,
    )


class SmartReplyModelMetadata(proto.Message):
    r"""Metadata for smart reply models.

    Attributes:
        model_type (str):
            DEPRECATED: Prefer defining and accessing the model type
            using training_model_type. Type of the smart reply model.
            The available values are:

            - ``smart-reply-dual-encoder-model-1``

              - (default) Smart Reply Dual Encoder Model.
        associated_allowlist_info (google.cloud.dialogflow_v2beta1.types.AssociateAllowlistInfo):
            Optional. The information of the allowlist
            associated with the conversation model. This
            field is internal and only to be accessed by the
            web console.
        training_model_type (google.cloud.dialogflow_v2beta1.types.ConversationModel.ModelType):
            Optional. Type of the smart reply model. If not provided,
            model_type is used.
    """

    model_type: str = proto.Field(
        proto.STRING,
        number=1,
    )
    associated_allowlist_info: 'AssociateAllowlistInfo' = proto.Field(
        proto.MESSAGE,
        number=5,
        message='AssociateAllowlistInfo',
    )
    training_model_type: 'ConversationModel.ModelType' = proto.Field(
        proto.ENUM,
        number=6,
        enum='ConversationModel.ModelType',
    )


class SmartComposeModelMetadata(proto.Message):
    r"""Metadata for smart compose models.

    Attributes:
        model_type (str):
            Optional. DEPRECATED: Prefer defining and accessing the
            model type using training_model_type. Type of the smart
            compose model. The available values are:

            - ``smart-compose-dual-encoder-model-1``

              - (default) Smart Compose Dual Encoder Model.
        associated_allowlist_info (google.cloud.dialogflow_v2beta1.types.AssociateAllowlistInfo):
            Optional. The information of the allowlist
            associated with the conversation model. This
            field is internal and only to be accessed by the
            web console.
        training_model_type (google.cloud.dialogflow_v2beta1.types.ConversationModel.ModelType):
            Optional. Type of the smart compose model. If not provided,
            model_type is used.
    """

    model_type: str = proto.Field(
        proto.STRING,
        number=1,
    )
    associated_allowlist_info: 'AssociateAllowlistInfo' = proto.Field(
        proto.MESSAGE,
        number=6,
        message='AssociateAllowlistInfo',
    )
    training_model_type: 'ConversationModel.ModelType' = proto.Field(
        proto.ENUM,
        number=7,
        enum='ConversationModel.ModelType',
    )


class SummarizationModelMetadata(proto.Message):
    r"""Metadata for summarization models.

    Attributes:
        model_type (str):
            Optional. DEPRECATED: Prefer defining and accessing the
            model type using training_model_type. Type of the
            summarization model. The available values are:

            - ``summarization-model-1`` - (default)
        training_model_type (google.cloud.dialogflow_v2beta1.types.ConversationModel.ModelType):
            Optional. Type of the summarizationsummarization model. If
            not provided, model_type is used.
    """

    model_type: str = proto.Field(
        proto.STRING,
        number=1,
    )
    training_model_type: 'ConversationModel.ModelType' = proto.Field(
        proto.ENUM,
        number=4,
        enum='ConversationModel.ModelType',
    )


class KeyMomentModelMetadata(proto.Message):
    r"""Metadata for key moment models.

    Attributes:
        model_type (str):
            Type of the smart reply model. The available values are:

            - ``key-moment-model-1`` - (default)
    """

    model_type: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CreateConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.CreateConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.CreateConversationModel]

    Attributes:
        parent (str):
            The project to create conversation model for. Format:
            ``projects/<Project ID>``
        conversation_model (google.cloud.dialogflow_v2beta1.types.ConversationModel):
            Required. The conversation model to create.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation_model: 'ConversationModel' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationModel',
    )


class GetConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.GetConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.GetConversationModel]

    Attributes:
        name (str):
            Required. The conversation model to retrieve. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationModelsRequest(proto.Message):
    r"""The request message for
    [ConversationModels.ListConversationModels][google.cloud.dialogflow.v2beta1.ConversationModels.ListConversationModels]

    Attributes:
        parent (str):
            Required. The project to list all conversation models for.
            Format: ``projects/<Project ID>``
        page_size (int):
            Optional. Maximum number of conversation
            models to return in a single page. By default
            100 and at most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListConversationModelsResponse(proto.Message):
    r"""The response message for
    [ConversationModels.ListConversationModels][google.cloud.dialogflow.v2beta1.ConversationModels.ListConversationModels]

    Attributes:
        conversation_models (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationModel]):
            The list of models to return.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversation_models: MutableSequence['ConversationModel'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationModel',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.DeleteConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.DeleteConversationModel]

    Attributes:
        name (str):
            Required. The conversation model to delete. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CopyConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.CopyConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.CopyConversationModel]

    Attributes:
        parent (str):
            Required. The location to create conversation model for.
            Format: ``projects/<Project ID>/locations/<Location ID>``
        source_conversation_model (str):
            Required. The conversation model to copy. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversationModels/<Conversation Model ID>``
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    source_conversation_model: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeployConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.DeployConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.DeployConversationModel]

    Attributes:
        name (str):
            Required. The conversation model to deploy. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UndeployConversationModelRequest(proto.Message):
    r"""The request message for
    [ConversationModels.UndeployConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.UndeployConversationModel]

    Attributes:
        name (str):
            Required. The conversation model to undeploy. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CopyConversationModelOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationModels.CopyConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.CopyConversationModel]
    operation.

    Attributes:
        conversation_model (str):
            The resource name of the conversation model. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversationModels/<Conversation Model Id>``
    """

    conversation_model: str = proto.Field(
        proto.STRING,
        number=1,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
