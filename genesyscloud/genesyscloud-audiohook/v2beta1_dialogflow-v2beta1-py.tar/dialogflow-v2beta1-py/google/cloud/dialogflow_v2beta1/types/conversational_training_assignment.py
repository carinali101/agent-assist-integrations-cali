# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateConversationalTrainingAssignmentRequest',
        'GetConversationalTrainingAssignmentRequest',
        'ListConversationalTrainingAssignmentsRequest',
        'ListConversationalTrainingAssignmentsResponse',
        'DeleteConversationalTrainingAssignmentRequest',
        'UpdateConversationalTrainingAssignmentRequest',
        'FinalizeSimulationAttemptRequest',
        'CompleteConversationalTrainingAssignmentRequest',
        'BatchCreateConversationalTrainingAssignmentsRequest',
        'BatchCreateConversationalTrainingAssignmentsResponse',
        'BatchDeleteConversationalTrainingAssignmentsRequest',
        'BatchUpdateConversationalTrainingAssignmentsRequest',
        'BatchUpdateConversationalTrainingAssignmentsResponse',
        'ConversationalTrainingAssignment',
    },
)


class CreateConversationalTrainingAssignmentRequest(proto.Message):
    r"""Request message of CreateConversationalTrainingAssignment.

    Attributes:
        parent (str):
            Required. The member to create conversational training
            assignment for. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``.
        conversational_training_assignment (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment):
            Required. The conversational training
            assignment to create.
        conversational_training_assignment_id (str):
            Optional. The ID to use for the conversational training
            assignment, which will become the final component of the
            conversational training assignment's resource name.

            The conversational training assignment ID must be compliant
            with the regression fomula ``[a-zA-Z][a-zA-Z0-9_-]*`` with
            the characters length in range of [3,64]. If the field is
            not provide, an Id will be auto-generated. If the field is
            provided, the caller is responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversational_training_assignment: 'ConversationalTrainingAssignment' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationalTrainingAssignment',
    )
    conversational_training_assignment_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class GetConversationalTrainingAssignmentRequest(proto.Message):
    r"""Request message of GetConversationalTrainingAssignment.

    Attributes:
        name (str):
            Required. The conversational training assignment resource
            name to retrieve. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationalTrainingAssignmentsRequest(proto.Message):
    r"""Request message of ListConversationalTrainingAssignments.

    Attributes:
        parent (str):
            Required. The member to list
            conversationalTrainingAssignments for. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``
        page_size (int):
            Optional. Maximum number of conversational
            training assignments to return in a single page.
            Default to 10.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListConversationalTrainingAssignmentsResponse(proto.Message):
    r"""Response of ListConversationalTrainingAssignments.

    Attributes:
        conversational_training_assignments (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment]):
            List of conversationalTrainingAssignments
            retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversational_training_assignments: MutableSequence['ConversationalTrainingAssignment'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingAssignment',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationalTrainingAssignmentRequest(proto.Message):
    r"""Request of DeleteConversationalTrainingAssignment.

    Attributes:
        name (str):
            Required. The conversational training assignment resource
            name to delete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateConversationalTrainingAssignmentRequest(proto.Message):
    r"""Request of UpdateConversationalTrainingAssignment. Should
    only be used by managers to prevent directly setting assignment
    progress.

    Attributes:
        conversational_training_assignment (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment):
            Required. The conversational training
            assignment to update. The name field of
            conversational training assignment is to
            identify the conversational training assignment
            to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The list of fields to update.
    """

    conversational_training_assignment: 'ConversationalTrainingAssignment' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingAssignment',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class FinalizeSimulationAttemptRequest(proto.Message):
    r"""Request message of FinalizeSimulationAttempt.

    Attributes:
        name (str):
            Required. The conversational training assignment to complete
            the simulation for. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
        conversation (str):
            Required. The conversation that the simulation was run on.
            Will be used to fetch the score of the simulation. Requires
            that the conversation has been completed and was a simulated
            conversation for the applicable module component. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversations/<ConversationID>``
        module_component_uuid (str):
            Required. The UUID of the module component to
            complete the simulation for.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation: str = proto.Field(
        proto.STRING,
        number=2,
    )
    module_component_uuid: str = proto.Field(
        proto.STRING,
        number=3,
    )


class CompleteConversationalTrainingAssignmentRequest(proto.Message):
    r"""Request message of CompleteConversationalTrainingAssignment.

    Attributes:
        name (str):
            Required. The conversational training assignment to
            complete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class BatchCreateConversationalTrainingAssignmentsRequest(proto.Message):
    r"""Request message of BatchCreateConversationalTrainingAssignment.

    All individual requests must have the same ``batch_uuid``. If no
    ``batch_uuid`` is provided, a new UUID will be generated for the
    entire batch.

    Attributes:
        parent (str):
            Required. The parent resource name to create assignments
            under. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``
        requests (MutableSequence[google.cloud.dialogflow_v2beta1.types.CreateConversationalTrainingAssignmentRequest]):
            Required. A list of assignment create
            requests.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    requests: MutableSequence['CreateConversationalTrainingAssignmentRequest'] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='CreateConversationalTrainingAssignmentRequest',
    )


class BatchCreateConversationalTrainingAssignmentsResponse(proto.Message):
    r"""Response message of
    BatchCreateConversationalTrainingAssignment.

    Attributes:
        conversational_training_assignments (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment]):
            The conversational training assignments
            created.
    """

    conversational_training_assignments: MutableSequence['ConversationalTrainingAssignment'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingAssignment',
    )


class BatchDeleteConversationalTrainingAssignmentsRequest(proto.Message):
    r"""Request message of
    BatchDeleteConversationalTrainingAssignment.

    Attributes:
        parent (str):
            Required. The parent resource name to delete assignments
            under. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``
        names (MutableSequence[str]):
            Required. A list of conversational training assignment
            resource names to delete. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    names: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=2,
    )


class BatchUpdateConversationalTrainingAssignmentsRequest(proto.Message):
    r"""Request message of
    BatchUpdateConversationalTrainingAssignment.

    Attributes:
        parent (str):
            Required. The parent resource name to update assignments
            under. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>``
        requests (MutableSequence[google.cloud.dialogflow_v2beta1.types.UpdateConversationalTrainingAssignmentRequest]):
            Required. A list of assignment update
            requests.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    requests: MutableSequence['UpdateConversationalTrainingAssignmentRequest'] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='UpdateConversationalTrainingAssignmentRequest',
    )


class BatchUpdateConversationalTrainingAssignmentsResponse(proto.Message):
    r"""Response message of
    BatchUpdateConversationalTrainingAssignment.

    Attributes:
        conversational_training_assignments (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment]):
            The conversational training assignments
            updated.
    """

    conversational_training_assignments: MutableSequence['ConversationalTrainingAssignment'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationalTrainingAssignment',
    )


class ConversationalTrainingAssignment(proto.Message):
    r"""A conversational training assignment that includes members
    that should get similar assignments and managed by the same
    group of managers.

    Attributes:
        name (str):
            Immutable. Identifier. The resource name of the
            conversational training assignment Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingTeams/<TeamID>/members/<MemberID>/assignments/<AssignmentID>``.
        due_time (google.protobuf.timestamp_pb2.Timestamp):
            Optional. The due date of the assignment.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The creation time of the
            conversational training assignment.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The last update time of the
            conversational training assignment.
        training_module (str):
            Required. The resource name of the conversational training
            module. Format:
            ``projects/<ProjectID>/locations/<LocationID>/conversationalTrainingModules/<ConversationalTrainingModuleID>``.
        batch_uuid (str):
            Output only. The UUID of the batch of
            assignments this assignment was created in.
        state (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment.State):
            Output only. State of the assignment.
        assignment_progress (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment.ComponentResult]):
            Optional. Saved results of the training
            simulation. The key is the assigned
            ModuleComponentUUID.
    """
    class State(proto.Enum):
        r"""Possible states of an assignment.

        Values:
            STATE_UNSPECIFIED (0):
                Not specified.
            ASSIGNED (1):
                Assignment set and is ready to be used.
            COMPLETED (2):
                Assignment has been completed.
            VOIDED (3):
                Assignment was voided.
        """
        STATE_UNSPECIFIED = 0
        ASSIGNED = 1
        COMPLETED = 2
        VOIDED = 3

    class SimulationResults(proto.Message):
        r"""Represents the results of a simulation module component.

        Attributes:
            attempts (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment.SimulationResults.Attempt]):
                The attempts at a simulation module
                component.
        """

        class InstructionFeedback(proto.Message):
            r"""Represents the feedback for a specific instruction.
            An instruction's condition was not met if the there was no
            constructive feedback and the suggestion was never followed.

            Attributes:
                instruction_title (str):
                    AI trainer instruction display title.
                constructive_feedback_count (int):
                    Number of times the expected agent actions
                    were not followed and constructive feedback was
                    given to the agent for this instruction.
                followed_suggestion (bool):
                    If the agent was successful with this
                    condition, regardless of the number of failures.
            """

            instruction_title: str = proto.Field(
                proto.STRING,
                number=1,
            )
            constructive_feedback_count: int = proto.Field(
                proto.INT32,
                number=2,
            )
            followed_suggestion: bool = proto.Field(
                proto.BOOL,
                number=3,
            )

        class Attempt(proto.Message):
            r"""Represents an agent's attempt at a simulation.

            Attributes:
                conversation (str):
                    Required. The full name of the simulation's conversation.
                    This conversation is not guaranteed to still exist. Format:
                    ``projects/<ProjectID>/locations/<LocationID>/conversation/<ConversationID>``
                instruction_feedback (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment.SimulationResults.InstructionFeedback]):
                    The feedback of every instruction at the time
                    of the simulation. Including those instructions
                    whose conditions were never met.
            """

            conversation: str = proto.Field(
                proto.STRING,
                number=1,
            )
            instruction_feedback: MutableSequence['ConversationalTrainingAssignment.SimulationResults.InstructionFeedback'] = proto.RepeatedField(
                proto.MESSAGE,
                number=2,
                message='ConversationalTrainingAssignment.SimulationResults.InstructionFeedback',
            )

        attempts: MutableSequence['ConversationalTrainingAssignment.SimulationResults.Attempt'] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='ConversationalTrainingAssignment.SimulationResults.Attempt',
        )

    class ComponentResult(proto.Message):
        r"""Represents a trainee's progress results for a specific mdoule
        component.


        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            simulation_results (google.cloud.dialogflow_v2beta1.types.ConversationalTrainingAssignment.SimulationResults):
                The simulation results for a simulation
                module component.

                This field is a member of `oneof`_ ``results``.
        """

        simulation_results: 'ConversationalTrainingAssignment.SimulationResults' = proto.Field(
            proto.MESSAGE,
            number=1,
            oneof='results',
            message='ConversationalTrainingAssignment.SimulationResults',
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    due_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=2,
        message=timestamp_pb2.Timestamp,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=4,
        message=timestamp_pb2.Timestamp,
    )
    training_module: str = proto.Field(
        proto.STRING,
        number=5,
    )
    batch_uuid: str = proto.Field(
        proto.STRING,
        number=6,
    )
    state: State = proto.Field(
        proto.ENUM,
        number=7,
        enum=State,
    )
    assignment_progress: MutableMapping[str, ComponentResult] = proto.MapField(
        proto.STRING,
        proto.MESSAGE,
        number=8,
        message=ComponentResult,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
