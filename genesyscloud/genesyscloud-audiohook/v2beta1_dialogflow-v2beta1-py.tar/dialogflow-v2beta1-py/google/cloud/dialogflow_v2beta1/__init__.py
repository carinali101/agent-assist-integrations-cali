# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from google.cloud.dialogflow_v2beta1 import gapic_version as package_version

import google.api_core as api_core
import sys

__version__ = package_version.__version__

if sys.version_info >= (3, 8):  # pragma: NO COVER
    from importlib import metadata
else:  # pragma: NO COVER
    # TODO(https://github.com/googleapis/python-api-core/issues/835): Remove
    # this code path once we drop support for Python 3.7
    import importlib_metadata as metadata


from .services.agents import AgentsClient
from .services.agents import AgentsAsyncClient
from .services.answer_records import AnswerRecordsClient
from .services.answer_records import AnswerRecordsAsyncClient
from .services.asynchronous_fulfillment import AsynchronousFulfillmentClient
from .services.asynchronous_fulfillment import AsynchronousFulfillmentAsyncClient
from .services.contexts import ContextsClient
from .services.contexts import ContextsAsyncClient
from .services.conversational_training_assignments import ConversationalTrainingAssignmentsClient
from .services.conversational_training_assignments import ConversationalTrainingAssignmentsAsyncClient
from .services.conversational_training_members import ConversationalTrainingMembersClient
from .services.conversational_training_members import ConversationalTrainingMembersAsyncClient
from .services.conversational_training_modules import ConversationalTrainingModulesClient
from .services.conversational_training_modules import ConversationalTrainingModulesAsyncClient
from .services.conversational_training_teams import ConversationalTrainingTeamsClient
from .services.conversational_training_teams import ConversationalTrainingTeamsAsyncClient
from .services.conversation_datasets import ConversationDatasetsClient
from .services.conversation_datasets import ConversationDatasetsAsyncClient
from .services.conversation_models import ConversationModelsClient
from .services.conversation_models import ConversationModelsAsyncClient
from .services.conversation_profiles import ConversationProfilesClient
from .services.conversation_profiles import ConversationProfilesAsyncClient
from .services.conversations import ConversationsClient
from .services.conversations import ConversationsAsyncClient
from .services.documents import DocumentsClient
from .services.documents import DocumentsAsyncClient
from .services.encryption_spec_service import EncryptionSpecServiceClient
from .services.encryption_spec_service import EncryptionSpecServiceAsyncClient
from .services.entity_types import EntityTypesClient
from .services.entity_types import EntityTypesAsyncClient
from .services.environments import EnvironmentsClient
from .services.environments import EnvironmentsAsyncClient
from .services.fulfillments import FulfillmentsClient
from .services.fulfillments import FulfillmentsAsyncClient
from .services.generator_evaluations import GeneratorEvaluationsClient
from .services.generator_evaluations import GeneratorEvaluationsAsyncClient
from .services.generators import GeneratorsClient
from .services.generators import GeneratorsAsyncClient
from .services.human_agent_assistants import HumanAgentAssistantsClient
from .services.human_agent_assistants import HumanAgentAssistantsAsyncClient
from .services.intents import IntentsClient
from .services.intents import IntentsAsyncClient
from .services.knowledge_bases import KnowledgeBasesClient
from .services.knowledge_bases import KnowledgeBasesAsyncClient
from .services.participants import ParticipantsClient
from .services.participants import ParticipantsAsyncClient
from .services.phone_number_orders import PhoneNumberOrdersClient
from .services.phone_number_orders import PhoneNumberOrdersAsyncClient
from .services.phone_numbers import PhoneNumbersClient
from .services.phone_numbers import PhoneNumbersAsyncClient
from .services.security_settings_service import SecuritySettingsServiceClient
from .services.security_settings_service import SecuritySettingsServiceAsyncClient
from .services.session_entity_types import SessionEntityTypesClient
from .services.session_entity_types import SessionEntityTypesAsyncClient
from .services.sessions import SessionsClient
from .services.sessions import SessionsAsyncClient
from .services.sip_trunks import SipTrunksClient
from .services.sip_trunks import SipTrunksAsyncClient
from .services.supervisor_assignment_service import SupervisorAssignmentServiceClient
from .services.supervisor_assignment_service import SupervisorAssignmentServiceAsyncClient
from .services.tools import ToolsClient
from .services.tools import ToolsAsyncClient
from .services.versions import VersionsClient
from .services.versions import VersionsAsyncClient

from .types.agent import Agent
from .types.agent import DeleteAgentRequest
from .types.agent import ExportAgentRequest
from .types.agent import ExportAgentResponse
from .types.agent import GetAgentRequest
from .types.agent import GetValidationResultRequest
from .types.agent import ImportAgentRequest
from .types.agent import RestoreAgentRequest
from .types.agent import SearchAgentsRequest
from .types.agent import SearchAgentsResponse
from .types.agent import SetAgentRequest
from .types.agent import SubAgent
from .types.agent import TrainAgentRequest
from .types.agent_coaching_instruction import AgentCoachingInstruction
from .types.answer_record import AgentAssistantFeedback
from .types.answer_record import AgentAssistantRecord
from .types.answer_record import AnswerFeedback
from .types.answer_record import AnswerRecord
from .types.answer_record import GetAnswerRecordRequest
from .types.answer_record import ListAnswerRecordsRequest
from .types.answer_record import ListAnswerRecordsResponse
from .types.answer_record import UpdateAnswerRecordRequest
from .types.asynchronous_fulfillment import FulfillmentResult
from .types.asynchronous_fulfillment import PushFulfillmentResultRequest
from .types.audio_config import BargeInConfig
from .types.audio_config import CustomPronunciationParams
from .types.audio_config import InputAudioConfig
from .types.audio_config import OutputAudioConfig
from .types.audio_config import SpeechContext
from .types.audio_config import SpeechToTextConfig
from .types.audio_config import SpeechWordInfo
from .types.audio_config import SynthesizeSpeechConfig
from .types.audio_config import TelephonyDtmfEvents
from .types.audio_config import VoiceSelectionParams
from .types.audio_config import AudioEncoding
from .types.audio_config import OutputAudioEncoding
from .types.audio_config import SpeechModelVariant
from .types.audio_config import SsmlVoiceGender
from .types.audio_config import TelephonyDtmf
from .types.context import Context
from .types.context import CreateContextRequest
from .types.context import DeleteAllContextsRequest
from .types.context import DeleteContextRequest
from .types.context import GetContextRequest
from .types.context import ListContextsRequest
from .types.context import ListContextsResponse
from .types.context import UpdateContextRequest
from .types.conversation import AckInteractionMonitoringAlertRequest
from .types.conversation import ActivateConversationRequest
from .types.conversation import AddConversationPhoneNumberRequest
from .types.conversation import BatchCreateMessagesRequest
from .types.conversation import BatchCreateMessagesResponse
from .types.conversation import CallCompanionConversationEvent
from .types.conversation import CallCompanionSettings
from .types.conversation import CallCompanionUserInput
from .types.conversation import CallMatcher
from .types.conversation import CompleteConversationRequest
from .types.conversation import Conversation
from .types.conversation import ConversationPhoneNumber
from .types.conversation import CreateCallMatcherRequest
from .types.conversation import CreateConversationRequest
from .types.conversation import CreateMessageRequest
from .types.conversation import DeactivateConversationRequest
from .types.conversation import DeleteCallMatcherRequest
from .types.conversation import ExportMessagesRequest
from .types.conversation import ExportMessagesResponse
from .types.conversation import GenerateStatelessSuggestionRequest
from .types.conversation import GenerateStatelessSuggestionResponse
from .types.conversation import GenerateStatelessSummaryRequest
from .types.conversation import GenerateStatelessSummaryResponse
from .types.conversation import GenerateSuggestionsRequest
from .types.conversation import GetCallCompanionSettingsRequest
from .types.conversation import GetConversationRequest
from .types.conversation import GetInteractionMonitoringAlertRequest
from .types.conversation import IngestContextReferencesRequest
from .types.conversation import IngestContextReferencesResponse
from .types.conversation import InitializeCallCompanionRequest
from .types.conversation import InitiatePhoneCallRequest
from .types.conversation import InitiatePhoneCallResponse
from .types.conversation import InjectCallCompanionInputRequest
from .types.conversation import InjectCallCompanionInputResponse
from .types.conversation import InjectCallCompanionUserInputRequest
from .types.conversation import InjectCallCompanionUserInputResponse
from .types.conversation import InjectSupervisorInputRequest
from .types.conversation import InjectSupervisorInputResponse
from .types.conversation import ListCallMatchersRequest
from .types.conversation import ListCallMatchersResponse
from .types.conversation import ListConversationsRequest
from .types.conversation import ListConversationsResponse
from .types.conversation import ListInteractionMonitoringAlertsRequest
from .types.conversation import ListInteractionMonitoringAlertsResponse
from .types.conversation import ListInteractionMonitoringMetricsRequest
from .types.conversation import ListInteractionMonitoringMetricsResponse
from .types.conversation import ListMessagesRequest
from .types.conversation import ListMessagesResponse
from .types.conversation import ListPastCallCompanionEventsRequest
from .types.conversation import ListPastCallCompanionEventsResponse
from .types.conversation import SearchArticleAnswer
from .types.conversation import SearchArticlesRequest
from .types.conversation import SearchArticlesResponse
from .types.conversation import SearchKnowledgeAnswer
from .types.conversation import SearchKnowledgeDebugInfo
from .types.conversation import SearchKnowledgeRequest
from .types.conversation import SearchKnowledgeResponse
from .types.conversation import StreamingListCallCompanionEventsRequest
from .types.conversation import StreamingListCallCompanionEventsResponse
from .types.conversation import StreamingListUpcomingCallCompanionEventsRequest
from .types.conversation import StreamingListUpcomingCallCompanionEventsResponse
from .types.conversation import SuggestConversationKeyMomentsRequest
from .types.conversation import SuggestConversationKeyMomentsResponse
from .types.conversation import SuggestConversationSummaryRequest
from .types.conversation import SuggestConversationSummaryResponse
from .types.conversation import UpdateConversationRequest
from .types.conversation_dataset import AnnotatedConversationDataset
from .types.conversation_dataset import AnnotationTaskConfig
from .types.conversation_dataset import ConversationDataset
from .types.conversation_dataset import ConversationInfo
from .types.conversation_dataset import CreateConversationDatasetOperationMetadata
from .types.conversation_dataset import CreateConversationDatasetRequest
from .types.conversation_dataset import DeleteAnnotatedConversationDatasetRequest
from .types.conversation_dataset import DeleteConversationDatasetOperationMetadata
from .types.conversation_dataset import DeleteConversationDatasetRequest
from .types.conversation_dataset import GetAnnotatedConversationDatasetRequest
from .types.conversation_dataset import GetConversationDatasetRequest
from .types.conversation_dataset import ImportConversationDataOperationMetadata
from .types.conversation_dataset import ImportConversationDataOperationResponse
from .types.conversation_dataset import ImportConversationDataRequest
from .types.conversation_dataset import InputConfig
from .types.conversation_dataset import LabelConversationOperationMetadata
from .types.conversation_dataset import LabelConversationRequest
from .types.conversation_dataset import LabelConversationResponse
from .types.conversation_dataset import ListAnnotatedConversationDatasetsRequest
from .types.conversation_dataset import ListAnnotatedConversationDatasetsResponse
from .types.conversation_dataset import ListConversationDatasetsRequest
from .types.conversation_dataset import ListConversationDatasetsResponse
from .types.conversation_event import ConversationEvent
from .types.conversation_event import InteractionMonitoringEvent
from .types.conversation_model import ArticleSuggestionModelMetadata
from .types.conversation_model import AssociateAllowlistInfo
from .types.conversation_model import ConversationModel
from .types.conversation_model import CopyConversationModelOperationMetadata
from .types.conversation_model import CopyConversationModelRequest
from .types.conversation_model import CreateConversationModelRequest
from .types.conversation_model import DeleteConversationModelRequest
from .types.conversation_model import DeployConversationModelRequest
from .types.conversation_model import GetConversationModelRequest
from .types.conversation_model import InputDataset
from .types.conversation_model import KeyMomentModelMetadata
from .types.conversation_model import ListConversationModelsRequest
from .types.conversation_model import ListConversationModelsResponse
from .types.conversation_model import SmartComposeModelMetadata
from .types.conversation_model import SmartReplyModelMetadata
from .types.conversation_model import SummarizationModelMetadata
from .types.conversation_model import UndeployConversationModelRequest
from .types.conversation_profile import AutomatedAgentConfig
from .types.conversation_profile import CallCompanionConfig
from .types.conversation_profile import ClearSuggestionFeatureConfigOperationMetadata
from .types.conversation_profile import ClearSuggestionFeatureConfigRequest
from .types.conversation_profile import ConversationProfile
from .types.conversation_profile import CreateConversationProfileRequest
from .types.conversation_profile import DeleteConversationProfileRequest
from .types.conversation_profile import GetConversationProfileRequest
from .types.conversation_profile import HumanAgentAssistantConfig
from .types.conversation_profile import HumanAgentHandoffConfig
from .types.conversation_profile import ListConversationProfilesRequest
from .types.conversation_profile import ListConversationProfilesResponse
from .types.conversation_profile import LoggingConfig
from .types.conversation_profile import NotificationConfig
from .types.conversation_profile import SetSuggestionFeatureConfigOperationMetadata
from .types.conversation_profile import SetSuggestionFeatureConfigRequest
from .types.conversation_profile import SipConfig
from .types.conversation_profile import TelephonySttConfig
from .types.conversation_profile import UpdateConversationProfileRequest
from .types.conversational_training_assignment import BatchCreateConversationalTrainingAssignmentsRequest
from .types.conversational_training_assignment import BatchCreateConversationalTrainingAssignmentsResponse
from .types.conversational_training_assignment import BatchDeleteConversationalTrainingAssignmentsRequest
from .types.conversational_training_assignment import BatchUpdateConversationalTrainingAssignmentsRequest
from .types.conversational_training_assignment import BatchUpdateConversationalTrainingAssignmentsResponse
from .types.conversational_training_assignment import CompleteConversationalTrainingAssignmentRequest
from .types.conversational_training_assignment import ConversationalTrainingAssignment
from .types.conversational_training_assignment import CreateConversationalTrainingAssignmentRequest
from .types.conversational_training_assignment import DeleteConversationalTrainingAssignmentRequest
from .types.conversational_training_assignment import FinalizeSimulationAttemptRequest
from .types.conversational_training_assignment import GetConversationalTrainingAssignmentRequest
from .types.conversational_training_assignment import ListConversationalTrainingAssignmentsRequest
from .types.conversational_training_assignment import ListConversationalTrainingAssignmentsResponse
from .types.conversational_training_assignment import UpdateConversationalTrainingAssignmentRequest
from .types.conversational_training_member import ConversationalTrainingMember
from .types.conversational_training_member import CreateConversationalTrainingMemberRequest
from .types.conversational_training_member import DeleteConversationalTrainingMemberRequest
from .types.conversational_training_member import GetConversationalTrainingMemberRequest
from .types.conversational_training_member import ListConversationalTrainingMembersRequest
from .types.conversational_training_member import ListConversationalTrainingMembersResponse
from .types.conversational_training_member import UpdateConversationalTrainingMemberRequest
from .types.conversational_training_module import ConversationalTrainingModule
from .types.conversational_training_module import CreateConversationalTrainingModuleRequest
from .types.conversational_training_module import DeleteConversationalTrainingModuleRequest
from .types.conversational_training_module import GetConversationalTrainingModuleRequest
from .types.conversational_training_module import ListConversationalTrainingModulesRequest
from .types.conversational_training_module import ListConversationalTrainingModulesResponse
from .types.conversational_training_module import UpdateConversationalTrainingModuleRequest
from .types.conversational_training_team import ConversationalTrainingTeam
from .types.conversational_training_team import CreateConversationalTrainingTeamRequest
from .types.conversational_training_team import DeleteConversationalTrainingTeamRequest
from .types.conversational_training_team import GetConversationalTrainingTeamRequest
from .types.conversational_training_team import ListConversationalTrainingTeamsRequest
from .types.conversational_training_team import ListConversationalTrainingTeamsResponse
from .types.conversational_training_team import UpdateConversationalTrainingTeamRequest
from .types.document import CreateDocumentRequest
from .types.document import DeleteDocumentRequest
from .types.document import Document
from .types.document import ExportDocumentRequest
from .types.document import ExportOperationMetadata
from .types.document import GenerateDocumentRequest
from .types.document import GetDocumentRequest
from .types.document import ImportDocumentsRequest
from .types.document import ImportDocumentsResponse
from .types.document import ImportDocumentTemplate
from .types.document import InputDatasets
from .types.document import KnowledgeOperationMetadata
from .types.document import ListDocumentsRequest
from .types.document import ListDocumentsResponse
from .types.document import ReloadDocumentRequest
from .types.document import UpdateDocumentRequest
from .types.document_collection import DocumentCollectionOperationMetadata
from .types.encryption_spec import EncryptionSpec
from .types.encryption_spec import GetEncryptionSpecRequest
from .types.encryption_spec import InitializeEncryptionSpecMetadata
from .types.encryption_spec import InitializeEncryptionSpecRequest
from .types.encryption_spec import InitializeEncryptionSpecResponse
from .types.entity_type import BatchCreateEntitiesRequest
from .types.entity_type import BatchDeleteEntitiesRequest
from .types.entity_type import BatchDeleteEntityTypesRequest
from .types.entity_type import BatchUpdateEntitiesRequest
from .types.entity_type import BatchUpdateEntityTypesRequest
from .types.entity_type import BatchUpdateEntityTypesResponse
from .types.entity_type import CreateEntityTypeRequest
from .types.entity_type import DeleteEntityTypeRequest
from .types.entity_type import EntityType
from .types.entity_type import EntityTypeBatch
from .types.entity_type import GetEntityTypeRequest
from .types.entity_type import ListEntityTypesRequest
from .types.entity_type import ListEntityTypesResponse
from .types.entity_type import UpdateEntityTypeRequest
from .types.environment import CreateEnvironmentRequest
from .types.environment import DeleteEnvironmentRequest
from .types.environment import Environment
from .types.environment import EnvironmentHistory
from .types.environment import GetEnvironmentHistoryRequest
from .types.environment import GetEnvironmentRequest
from .types.environment import ListEnvironmentsRequest
from .types.environment import ListEnvironmentsResponse
from .types.environment import TextToSpeechSettings
from .types.environment import UpdateEnvironmentRequest
from .types.fulfillment import Fulfillment
from .types.fulfillment import GetFulfillmentRequest
from .types.fulfillment import UpdateFulfillmentRequest
from .types.gcs import GcsDestination
from .types.gcs import GcsSource
from .types.gcs import GcsSources
from .types.generator import AgentCoachingArticleSnippet
from .types.generator import AgentCoachingContext
from .types.generator import AgentCoachingSuggestion
from .types.generator import ConversationContext
from .types.generator import CreateGeneratorRequest
from .types.generator import DeleteGeneratorRequest
from .types.generator import FewShotExample
from .types.generator import FreeFormContext
from .types.generator import FreeFormSuggestion
from .types.generator import Generator
from .types.generator import GeneratorSuggestion
from .types.generator import GetGeneratorRequest
from .types.generator import InferenceParameter
from .types.generator import ListGeneratorsRequest
from .types.generator import ListGeneratorsResponse
from .types.generator import MessageEntry
from .types.generator import RaiSettings
from .types.generator import SearchConfig
from .types.generator import SuggestionDedupingConfig
from .types.generator import SummarizationContext
from .types.generator import SummarizationSection
from .types.generator import SummarizationSectionList
from .types.generator import SummarySuggestion
from .types.generator import TranslationContext
from .types.generator import TranslationCustomization
from .types.generator import TranslationSuggestion
from .types.generator import UpdateGeneratorRequest
from .types.generator import TriggerEvent
from .types.generator_evaluation import CreateGeneratorEvaluationRequest
from .types.generator_evaluation import DeleteGeneratorEvaluationRequest
from .types.generator_evaluation import EvaluationStatus
from .types.generator_evaluation import GeneratorEvaluation
from .types.generator_evaluation import GeneratorEvaluationConfig
from .types.generator_evaluation import GetGeneratorEvaluationRequest
from .types.generator_evaluation import ListGeneratorEvaluationsRequest
from .types.generator_evaluation import ListGeneratorEvaluationsResponse
from .types.generator_evaluation import SummarizationEvaluationMetrics
from .types.human_agent_assistant import ArticleSuggestionConfig
from .types.human_agent_assistant import CompileSuggestionsRequest
from .types.human_agent_assistant import CompileSuggestionsResponse
from .types.human_agent_assistant import CreateHumanAgentAssistantRequest
from .types.human_agent_assistant import DeleteHumanAgentAssistantRequest
from .types.human_agent_assistant import DialogflowAssistConfig
from .types.human_agent_assistant import FaqAnswersConfig
from .types.human_agent_assistant import GetHumanAgentAssistantRequest
from .types.human_agent_assistant import HumanAgentAssistant
from .types.human_agent_assistant import ListHumanAgentAssistantsRequest
from .types.human_agent_assistant import ListHumanAgentAssistantsResponse
from .types.human_agent_assistant import SmartReplyConfig
from .types.human_agent_assistant import UpdateHumanAgentAssistantRequest
from .types.human_agent_assistant import TriggerModelMode
from .types.human_agent_assistant_event import HumanAgentAssistantEvent
from .types.intent import BatchDeleteIntentsRequest
from .types.intent import BatchUpdateIntentsRequest
from .types.intent import BatchUpdateIntentsResponse
from .types.intent import CreateIntentRequest
from .types.intent import DeleteIntentRequest
from .types.intent import GetIntentRequest
from .types.intent import Intent
from .types.intent import IntentBatch
from .types.intent import ListIntentsRequest
from .types.intent import ListIntentsResponse
from .types.intent import UpdateIntentRequest
from .types.intent import IntentView
from .types.interaction_monitoring import AlertMetadata
from .types.interaction_monitoring import InteractionMonitoringAlert
from .types.interaction_monitoring import MetricValues
from .types.interaction_monitoring import RawMetricValue
from .types.knowledge_base import CreateKnowledgeBaseRequest
from .types.knowledge_base import DeleteKnowledgeBaseRequest
from .types.knowledge_base import GetKnowledgeBaseRequest
from .types.knowledge_base import KnowledgeBase
from .types.knowledge_base import ListKnowledgeBasesRequest
from .types.knowledge_base import ListKnowledgeBasesResponse
from .types.knowledge_base import UpdateKnowledgeBaseRequest
from .types.operations import CreateConversationModelOperationMetadata
from .types.operations import DeleteConversationModelOperationMetadata
from .types.operations import DeployConversationModelOperationMetadata
from .types.operations import GenerateDocumentOperationMetadata
from .types.operations import GeneratorEvaluationOperationMetadata
from .types.operations import UndeployConversationModelOperationMetadata
from .types.participant import AnalyzeContentRequest
from .types.participant import AnalyzeContentResponse
from .types.participant import AnnotatedMessagePart
from .types.participant import ArticleAnswer
from .types.participant import AssistQueryParameters
from .types.participant import AudioInput
from .types.participant import AutomatedAgentReply
from .types.participant import BidiEndpointInteractRequest
from .types.participant import BidiEndpointInteractResponse
from .types.participant import BidiStreamingAnalyzeContentRequest
from .types.participant import BidiStreamingAnalyzeContentResponse
from .types.participant import CompileSuggestionRequest
from .types.participant import CompileSuggestionResponse
from .types.participant import CreateParticipantRequest
from .types.participant import DialogflowAssistAnswer
from .types.participant import DtmfParameters
from .types.participant import FaqAnswer
from .types.participant import GenerateSuggestionsResponse
from .types.participant import GetParticipantRequest
from .types.participant import IngestedContextReferenceDebugInfo
from .types.participant import InputAudio
from .types.participant import InputText
from .types.participant import InputTextConfig
from .types.participant import IntentInput
from .types.participant import IntentSuggestion
from .types.participant import KnowledgeAssistAnswer
from .types.participant import KnowledgeAssistDebugInfo
from .types.participant import ListParticipantsRequest
from .types.participant import ListParticipantsResponse
from .types.participant import ListSuggestionsRequest
from .types.participant import ListSuggestionsResponse
from .types.participant import Message
from .types.participant import MessageAnnotation
from .types.participant import OutputAudio
from .types.participant import ParameterSuggestions
from .types.participant import Participant
from .types.participant import ResponseMessage
from .types.participant import ServiceLatency
from .types.participant import SmartComposeAnswer
from .types.participant import SmartReplyAnswer
from .types.participant import StreamingAnalyzeContentRequest
from .types.participant import StreamingAnalyzeContentResponse
from .types.participant import SuggestArticlesRequest
from .types.participant import SuggestArticlesResponse
from .types.participant import SuggestDialogflowAssistsRequest
from .types.participant import SuggestDialogflowAssistsResponse
from .types.participant import SuggestFaqAnswersRequest
from .types.participant import SuggestFaqAnswersResponse
from .types.participant import Suggestion
from .types.participant import SuggestionFeature
from .types.participant import SuggestionInput
from .types.participant import SuggestionResult
from .types.participant import SuggestKnowledgeAssistRequest
from .types.participant import SuggestKnowledgeAssistResponse
from .types.participant import SuggestSmartComposeAnswersRequest
from .types.participant import SuggestSmartComposeAnswersResponse
from .types.participant import SuggestSmartRepliesRequest
from .types.participant import SuggestSmartRepliesResponse
from .types.participant import UpdateParticipantRequest
from .types.participant import DatastoreResponseReason
from .types.phone_number import CreatePhoneNumberRequest
from .types.phone_number import DeletePhoneNumberRequest
from .types.phone_number import InitiateStreamingApiCallRequest
from .types.phone_number import InitiateStreamingApiCallResponse
from .types.phone_number import InitiateWebRtcCallRequest
from .types.phone_number import InitiateWebRtcCallResponse
from .types.phone_number import ListPhoneNumbersRequest
from .types.phone_number import ListPhoneNumbersResponse
from .types.phone_number import PhoneNumber
from .types.phone_number import UndeletePhoneNumberRequest
from .types.phone_number import UpdatePhoneNumberRequest
from .types.phone_number_order import CancelPhoneNumberOrderRequest
from .types.phone_number_order import CreatePhoneNumberOrderRequest
from .types.phone_number_order import GetPhoneNumberOrderRequest
from .types.phone_number_order import ListPhoneNumberOrdersRequest
from .types.phone_number_order import ListPhoneNumberOrdersResponse
from .types.phone_number_order import PhoneNumberOrder
from .types.phone_number_order import PhoneNumberSpec
from .types.phone_number_order import UpdatePhoneNumberOrderRequest
from .types.security_settings import GetSecuritySettingsRequest
from .types.security_settings import SecuritySettings
from .types.security_settings import UpdateSecuritySettingsRequest
from .types.session import CloudConversationDebuggingInfo
from .types.session import DetectIntentRequest
from .types.session import DetectIntentResponse
from .types.session import EventInput
from .types.session import KnowledgeAnswers
from .types.session import QueryInput
from .types.session import QueryParameters
from .types.session import QueryResult
from .types.session import Sentiment
from .types.session import SentimentAnalysisRequestConfig
from .types.session import SentimentAnalysisResult
from .types.session import StreamingDetectIntentRequest
from .types.session import StreamingDetectIntentResponse
from .types.session import StreamingRecognitionResult
from .types.session import TextInput
from .types.session_entity_type import CreateSessionEntityTypeRequest
from .types.session_entity_type import DeleteSessionEntityTypeRequest
from .types.session_entity_type import GetSessionEntityTypeRequest
from .types.session_entity_type import ListSessionEntityTypesRequest
from .types.session_entity_type import ListSessionEntityTypesResponse
from .types.session_entity_type import SessionEntityType
from .types.session_entity_type import UpdateSessionEntityTypeRequest
from .types.sip_trunk import Connection
from .types.sip_trunk import CreateSipTrunkRequest
from .types.sip_trunk import DeleteSipTrunkRequest
from .types.sip_trunk import DisableSipOptionsPingRequest
from .types.sip_trunk import DisableSipOptionsPingResponse
from .types.sip_trunk import GetSipTrunkRequest
from .types.sip_trunk import InitiateSipOptionsPingRequest
from .types.sip_trunk import InitiateSipOptionsPingResponse
from .types.sip_trunk import ListSipTrunksRequest
from .types.sip_trunk import ListSipTrunksResponse
from .types.sip_trunk import ProbeDetails
from .types.sip_trunk import SipHostname
from .types.sip_trunk import SipTrunk
from .types.sip_trunk import UpdateSipTrunkRequest
from .types.supervisor_assignment_service import AssignSupervisorRequest
from .types.supervisor_assignment_service import AssignSupervisorResponse
from .types.supervisor_assignment_service import ConversationAssignment
from .types.supervisor_assignment_service import CreateSupervisorRequest
from .types.supervisor_assignment_service import DeleteSupervisorRequest
from .types.supervisor_assignment_service import ListConversationAssignmentsRequest
from .types.supervisor_assignment_service import ListConversationAssignmentsResponse
from .types.supervisor_assignment_service import ListSupervisorsRequest
from .types.supervisor_assignment_service import ListSupervisorsResponse
from .types.supervisor_assignment_service import Supervisor
from .types.supervisor_assignment_service import SupervisorStatus
from .types.supervisor_assignment_service import UpdateSupervisorStatusRequest
from .types.supervisor_assignment_service import Availability
from .types.tool import CreateToolRequest
from .types.tool import DeleteToolRequest
from .types.tool import GetToolRequest
from .types.tool import ListToolsRequest
from .types.tool import ListToolsResponse
from .types.tool import Tool
from .types.tool import UpdateToolRequest
from .types.tool_call import ToolCall
from .types.tool_call import ToolCallResult
from .types.toolset import ToolsetTool
from .types.validation_result import ValidationError
from .types.validation_result import ValidationResult
from .types.version import CreateVersionRequest
from .types.version import DeleteVersionRequest
from .types.version import GetVersionRequest
from .types.version import ListVersionsRequest
from .types.version import ListVersionsResponse
from .types.version import UpdateVersionRequest
from .types.version import Version
from .types.webhook import OriginalDetectIntentRequest
from .types.webhook import WebhookRequest
from .types.webhook import WebhookResponse

if hasattr(api_core, "check_python_version") and hasattr(api_core, "check_dependency_versions"):   # pragma: NO COVER
    api_core.check_python_version("google.cloud.dialogflow_v2beta1") # type: ignore
    api_core.check_dependency_versions("google.cloud.dialogflow_v2beta1") # type: ignore
else:   # pragma: NO COVER
    # An older version of api_core is installed which does not define the
    # functions above. We do equivalent checks manually.
    try:
        import warnings
        import sys

        _py_version_str = sys.version.split()[0]
        _package_label = "google.cloud.dialogflow_v2beta1"
        if sys.version_info < (3, 9):
            warnings.warn("You are using a non-supported Python version " +
                          f"({_py_version_str}).  Google will not post any further " +
                          f"updates to {_package_label} supporting this Python version. " +
                          "Please upgrade to the latest Python version, or at " +
                          f"least to Python 3.9, and then update {_package_label}.",
                          FutureWarning)
        if sys.version_info[:2] == (3, 9):
            warnings.warn(f"You are using a Python version ({_py_version_str}) " +
                          f"which Google will stop supporting in {_package_label} in " +
                          "January 2026. Please " +
                          "upgrade to the latest Python version, or at " +
                          "least to Python 3.10, before then, and " +
                          f"then update {_package_label}.",
                          FutureWarning)

        def parse_version_to_tuple(version_string: str):
            """Safely converts a semantic version string to a comparable tuple of integers.
            Example: "4.25.8" -> (4, 25, 8)
            Ignores non-numeric parts and handles common version formats.
            Args:
                version_string: Version string in the format "x.y.z" or "x.y.z<suffix>"
            Returns:
                Tuple of integers for the parsed version string.
            """
            parts = []
            for part in version_string.split("."):
                try:
                    parts.append(int(part))
                except ValueError:
                    # If it's a non-numeric part (e.g., '1.0.0b1' -> 'b1'), stop here.
                    # This is a simplification compared to 'packaging.parse_version', but sufficient
                    # for comparing strictly numeric semantic versions.
                    break
            return tuple(parts)

        def _get_version(dependency_name):
            try:
                version_string: str = metadata.version(dependency_name)
                parsed_version = parse_version_to_tuple(version_string)
                return (parsed_version, version_string)
            except Exception:
                # Catch exceptions from metadata.version() (e.g., PackageNotFoundError)
                # or errors during parse_version_to_tuple
                return (None, "--")

        _dependency_package = "google.protobuf"
        _next_supported_version = "4.25.8"
        _next_supported_version_tuple = (4, 25, 8)
        _recommendation = " (we recommend 6.x)"
        (_version_used, _version_used_string) = _get_version(_dependency_package)
        if _version_used and _version_used < _next_supported_version_tuple:
            warnings.warn(f"Package {_package_label} depends on " +
                          f"{_dependency_package}, currently installed at version " +
                          f"{_version_used_string}. Future updates to " +
                          f"{_package_label} will require {_dependency_package} at " +
                          f"version {_next_supported_version} or higher{_recommendation}." +
                          " Please ensure " +
                          "that either (a) your Python environment doesn't pin the " +
                          f"version of {_dependency_package}, so that updates to " +
                          f"{_package_label} can require the higher version, or " +
                          "(b) you manually update your Python environment to use at " +
                          f"least version {_next_supported_version} of " +
                          f"{_dependency_package}.",
                          FutureWarning)
    except Exception:
            warnings.warn("Could not determine the version of Python " +
                          "currently being used. To continue receiving " +
                          "updates for {_package_label}, ensure you are " +
                          "using a supported version of Python; see " +
                          "https://devguide.python.org/versions/")

__all__ = (
    'AgentsAsyncClient',
    'AnswerRecordsAsyncClient',
    'AsynchronousFulfillmentAsyncClient',
    'ContextsAsyncClient',
    'ConversationDatasetsAsyncClient',
    'ConversationModelsAsyncClient',
    'ConversationProfilesAsyncClient',
    'ConversationalTrainingAssignmentsAsyncClient',
    'ConversationalTrainingMembersAsyncClient',
    'ConversationalTrainingModulesAsyncClient',
    'ConversationalTrainingTeamsAsyncClient',
    'ConversationsAsyncClient',
    'DocumentsAsyncClient',
    'EncryptionSpecServiceAsyncClient',
    'EntityTypesAsyncClient',
    'EnvironmentsAsyncClient',
    'FulfillmentsAsyncClient',
    'GeneratorEvaluationsAsyncClient',
    'GeneratorsAsyncClient',
    'HumanAgentAssistantsAsyncClient',
    'IntentsAsyncClient',
    'KnowledgeBasesAsyncClient',
    'ParticipantsAsyncClient',
    'PhoneNumberOrdersAsyncClient',
    'PhoneNumbersAsyncClient',
    'SecuritySettingsServiceAsyncClient',
    'SessionEntityTypesAsyncClient',
    'SessionsAsyncClient',
    'SipTrunksAsyncClient',
    'SupervisorAssignmentServiceAsyncClient',
    'ToolsAsyncClient',
    'VersionsAsyncClient',
'AckInteractionMonitoringAlertRequest',
'ActivateConversationRequest',
'AddConversationPhoneNumberRequest',
'Agent',
'AgentAssistantFeedback',
'AgentAssistantRecord',
'AgentCoachingArticleSnippet',
'AgentCoachingContext',
'AgentCoachingInstruction',
'AgentCoachingSuggestion',
'AgentsClient',
'AlertMetadata',
'AnalyzeContentRequest',
'AnalyzeContentResponse',
'AnnotatedConversationDataset',
'AnnotatedMessagePart',
'AnnotationTaskConfig',
'AnswerFeedback',
'AnswerRecord',
'AnswerRecordsClient',
'ArticleAnswer',
'ArticleSuggestionConfig',
'ArticleSuggestionModelMetadata',
'AssignSupervisorRequest',
'AssignSupervisorResponse',
'AssistQueryParameters',
'AssociateAllowlistInfo',
'AsynchronousFulfillmentClient',
'AudioEncoding',
'AudioInput',
'AutomatedAgentConfig',
'AutomatedAgentReply',
'Availability',
'BargeInConfig',
'BatchCreateConversationalTrainingAssignmentsRequest',
'BatchCreateConversationalTrainingAssignmentsResponse',
'BatchCreateEntitiesRequest',
'BatchCreateMessagesRequest',
'BatchCreateMessagesResponse',
'BatchDeleteConversationalTrainingAssignmentsRequest',
'BatchDeleteEntitiesRequest',
'BatchDeleteEntityTypesRequest',
'BatchDeleteIntentsRequest',
'BatchUpdateConversationalTrainingAssignmentsRequest',
'BatchUpdateConversationalTrainingAssignmentsResponse',
'BatchUpdateEntitiesRequest',
'BatchUpdateEntityTypesRequest',
'BatchUpdateEntityTypesResponse',
'BatchUpdateIntentsRequest',
'BatchUpdateIntentsResponse',
'BidiEndpointInteractRequest',
'BidiEndpointInteractResponse',
'BidiStreamingAnalyzeContentRequest',
'BidiStreamingAnalyzeContentResponse',
'CallCompanionConfig',
'CallCompanionConversationEvent',
'CallCompanionSettings',
'CallCompanionUserInput',
'CallMatcher',
'CancelPhoneNumberOrderRequest',
'ClearSuggestionFeatureConfigOperationMetadata',
'ClearSuggestionFeatureConfigRequest',
'CloudConversationDebuggingInfo',
'CompileSuggestionRequest',
'CompileSuggestionResponse',
'CompileSuggestionsRequest',
'CompileSuggestionsResponse',
'CompleteConversationRequest',
'CompleteConversationalTrainingAssignmentRequest',
'Connection',
'Context',
'ContextsClient',
'Conversation',
'ConversationAssignment',
'ConversationContext',
'ConversationDataset',
'ConversationDatasetsClient',
'ConversationEvent',
'ConversationInfo',
'ConversationModel',
'ConversationModelsClient',
'ConversationPhoneNumber',
'ConversationProfile',
'ConversationProfilesClient',
'ConversationalTrainingAssignment',
'ConversationalTrainingAssignmentsClient',
'ConversationalTrainingMember',
'ConversationalTrainingMembersClient',
'ConversationalTrainingModule',
'ConversationalTrainingModulesClient',
'ConversationalTrainingTeam',
'ConversationalTrainingTeamsClient',
'ConversationsClient',
'CopyConversationModelOperationMetadata',
'CopyConversationModelRequest',
'CreateCallMatcherRequest',
'CreateContextRequest',
'CreateConversationDatasetOperationMetadata',
'CreateConversationDatasetRequest',
'CreateConversationModelOperationMetadata',
'CreateConversationModelRequest',
'CreateConversationProfileRequest',
'CreateConversationRequest',
'CreateConversationalTrainingAssignmentRequest',
'CreateConversationalTrainingMemberRequest',
'CreateConversationalTrainingModuleRequest',
'CreateConversationalTrainingTeamRequest',
'CreateDocumentRequest',
'CreateEntityTypeRequest',
'CreateEnvironmentRequest',
'CreateGeneratorEvaluationRequest',
'CreateGeneratorRequest',
'CreateHumanAgentAssistantRequest',
'CreateIntentRequest',
'CreateKnowledgeBaseRequest',
'CreateMessageRequest',
'CreateParticipantRequest',
'CreatePhoneNumberOrderRequest',
'CreatePhoneNumberRequest',
'CreateSessionEntityTypeRequest',
'CreateSipTrunkRequest',
'CreateSupervisorRequest',
'CreateToolRequest',
'CreateVersionRequest',
'CustomPronunciationParams',
'DatastoreResponseReason',
'DeactivateConversationRequest',
'DeleteAgentRequest',
'DeleteAllContextsRequest',
'DeleteAnnotatedConversationDatasetRequest',
'DeleteCallMatcherRequest',
'DeleteContextRequest',
'DeleteConversationDatasetOperationMetadata',
'DeleteConversationDatasetRequest',
'DeleteConversationModelOperationMetadata',
'DeleteConversationModelRequest',
'DeleteConversationProfileRequest',
'DeleteConversationalTrainingAssignmentRequest',
'DeleteConversationalTrainingMemberRequest',
'DeleteConversationalTrainingModuleRequest',
'DeleteConversationalTrainingTeamRequest',
'DeleteDocumentRequest',
'DeleteEntityTypeRequest',
'DeleteEnvironmentRequest',
'DeleteGeneratorEvaluationRequest',
'DeleteGeneratorRequest',
'DeleteHumanAgentAssistantRequest',
'DeleteIntentRequest',
'DeleteKnowledgeBaseRequest',
'DeletePhoneNumberRequest',
'DeleteSessionEntityTypeRequest',
'DeleteSipTrunkRequest',
'DeleteSupervisorRequest',
'DeleteToolRequest',
'DeleteVersionRequest',
'DeployConversationModelOperationMetadata',
'DeployConversationModelRequest',
'DetectIntentRequest',
'DetectIntentResponse',
'DialogflowAssistAnswer',
'DialogflowAssistConfig',
'DisableSipOptionsPingRequest',
'DisableSipOptionsPingResponse',
'Document',
'DocumentCollectionOperationMetadata',
'DocumentsClient',
'DtmfParameters',
'EncryptionSpec',
'EncryptionSpecServiceClient',
'EntityType',
'EntityTypeBatch',
'EntityTypesClient',
'Environment',
'EnvironmentHistory',
'EnvironmentsClient',
'EvaluationStatus',
'EventInput',
'ExportAgentRequest',
'ExportAgentResponse',
'ExportDocumentRequest',
'ExportMessagesRequest',
'ExportMessagesResponse',
'ExportOperationMetadata',
'FaqAnswer',
'FaqAnswersConfig',
'FewShotExample',
'FinalizeSimulationAttemptRequest',
'FreeFormContext',
'FreeFormSuggestion',
'Fulfillment',
'FulfillmentResult',
'FulfillmentsClient',
'GcsDestination',
'GcsSource',
'GcsSources',
'GenerateDocumentOperationMetadata',
'GenerateDocumentRequest',
'GenerateStatelessSuggestionRequest',
'GenerateStatelessSuggestionResponse',
'GenerateStatelessSummaryRequest',
'GenerateStatelessSummaryResponse',
'GenerateSuggestionsRequest',
'GenerateSuggestionsResponse',
'Generator',
'GeneratorEvaluation',
'GeneratorEvaluationConfig',
'GeneratorEvaluationOperationMetadata',
'GeneratorEvaluationsClient',
'GeneratorSuggestion',
'GeneratorsClient',
'GetAgentRequest',
'GetAnnotatedConversationDatasetRequest',
'GetAnswerRecordRequest',
'GetCallCompanionSettingsRequest',
'GetContextRequest',
'GetConversationDatasetRequest',
'GetConversationModelRequest',
'GetConversationProfileRequest',
'GetConversationRequest',
'GetConversationalTrainingAssignmentRequest',
'GetConversationalTrainingMemberRequest',
'GetConversationalTrainingModuleRequest',
'GetConversationalTrainingTeamRequest',
'GetDocumentRequest',
'GetEncryptionSpecRequest',
'GetEntityTypeRequest',
'GetEnvironmentHistoryRequest',
'GetEnvironmentRequest',
'GetFulfillmentRequest',
'GetGeneratorEvaluationRequest',
'GetGeneratorRequest',
'GetHumanAgentAssistantRequest',
'GetIntentRequest',
'GetInteractionMonitoringAlertRequest',
'GetKnowledgeBaseRequest',
'GetParticipantRequest',
'GetPhoneNumberOrderRequest',
'GetSecuritySettingsRequest',
'GetSessionEntityTypeRequest',
'GetSipTrunkRequest',
'GetToolRequest',
'GetValidationResultRequest',
'GetVersionRequest',
'HumanAgentAssistant',
'HumanAgentAssistantConfig',
'HumanAgentAssistantEvent',
'HumanAgentAssistantsClient',
'HumanAgentHandoffConfig',
'ImportAgentRequest',
'ImportConversationDataOperationMetadata',
'ImportConversationDataOperationResponse',
'ImportConversationDataRequest',
'ImportDocumentTemplate',
'ImportDocumentsRequest',
'ImportDocumentsResponse',
'InferenceParameter',
'IngestContextReferencesRequest',
'IngestContextReferencesResponse',
'IngestedContextReferenceDebugInfo',
'InitializeCallCompanionRequest',
'InitializeEncryptionSpecMetadata',
'InitializeEncryptionSpecRequest',
'InitializeEncryptionSpecResponse',
'InitiatePhoneCallRequest',
'InitiatePhoneCallResponse',
'InitiateSipOptionsPingRequest',
'InitiateSipOptionsPingResponse',
'InitiateStreamingApiCallRequest',
'InitiateStreamingApiCallResponse',
'InitiateWebRtcCallRequest',
'InitiateWebRtcCallResponse',
'InjectCallCompanionInputRequest',
'InjectCallCompanionInputResponse',
'InjectCallCompanionUserInputRequest',
'InjectCallCompanionUserInputResponse',
'InjectSupervisorInputRequest',
'InjectSupervisorInputResponse',
'InputAudio',
'InputAudioConfig',
'InputConfig',
'InputDataset',
'InputDatasets',
'InputText',
'InputTextConfig',
'Intent',
'IntentBatch',
'IntentInput',
'IntentSuggestion',
'IntentView',
'IntentsClient',
'InteractionMonitoringAlert',
'InteractionMonitoringEvent',
'KeyMomentModelMetadata',
'KnowledgeAnswers',
'KnowledgeAssistAnswer',
'KnowledgeAssistDebugInfo',
'KnowledgeBase',
'KnowledgeBasesClient',
'KnowledgeOperationMetadata',
'LabelConversationOperationMetadata',
'LabelConversationRequest',
'LabelConversationResponse',
'ListAnnotatedConversationDatasetsRequest',
'ListAnnotatedConversationDatasetsResponse',
'ListAnswerRecordsRequest',
'ListAnswerRecordsResponse',
'ListCallMatchersRequest',
'ListCallMatchersResponse',
'ListContextsRequest',
'ListContextsResponse',
'ListConversationAssignmentsRequest',
'ListConversationAssignmentsResponse',
'ListConversationDatasetsRequest',
'ListConversationDatasetsResponse',
'ListConversationModelsRequest',
'ListConversationModelsResponse',
'ListConversationProfilesRequest',
'ListConversationProfilesResponse',
'ListConversationalTrainingAssignmentsRequest',
'ListConversationalTrainingAssignmentsResponse',
'ListConversationalTrainingMembersRequest',
'ListConversationalTrainingMembersResponse',
'ListConversationalTrainingModulesRequest',
'ListConversationalTrainingModulesResponse',
'ListConversationalTrainingTeamsRequest',
'ListConversationalTrainingTeamsResponse',
'ListConversationsRequest',
'ListConversationsResponse',
'ListDocumentsRequest',
'ListDocumentsResponse',
'ListEntityTypesRequest',
'ListEntityTypesResponse',
'ListEnvironmentsRequest',
'ListEnvironmentsResponse',
'ListGeneratorEvaluationsRequest',
'ListGeneratorEvaluationsResponse',
'ListGeneratorsRequest',
'ListGeneratorsResponse',
'ListHumanAgentAssistantsRequest',
'ListHumanAgentAssistantsResponse',
'ListIntentsRequest',
'ListIntentsResponse',
'ListInteractionMonitoringAlertsRequest',
'ListInteractionMonitoringAlertsResponse',
'ListInteractionMonitoringMetricsRequest',
'ListInteractionMonitoringMetricsResponse',
'ListKnowledgeBasesRequest',
'ListKnowledgeBasesResponse',
'ListMessagesRequest',
'ListMessagesResponse',
'ListParticipantsRequest',
'ListParticipantsResponse',
'ListPastCallCompanionEventsRequest',
'ListPastCallCompanionEventsResponse',
'ListPhoneNumberOrdersRequest',
'ListPhoneNumberOrdersResponse',
'ListPhoneNumbersRequest',
'ListPhoneNumbersResponse',
'ListSessionEntityTypesRequest',
'ListSessionEntityTypesResponse',
'ListSipTrunksRequest',
'ListSipTrunksResponse',
'ListSuggestionsRequest',
'ListSuggestionsResponse',
'ListSupervisorsRequest',
'ListSupervisorsResponse',
'ListToolsRequest',
'ListToolsResponse',
'ListVersionsRequest',
'ListVersionsResponse',
'LoggingConfig',
'Message',
'MessageAnnotation',
'MessageEntry',
'MetricValues',
'NotificationConfig',
'OriginalDetectIntentRequest',
'OutputAudio',
'OutputAudioConfig',
'OutputAudioEncoding',
'ParameterSuggestions',
'Participant',
'ParticipantsClient',
'PhoneNumber',
'PhoneNumberOrder',
'PhoneNumberOrdersClient',
'PhoneNumberSpec',
'PhoneNumbersClient',
'ProbeDetails',
'PushFulfillmentResultRequest',
'QueryInput',
'QueryParameters',
'QueryResult',
'RaiSettings',
'RawMetricValue',
'ReloadDocumentRequest',
'ResponseMessage',
'RestoreAgentRequest',
'SearchAgentsRequest',
'SearchAgentsResponse',
'SearchArticleAnswer',
'SearchArticlesRequest',
'SearchArticlesResponse',
'SearchConfig',
'SearchKnowledgeAnswer',
'SearchKnowledgeDebugInfo',
'SearchKnowledgeRequest',
'SearchKnowledgeResponse',
'SecuritySettings',
'SecuritySettingsServiceClient',
'Sentiment',
'SentimentAnalysisRequestConfig',
'SentimentAnalysisResult',
'ServiceLatency',
'SessionEntityType',
'SessionEntityTypesClient',
'SessionsClient',
'SetAgentRequest',
'SetSuggestionFeatureConfigOperationMetadata',
'SetSuggestionFeatureConfigRequest',
'SipConfig',
'SipHostname',
'SipTrunk',
'SipTrunksClient',
'SmartComposeAnswer',
'SmartComposeModelMetadata',
'SmartReplyAnswer',
'SmartReplyConfig',
'SmartReplyModelMetadata',
'SpeechContext',
'SpeechModelVariant',
'SpeechToTextConfig',
'SpeechWordInfo',
'SsmlVoiceGender',
'StreamingAnalyzeContentRequest',
'StreamingAnalyzeContentResponse',
'StreamingDetectIntentRequest',
'StreamingDetectIntentResponse',
'StreamingListCallCompanionEventsRequest',
'StreamingListCallCompanionEventsResponse',
'StreamingListUpcomingCallCompanionEventsRequest',
'StreamingListUpcomingCallCompanionEventsResponse',
'StreamingRecognitionResult',
'SubAgent',
'SuggestArticlesRequest',
'SuggestArticlesResponse',
'SuggestConversationKeyMomentsRequest',
'SuggestConversationKeyMomentsResponse',
'SuggestConversationSummaryRequest',
'SuggestConversationSummaryResponse',
'SuggestDialogflowAssistsRequest',
'SuggestDialogflowAssistsResponse',
'SuggestFaqAnswersRequest',
'SuggestFaqAnswersResponse',
'SuggestKnowledgeAssistRequest',
'SuggestKnowledgeAssistResponse',
'SuggestSmartComposeAnswersRequest',
'SuggestSmartComposeAnswersResponse',
'SuggestSmartRepliesRequest',
'SuggestSmartRepliesResponse',
'Suggestion',
'SuggestionDedupingConfig',
'SuggestionFeature',
'SuggestionInput',
'SuggestionResult',
'SummarizationContext',
'SummarizationEvaluationMetrics',
'SummarizationModelMetadata',
'SummarizationSection',
'SummarizationSectionList',
'SummarySuggestion',
'Supervisor',
'SupervisorAssignmentServiceClient',
'SupervisorStatus',
'SynthesizeSpeechConfig',
'TelephonyDtmf',
'TelephonyDtmfEvents',
'TelephonySttConfig',
'TextInput',
'TextToSpeechSettings',
'Tool',
'ToolCall',
'ToolCallResult',
'ToolsClient',
'ToolsetTool',
'TrainAgentRequest',
'TranslationContext',
'TranslationCustomization',
'TranslationSuggestion',
'TriggerEvent',
'TriggerModelMode',
'UndeletePhoneNumberRequest',
'UndeployConversationModelOperationMetadata',
'UndeployConversationModelRequest',
'UpdateAnswerRecordRequest',
'UpdateContextRequest',
'UpdateConversationProfileRequest',
'UpdateConversationRequest',
'UpdateConversationalTrainingAssignmentRequest',
'UpdateConversationalTrainingMemberRequest',
'UpdateConversationalTrainingModuleRequest',
'UpdateConversationalTrainingTeamRequest',
'UpdateDocumentRequest',
'UpdateEntityTypeRequest',
'UpdateEnvironmentRequest',
'UpdateFulfillmentRequest',
'UpdateGeneratorRequest',
'UpdateHumanAgentAssistantRequest',
'UpdateIntentRequest',
'UpdateKnowledgeBaseRequest',
'UpdateParticipantRequest',
'UpdatePhoneNumberOrderRequest',
'UpdatePhoneNumberRequest',
'UpdateSecuritySettingsRequest',
'UpdateSessionEntityTypeRequest',
'UpdateSipTrunkRequest',
'UpdateSupervisorStatusRequest',
'UpdateToolRequest',
'UpdateVersionRequest',
'ValidationError',
'ValidationResult',
'Version',
'VersionsClient',
'VoiceSelectionParams',
'WebhookRequest',
'WebhookResponse',
)
