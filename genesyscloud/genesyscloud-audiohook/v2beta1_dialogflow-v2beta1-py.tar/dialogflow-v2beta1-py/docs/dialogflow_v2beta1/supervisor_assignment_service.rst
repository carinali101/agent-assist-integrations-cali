SupervisorAssignmentService
---------------------------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.supervisor_assignment_service
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.supervisor_assignment_service.pagers
    :members:
    :inherited-members:
