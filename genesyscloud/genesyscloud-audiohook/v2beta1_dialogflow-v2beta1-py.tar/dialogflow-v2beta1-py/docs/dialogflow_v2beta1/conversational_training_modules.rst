ConversationalTrainingModules
-----------------------------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.conversational_training_modules
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.conversational_training_modules.pagers
    :members:
    :inherited-members:
