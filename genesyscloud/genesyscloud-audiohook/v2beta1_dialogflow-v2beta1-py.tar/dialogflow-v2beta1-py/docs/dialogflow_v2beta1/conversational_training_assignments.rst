ConversationalTrainingAssignments
---------------------------------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.conversational_training_assignments
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.conversational_training_assignments.pagers
    :members:
    :inherited-members:
